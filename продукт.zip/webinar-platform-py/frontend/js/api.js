/**
 * Клиент REST API ConfHub.
 *
 * Обязанности:
 *  - строит адреса ресурсов вида api/v1/webinars/12/messages;
 *  - получает и подставляет CSRF-токен в заголовок X-CSRF-Token для
 *    всех изменяющих запросов (POST/PATCH/DELETE);
 *  - отправляет cookie сессии (credentials: 'include');
 *  - превращает ответ с ошибкой в исключение с понятным текстом.
 */
const Api = {
  base: '/api/v1',
  csrfToken: null,
  _ready: null,

  buildUrl(path, query) {
    const clean = String(path).replace(/^\/+/, '');
    const url = `${this.base}/${clean}`;
    const qs = new URLSearchParams(query || {}).toString();
    return qs ? `${url}?${qs}` : url;
  },

  /** Получает CSRF-токен (один раз при первом обращении к API). */
  async init() {
    if (this.csrfToken) return;
    if (!this._ready) {
      this._ready = (async () => {
        try {
          const response = await fetch(this.buildUrl('csrf'), { credentials: 'include' });
          const data = await response.json();
          if (!response.ok || !data.csrf_token) throw new Error('csrf');
          this.csrfToken = data.csrf_token;
        } catch (e) {
          this._ready = null;
          throw new Error('Не удалось связаться с REST API (/api/v1). Проверьте, что сервер запущен.');
        }
      })();
    }
    return this._ready;
  },

  async request(method, path, { body, query } = {}) {
    await this.init();

    const options = {
      method,
      credentials: 'include',
      headers: { Accept: 'application/json' },
    };

    if (method !== 'GET') {
      // Синхронизирующий CSRF-токен: без него сервер вернёт 419.
      options.headers['X-CSRF-Token'] = this.csrfToken || '';
    }
    if (body !== undefined) {
      options.headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(body);
    }

    let response;
    try {
      response = await fetch(this.buildUrl(path, query), options);
    } catch (e) {
      throw new Error('Не удалось связаться с сервером');
    }

    if (response.status === 204) return {};

    let data = {};
    try {
      data = await response.json();
    } catch (e) {
      data = {};
    }

    // Сервер мог перевыпустить токен (вход, выход, смена пароля).
    if (data && data.csrf_token) {
      this.csrfToken = data.csrf_token;
    }

    if (!response.ok) {
      const error = new Error(data.error || `Ошибка запроса (${response.status})`);
      error.status = response.status;
      throw error;
    }

    return data;
  },

  get(path, query) {
    return this.request('GET', path, { query });
  },
  post(path, body) {
    return this.request('POST', path, { body: body || {} });
  },
  patch(path, body) {
    return this.request('PATCH', path, { body: body || {} });
  },
  del(path) {
    return this.request('DELETE', path);
  },

  /**
   * Загрузка файла (multipart/form-data) — используется для сохранения
   * записи экрана. В отличие от request(), тело не сериализуется в JSON:
   * браузер сам расставляет корректный Content-Type с boundary.
   */
  async upload(path, formData) {
    await this.init();
    formData.append('csrf_token', this.csrfToken || '');

    let response;
    try {
      response = await fetch(this.buildUrl(path), {
        method: 'POST',
        credentials: 'include',
        headers: { Accept: 'application/json', 'X-CSRF-Token': this.csrfToken || '' },
        body: formData,
      });
    } catch (e) {
      throw new Error('Не удалось связаться с сервером');
    }

    let data = {};
    try {
      data = await response.json();
    } catch (e) {
      data = {};
    }

    if (data && data.csrf_token) {
      this.csrfToken = data.csrf_token;
    }

    if (!response.ok) {
      const error = new Error(data.error || `Ошибка запроса (${response.status})`);
      error.status = response.status;
      throw error;
    }

    return data;
  },
};

/** Форматирование даты «2026-09-13 18:00:00» → «13.09.2026, 18:00». */
function formatDateTime(value) {
  if (!value) return '';
  const d = new Date(String(value).replace(' ', 'T'));
  if (isNaN(d.getTime())) return value;
  return d.toLocaleString('ru-RU', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

/** Подписи статусов вебинара. */
const STATUS_LABELS = {
  scheduled: 'Запланирован',
  live: 'Идёт сейчас',
  finished: 'Завершён',
};


/**
 * Отчёты об ошибках JavaScript: необработанные исключения и отклонённые промисы отправляются на сервер
 * (POST /api/v1/client-errors) и попадают в журнал ошибок админ-панели. Не чаще 5 раз за сессию страницы.
 */
(function reportClientErrors() {
  let sent = 0;
  async function report(message, source, line, stack) {
    if (sent >= 5) return;
    sent += 1;
    try {
      await Api.post('client-errors', {
        message: String(message || '').slice(0, 300), source: String(source || '').slice(0, 200),
        line, stack: String(stack || '').slice(0, 3000), page: location.pathname + location.search,
      });
    } catch (e) { /* журналирование не должно ломать страницу */ }
  }
  window.addEventListener('error', (e) => report(e.message, e.filename, e.lineno, e.error && e.error.stack));
  window.addEventListener('unhandledrejection', (e) => {
    const r = e.reason;
    report(r && r.message ? r.message : r, 'promise', 0, r && r.stack);
  });
})();
