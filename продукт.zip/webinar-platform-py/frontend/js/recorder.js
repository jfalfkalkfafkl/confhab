/**
 * Запись экрана организатора и завершение эфира.
 *
 * Модуль используется и на дашборде (вкладка «В эфире»), и на странице
 * вебинара, поэтому вся логика вынесена сюда:
 *
 *  - ScreenRecorder — обёртка над getDisplayMedia + MediaRecorder;
 *  - publishRecording() — загрузка файла на сервер и перевод вебинара
 *    в статус «Завершён» с ссылкой на запись (после этого запись можно
 *    смотреть во вкладке «Завершённые»);
 *  - ScreenRecorderMixin — готовое состояние и методы для Vue-страниц;
 *  - fixVideoDuration() — «починка» длительности записи, чтобы по ней
 *    работала перемотка.
 */

class ScreenRecorder {
  /**
   * @param {{onTick?: function(number), onFinish?: function(Blob|null)}} handlers
   *   onTick   — раз в полсекунды, с прошедшим временем в секундах;
   *   onFinish — запись остановлена (нашей кнопкой или системной кнопкой
   *              браузера «Прекратить показ»), с готовым файлом или null.
   */
  constructor({ onTick, onFinish } = {}) {
    this.onTick = onTick || (() => {});
    this.onFinish = onFinish || (() => {});
    this.stream = null;
    this.recorder = null;
    this.chunks = [];
    this.startedAt = 0;
    this.timer = null;
    this.active = false;
    this.stopping = false;
    this.finished = false;
  }

  /** Причина, по которой запись недоступна, или пустая строка, если всё в порядке. */
  static unsupportedReason() {
    // getDisplayMedia доступен только в «безопасном контексте»: https или
    // http://localhost. По адресу вида http://my-site/ браузер прячет
    // navigator.mediaDevices целиком — отдельно объясняем это пользователю.
    if (!window.isSecureContext) {
      return 'Запись экрана работает только на защищённых адресах: откройте сайт по https ' +
        'или через http://localhost (адрес «' + window.location.origin + '» браузер считает небезопасным).';
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
      return 'Этот браузер не поддерживает запись экрана.';
    }
    if (typeof MediaRecorder === 'undefined') {
      return 'Этот браузер не поддерживает запись видео (MediaRecorder).';
    }
    return '';
  }

  static _error(message, code) {
    const err = new Error(message);
    err.code = code;
    return err;
  }

  /**
   * Открывает системное окно выбора экрана и начинает запись.
   * Ошибки: code === 'cancelled' — человек закрыл окно выбора (это не
   * ошибка, показывать ничего не нужно); 'unsupported' / 'failed' — с текстом.
   */
  async start() {
    const reason = ScreenRecorder.unsupportedReason();
    if (reason) throw ScreenRecorder._error(reason, 'unsupported');

    let stream;
    try {
      stream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 30 },
        audio: true,
      });
    } catch (err) {
      if (err && (err.name === 'NotAllowedError' || err.name === 'AbortError')) {
        throw ScreenRecorder._error('', 'cancelled');
      }
      throw ScreenRecorder._error(
        'Не удалось начать запись экрана: ' + (err && err.message ? err.message : err), 'failed'
      );
    }

    const candidates = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    const mimeType = candidates.find((type) => MediaRecorder.isTypeSupported(type)) || '';

    let recorder;
    try {
      recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
    } catch (err) {
      stream.getTracks().forEach((track) => track.stop());
      throw ScreenRecorder._error('Не удалось запустить запись: ' + err.message, 'failed');
    }

    this.stream = stream;
    this.recorder = recorder;
    this.chunks = [];

    recorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) this.chunks.push(event.data);
    };
    recorder.onstop = () => this._finish();

    // Системная кнопка «Прекратить показ» завершает запись так же,
    // как наша собственная кнопка.
    stream.getVideoTracks()[0].addEventListener('ended', () => this.stop());

    this.startedAt = Date.now();
    this.active = true;
    this.timer = setInterval(() => {
      this.onTick(Math.floor((Date.now() - this.startedAt) / 1000));
    }, 500);

    recorder.start(1000);
  }

  /** Останавливает запись; готовый файл придёт в onFinish. */
  stop() {
    if (this.finished || this.stopping) return;
    this.stopping = true;
    if (this.recorder && this.recorder.state !== 'inactive') {
      this.recorder.stop(); // дальше сработает onstop → _finish()
    } else {
      this._finish();
    }
  }

  /** Полностью гасит захват без вызова onFinish (уход со страницы). */
  dispose() {
    this.finished = true;
    this.onFinish = () => {};
    clearInterval(this.timer);
    if (this.recorder && this.recorder.state !== 'inactive') {
      try { this.recorder.stop(); } catch (e) { /* уже остановлен */ }
    }
    this._releaseStream();
    this.chunks = [];
  }

  _releaseStream() {
    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
      this.stream = null;
    }
  }

  _finish() {
    if (this.finished) return;
    this.finished = true;
    this.active = false;
    clearInterval(this.timer);
    this._releaseStream();

    const type = (this.chunks[0] && this.chunks[0].type) ||
      (this.recorder && this.recorder.mimeType) || 'video/webm';
    const blob = this.chunks.length ? new Blob(this.chunks, { type }) : null;
    this.chunks = [];
    this.onFinish(blob);
  }
}

/**
 * Завершение эфира с записью: загружает файл на сервер (если он ещё не
 * загружен) и одним запросом ставит вебинару статус «Завершён» и ссылку
 * на запись. Результат загрузки кэшируется в cache.url — при повторной
 * попытке (после сбоя сети) файл не отправляется второй раз.
 */
async function publishRecording(webinarId, blob, cache) {
  if (!cache.url) {
    const extension = /mp4/i.test(blob.type) ? 'mp4' : 'webm';
    const formData = new FormData();
    formData.append('recording', blob, 'screen-recording.' + extension);
    const { path } = await Api.upload(`webinars/${webinarId}/recording`, formData);
    cache.url = absoluteUrlFromPublicPath(path);
  }
  await Api.patch(`webinars/${webinarId}`, { recording_url: cache.url, status: 'finished' });
  return cache.url;
}

/** Сохраняет Blob как файл на компьютер (запасной вариант, если загрузка не удалась). */
function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

/**
 * MediaRecorder в Chrome пишет WebM без длительности: у ролика duration
 * равна Infinity и ползунок перемотки не работает. Если «прыгнуть» в
 * конец, браузер досчитывает длительность — после этого возвращаемся в начало.
 */
function fixVideoDuration(video) {
  if (!video || video.duration !== Infinity) return;
  const restore = () => {
    video.removeEventListener('timeupdate', restore);
    video.currentTime = 0;
  };
  video.addEventListener('timeupdate', restore);
  video.currentTime = 1e101;
}

/**
 * Vue-миксин: состояние и методы записи экрана для страницы.
 *
 * Страница подключает его через `mixins: [ScreenRecorderMixin]`, кладёт в
 * шаблон <video ref="recPreview" autoplay muted playsinline> для живого
 * предпросмотра и (по желанию) определяет методы-обработчики:
 *   onRecordingStarted()          — эфир начался, статус стал «В эфире»;
 *   onRecordingSaved(webinarId)   — запись сохранена, вебинар завершён.
 */
const ScreenRecorderMixin = {
  data() {
    return {
      recActive: false,       // идёт запись
      recSeconds: 0,          // сколько записано, секунд
      recSaving: false,       // файл загружается на сервер
      recError: '',           // текст ошибки (запись/загрузка)
      recSaved: false,        // запись сохранена, эфир завершён
      recPending: null,       // файл, который не удалось загрузить (можно повторить/скачать)
      recWebinarId: null,     // для какого вебинара идёт/шла запись
      recCache: { url: null }, // ссылка на уже загруженный файл
    };
  },

  computed: {
    recTimeLabel() {
      const m = String(Math.floor(this.recSeconds / 60)).padStart(2, '0');
      const s = String(this.recSeconds % 60).padStart(2, '0');
      return `${m}:${s}`;
    },
  },

  mounted() {
    // Закрытие вкладки во время записи или до сохранения файла — потеря
    // эфира, поэтому просим браузер переспросить.
    this._recGuard = (event) => {
      if (this.recActive || this.recPending) {
        event.preventDefault();
        event.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', this._recGuard);
  },

  beforeUnmount() {
    window.removeEventListener('beforeunload', this._recGuard);
    if (this._recorder) this._recorder.dispose();
  },

  methods: {
    /**
     * Начинает эфир: запрашивает экран, запускает запись и переводит
     * вебинар в статус «В эфире». Вызывать из обработчика клика.
     */
    async startRecording(webinarId) {
      if (this.recActive || this.recSaving) return;

      this.recError = '';
      this.recSaved = false;
      this.recPending = null;
      this.recCache = { url: null };

      const recorder = Vue.markRaw(new ScreenRecorder({
        onTick: (seconds) => { this.recSeconds = seconds; },
        onFinish: (blob) => this._onRecordingFinished(blob),
      }));

      try {
        await recorder.start();
      } catch (err) {
        if (err.code !== 'cancelled') this.recError = err.message;
        return;
      }

      this._recorder = recorder;
      this.recWebinarId = webinarId;
      this.recSeconds = 0;
      this.recActive = true;

      await Vue.nextTick();
      if (this.$refs.recPreview) this.$refs.recPreview.srcObject = recorder.stream;

      // Запись уже идёт — статус «В эфире» ставим после, чтобы отмена
      // окна выбора экрана не запускала эфир.
      try {
        await Api.patch(`webinars/${webinarId}`, { status: 'live' });
        if (this.onRecordingStarted) await this.onRecordingStarted();
      } catch (err) {
        this.recError = 'Запись идёт, но статус «В эфире» поставить не удалось: ' + err.message;
      }
    },

    /** Завершает эфир: останавливает запись; дальше файл сохранится сам. */
    stopRecording() {
      if (!this.recActive || !this._recorder) return;
      this.recSaving = true;
      this._recorder.stop();
    },

    async _onRecordingFinished(blob) {
      this.recActive = false;
      this._recorder = null;

      if (!blob) {
        // Пустая запись: сохранять нечего, но эфир при этом закончился.
        this.recSaving = true;
        try {
          await Api.patch(`webinars/${this.recWebinarId}`, { status: 'finished' });
          if (this.onRecordingSaved) await this.onRecordingSaved(this.recWebinarId);
        } catch (err) { /* статус можно поменять вручную */ }
        this.recSaving = false;
        this.recError = 'Запись получилась пустой, поэтому сохранять нечего. Эфир завершён без записи.';
        return;
      }

      this.recPending = blob;
      await this.uploadPendingRecording();
    },

    /** Загружает файл и завершает вебинар. Повторяется кнопкой при сбое. */
    async uploadPendingRecording() {
      if (!this.recPending) return;
      this.recSaving = true;
      this.recError = '';
      try {
        await publishRecording(this.recWebinarId, this.recPending, this.recCache);
        this.recPending = null;
        this.recSaved = true;
        if (this.onRecordingSaved) await this.onRecordingSaved(this.recWebinarId);
      } catch (err) {
        this.recError = 'Не удалось сохранить запись: ' + err.message;
      } finally {
        this.recSaving = false;
      }
    },

    downloadPendingRecording() {
      if (!this.recPending) return;
      const extension = /mp4/i.test(this.recPending.type) ? 'mp4' : 'webm';
      downloadBlob(this.recPending, `webinar-${this.recWebinarId}.${extension}`);
    },
  },
};
