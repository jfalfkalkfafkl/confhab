/**
 * Слайдер главной страницы (без библиотек).
 *
 * Требования: 4 слайда, автопрокрутка каждые 3 секунды.
 * Дополнительно: стрелки, точки, свайп на телефоне, стрелки клавиатуры, кнопка «пауза»
 * (доступность, WCAG 2.2.2), остановка при наведении/фокусе и когда вкладка скрыта,
 * индикатор времени до следующего слайда.
 */
(function () {
  const INTERVAL = 3000; // автопрокрутка, мс
  const root = document.querySelector('[data-slider]');
  if (!root) return;

  const slides = Array.from(root.querySelectorAll('.slide'));
  const captions = Array.from(document.querySelectorAll('.caption-slide'));
  const dotsBox = root.querySelector('.dots');
  const bar = root.querySelector('.hero-progress i');
  const pauseBtn = root.querySelector('[data-pause]');
  const live = root.querySelector('[data-live]');
  let index = 0;
  let timer = null;
  let userPaused = false;   // нажата кнопка «пауза»
  let hovering = false;     // курсор/фокус внутри слайдера

  const dots = slides.map((_, i) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.setAttribute('aria-label', `Слайд ${i + 1} из ${slides.length}`);
    b.addEventListener('click', () => { go(i); restart(); });
    dotsBox.appendChild(b);
    return b;
  });

  function show(i) {
    index = (i + slides.length) % slides.length;
    slides.forEach((s, n) => {
      const on = n === index;
      s.classList.toggle('active', on);
      s.setAttribute('aria-hidden', on ? 'false' : 'true');
    });
    captions.forEach((c, n) => c.classList.toggle('active', n === index));
    dots.forEach((d, n) => {
      d.classList.toggle('active', n === index);
      d.setAttribute('aria-current', n === index ? 'true' : 'false');
    });
    if (live) live.textContent = `Слайд ${index + 1} из ${slides.length}`;
  }

  function resetBar() {
    if (!bar) return;
    bar.classList.remove('run');
    void bar.offsetWidth;               // перезапуск CSS-анимации
    if (isRunning()) bar.classList.add('run');
  }

  const isRunning = () => !userPaused && !hovering && !document.hidden;
  function go(i) { show(i); resetBar(); }
  function next() { go(index + 1); }
  function prev() { go(index - 1); }

  function restart() {
    clearInterval(timer);
    timer = null;
    resetBar();
    if (isRunning()) timer = setInterval(next, INTERVAL);
  }

  function setPaused(v) {
    userPaused = v;
    if (pauseBtn) {
      pauseBtn.textContent = v ? '▶' : '⏸';
      pauseBtn.setAttribute('aria-label', v ? 'Запустить автопрокрутку' : 'Остановить автопрокрутку');
    }
    root.classList.toggle('paused', v || hovering);
    restart();
  }

  root.querySelector('[data-next]')?.addEventListener('click', () => { next(); restart(); });
  root.querySelector('[data-prev]')?.addEventListener('click', () => { prev(); restart(); });
  pauseBtn?.addEventListener('click', () => setPaused(!userPaused));

  // Пауза при наведении мыши и при фокусе внутри слайдера
  ['mouseenter', 'focusin'].forEach((e) => root.addEventListener(e, () => { hovering = true; root.classList.add('paused'); restart(); }));
  ['mouseleave', 'focusout'].forEach((e) => root.addEventListener(e, () => { hovering = false; root.classList.toggle('paused', userPaused); restart(); }));
  document.addEventListener('visibilitychange', restart);

  // Свайп пальцем
  let startX = 0, startY = 0;
  root.addEventListener('touchstart', (e) => { startX = e.touches[0].clientX; startY = e.touches[0].clientY; }, { passive: true });
  root.addEventListener('touchend', (e) => {
    const dx = e.changedTouches[0].clientX - startX;
    const dy = e.changedTouches[0].clientY - startY;
    if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) { dx < 0 ? next() : prev(); restart(); }
  }, { passive: true });

  // Стрелки клавиатуры
  root.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight') { next(); restart(); }
    if (e.key === 'ArrowLeft') { prev(); restart(); }
  });

  show(0);
  restart();
})();
