/**
 * Лёгкий клиентский роутер на основе hash (без сборщика и без Vue Router).
 *
 * Возможности:
 *  - таблица маршрутов с необязательной проверкой доступа (guard);
 *  - переходы через историю браузера (кнопки «Назад/Вперёд» работают);
 *  - маршрут по умолчанию (fallback) для неизвестных адресов;
 *  - поддержка обоих видов адресов: dashboard.html#live и dashboard.html#/live.
 *
 * Пример:
 *   HashRouter.init({
 *     routes: [{ path: 'users' }, { path: 'log', guard: (u) => u.role === 'admin' }],
 *     fallback: 'users',
 *     context: user,
 *     onChange: (path) => { this.view = path; },
 *   });
 *   HashRouter.go('log');
 */
const HashRouter = {
  routes: [],
  fallback: '',
  context: null,
  onChange: null,
  current: '',

  init({ routes, fallback, context = null, onChange }) {
    this.routes = routes;
    this.fallback = fallback;
    this.context = context;
    this.onChange = onChange;
    window.addEventListener('hashchange', () => this.resolve());
    this.resolve(true);
  },

  /** Текущий путь из адресной строки: «#/live» и «#live» → «live». */
  parse() {
    return window.location.hash.replace(/^#\/?/, '').split('?')[0];
  },

  /** Есть ли такой маршрут и разрешён ли он текущему пользователю. */
  allowed(path) {
    const route = this.routes.find((r) => r.path === path);
    if (!route) return false;
    return typeof route.guard !== 'function' || !!route.guard(this.context);
  },

  /** Переход на маршрут (создаёт запись в истории браузера). */
  go(path) {
    const target = this.allowed(path) ? path : this.fallback;
    if (this.parse() === target) {
      this.resolve();
      return;
    }
    window.location.hash = '/' + target;
  },

  /** Приводит адрес к допустимому маршруту и уведомляет приложение. */
  resolve(initial = false) {
    let path = this.parse();
    if (!this.allowed(path)) {
      path = this.fallback;
      // Неизвестный/запрещённый адрес заменяем без записи в историю
      window.history.replaceState(null, '', '#/' + path);
    }
    if (!initial && path === this.current) return;
    this.current = path;
    if (typeof this.onChange === 'function') this.onChange(path);
  },
};
