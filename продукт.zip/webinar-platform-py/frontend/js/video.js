/**
 * Video — определение видеосервиса по ссылке и подготовка данных для показа
 * трансляции/записи на странице вебинара.
 *
 * Основные площадки проекта:
 *   • Яндекс Телемост — встраивание в чужие сайты запрещено самим сервисом, поэтому на странице
 *     вебинара показывается кнопка «Перейти в Телемост» (чат, опросы и вопросы остаются на ConfHub);
 *   • VK Видео (vk.com/video-1_2, vkvideo.ru/video-1_2, video_ext.php) — встраивается плеером <iframe>.
 * Дополнительно: RuTube, Vimeo, Twitch, Kinescope (плеер), Zoom, Google Meet, Teams, Discord (кнопка),
 * прямые видеофайлы и запись экрана (<video>). Любой другой адрес открывается кнопкой-ссылкой:
 * произвольные сайты в iframe не встраиваются (это же ограничено заголовком CSP frame-src).
 *
 * Важно: список встраиваемых хостов должен совпадать с FRAME_SRC в core/middleware.py.
 */
const Video = {
  /**
   * @param {string} url
   * @returns {{type: 'embed'|'file'|'link'|'unknown', src?: string, href?: string,
   *            platform: string, label: string}}
   */
  resolve(url) {
    if (!url) return { type: 'unknown', platform: '', label: '' };

    let u;
    try {
      u = new URL(url);
    } catch {
      return { type: 'unknown', platform: '', label: '' };
    }
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return { type: 'unknown', platform: '', label: '' };
    const host = u.hostname.replace(/^www\./, '').toLowerCase();
    const is = (domain) => host === domain || host.endsWith('.' + domain);

    // Прямая ссылка на видеофайл (запись экрана или любой .mp4/.webm) — обычный <video>
    if (/\.(webm|mp4|ogv|ogg|mov)$/i.test(u.pathname)) {
      return { type: 'file', src: url, platform: 'file', label: 'Видеозапись' };
    }

    // ---- Яндекс Телемост: только переход по ссылке ----
    if (['telemost.yandex.ru', 'telemost.360.yandex.ru', 'telemost.yandex.com'].some(is)) {
      return { type: 'link', href: url, platform: 'telemost', label: 'Яндекс Телемост' };
    }

    // ---- VK Видео ----
    if (is('vk.com') || is('vkvideo.ru') || is('vk.ru')) {
      const vk = this._vkEmbed(u);
      if (vk) return this._embed(vk, 'vk', 'VK Видео');
      return { type: 'link', href: url, platform: 'vk', label: 'VK Видео' };
    }

    // ---- Остальные плееры ----
    if (is('rutube.ru')) {
      const m = u.pathname.match(/\/(?:video|play\/embed)\/([a-zA-Z0-9]+)/);
      if (m) return this._embed(`https://rutube.ru/play/embed/${m[1]}`, 'rutube', 'RuTube');
    }
    if (is('vimeo.com')) {
      const id = u.pathname.split('/').filter(Boolean).pop();
      if (/^\d+$/.test(id || '')) return this._embed(`https://player.vimeo.com/video/${id}`, 'vimeo', 'Vimeo');
    }
    if (is('twitch.tv')) {
      const parts = u.pathname.split('/').filter(Boolean);
      const parent = encodeURIComponent(window.location.hostname);
      if (parts[0] === 'videos' && parts[1]) return this._embed(`https://player.twitch.tv/?video=${encodeURIComponent(parts[1])}&parent=${parent}`, 'twitch', 'Twitch');
      if (parts[0]) return this._embed(`https://player.twitch.tv/?channel=${encodeURIComponent(parts[0])}&parent=${parent}`, 'twitch', 'Twitch');
    }
    if (is('kinescope.io')) {
      const id = u.pathname.split('/').filter(Boolean).pop();
      if (id) return this._embed(`https://kinescope.io/embed/${encodeURIComponent(id)}`, 'kinescope', 'Kinescope');
    }

    // ---- Сервисы встреч: iframe запрещён самими сервисами ----
    const meetings = { 'zoom.us': ['zoom', 'Zoom'], 'meet.google.com': ['meet', 'Google Meet'],
      'teams.microsoft.com': ['teams', 'Microsoft Teams'], 'teams.live.com': ['teams', 'Microsoft Teams'],
      'discord.com': ['discord', 'Discord'], 'discord.gg': ['discord', 'Discord'] };
    for (const [domain, [key, label]] of Object.entries(meetings)) {
      if (is(domain)) return { type: 'link', href: url, platform: key, label };
    }

    // Неизвестный сайт: безопасная кнопка-ссылка (в iframe не встраиваем)
    return { type: 'link', href: url, platform: 'other', label: host };
  },

  /** Ссылка VK → адрес встраиваемого плеера или null. Понимает video-1_2, ?z=video-1_2, video_ext.php?oid=&id=. */
  _vkEmbed(u) {
    let oid, id, hash;
    if (u.pathname.includes('video_ext.php')) {
      oid = u.searchParams.get('oid');
      id = u.searchParams.get('id');
      hash = u.searchParams.get('hash');
    } else {
      const text = decodeURIComponent(u.pathname + ' ' + u.search);
      const m = text.match(/video(-?\d+)_(\d+)/);
      if (m) { oid = m[1]; id = m[2]; }
    }
    if (!/^-?\d+$/.test(oid || '') || !/^\d+$/.test(id || '')) return null;
    let src = `https://vk.com/video_ext.php?oid=${oid}&id=${id}&hd=2`;
    if (hash && /^[a-f0-9]{8,32}$/i.test(hash)) src += `&hash=${hash}`;
    return src;
  },

  _embed(src, platform, label) {
    return { type: 'embed', src, platform, label };
  },
};
