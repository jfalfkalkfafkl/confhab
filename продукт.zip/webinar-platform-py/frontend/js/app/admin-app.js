/**
 * Vue-приложение панели администратора (роль admin).
 *
 * Разделы переключает клиентский роутер (js/router.js):
 *   #/stats     — обзор: счётчики и график активности за 14 дней;
 *   #/users     — пользователи: серверные поиск/фильтры/сортировка/пагинация, роль, правка, блокировка, пароль, удаление, CSV;
 *   #/webinars  — все вебинары: поиск/фильтры/сортировка/пагинация, правка, смена статуса, удаление;
 *   #/categories — категории вебинаров (CRUD);
 *   #/errors    — журнал ошибок (сервер, браузер, внешние сервисы);
 *   #/log       — журнал безопасности с фильтрами и экспортом;
 *   #/security  — смена пароля админа и ключ восстановления.
 *
 * Проверка роли — здесь (requireRole) и на сервере (require_admin() → 403).
 */
const ADMIN_VIEWS = ['stats', 'users', 'webinars', 'categories', 'errors', 'log', 'security'];

/** CSV с защитой от «формульной инъекции» и BOM для корректного открытия в Excel. */
function downloadCsv(filename, header, rows) {
  const esc = (v) => {
    let s = v === null || v === undefined ? '' : String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
    return '"' + s.replace(/"/g, '""') + '"';
  };
  const text = [header, ...rows].map((r) => r.map(esc).join(';')).join('\r\n');
  const blob = new Blob(['\ufeff' + text], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

createConfHubApp({
  data() {
    return {
      user: null,
      view: 'stats',
      error: '',
      info: '',

      stats: null,
      platforms: {},
      series: [],
      loading: false,
      editError: '',

      // Пользователи / вебинары / ошибки: параметры запроса к серверу (поиск, фильтры, сортировка, страница)
      u: { q: '', role: '', status: '', sort: 'created_at', order: 'desc', page: 1, per_page: 10 },
      w: { q: '', status: '', platform: '', category: '', sort: 'date', order: 'desc', page: 1, per_page: 10 },
      e: { source: '', page: 1, per_page: 20 },
      users: [], uMeta: { total: 0, page: 1, pages: 1 },
      webinars: [], wMeta: { total: 0, page: 1, pages: 1 },
      errors: [], eMeta: { total: 0, page: 1, pages: 1 },
      userTotal: 0, webinarTotal: 0,
      categories: [],
      catForm: { id: null, name: '', slug: '', sort_order: 100 },
      wEdit: null,
      uEdit: null,
      tempPassword: null,
      searchTimer: null,

      log: [],
      logType: 'all',
      logSearch: '',

      security: null,
      pw: { current: '', next: '', next2: '' },
      rkPassword: '',
      recoveryKey: '',
    };
  },

  computed: {
    views() {
      return [
        { key: 'stats', label: 'Обзор' },
        { key: 'users', label: 'Пользователи', badge: this.userTotal || '' },
        { key: 'webinars', label: 'Все вебинары', badge: this.webinarTotal || '' },
        { key: 'categories', label: 'Категории' },
        { key: 'errors', label: 'Ошибки', badge: this.stats && this.stats.errors_24h ? this.stats.errors_24h : '', live: true },
        { key: 'log', label: 'Журнал безопасности' },
        { key: 'security', label: 'Безопасность' },
        { key: 'dashboard', label: '← К вебинарам', href: 'dashboard.html' },
      ];
    },

    viewTitle() {
      return {
        stats: 'Обзор платформы', users: 'Пользователи', webinars: 'Все вебинары', categories: 'Категории',
        errors: 'Журнал ошибок', log: 'Журнал безопасности', security: 'Безопасность аккаунта',
      }[this.view];
    },

    // Заголовки сортируемых колонок: key — поле сортировки на сервере
    userCols() {
      return [{ key: 'name', label: 'Имя' }, { key: 'role', label: 'Роль' }, { key: 'organized', label: 'Вебинаров' },
        { key: 'registered', label: 'Регистр.' }, { key: 'created_at', label: 'Создан' }, { key: 'last_login', label: 'Последний вход' }];
    },
    webinarCols() {
      return [{ key: 'title', label: 'Название' }, { key: 'organizer', label: 'Организатор' }, { key: 'date', label: 'Дата' },
        { key: 'status', label: 'Статус' }, { key: 'participants', label: 'Участников' }];
    },

    filteredLog() {
      const q = this.logSearch.trim().toLowerCase();
      if (!q) return this.log;
      return this.log.filter((r) =>
        [r.event, r.user_name, r.ip, r.details].join(' ').toLowerCase().includes(q));
    },

    seriesMax() {
      return Math.max(1, ...this.series.map((d) => Math.max(d.users, d.registrations)));
    },
  },

  watch: {
    // Любое изменение поиска/фильтров → страница 1 и новый запрос (поиск — с задержкой 350 мс)
    'u.q'() { this.debounced('u'); }, 'u.role'() { this.refilter('u'); }, 'u.status'() { this.refilter('u'); }, 'u.per_page'() { this.refilter('u'); },
    'w.q'() { this.debounced('w'); }, 'w.status'() { this.refilter('w'); }, 'w.platform'() { this.refilter('w'); },
    'w.category'() { this.refilter('w'); }, 'w.per_page'() { this.refilter('w'); },
    'e.source'() { this.refilter('e'); },
  },

  async mounted() {
    this.user = await requireRole('admin', 'admin-login.html');
    if (!this.user) return;

    this.loadSecurity();
    Api.get('categories').then((d) => { this.categories = d.categories; }).catch(() => {});
    HashRouter.init({
      routes: ADMIN_VIEWS.map((path) => ({ path, guard: (u) => u && u.role === 'admin' })),
      fallback: 'stats',
      context: this.user,
      onChange: (path) => {
        this.view = path;
        this.loadView(path);
      },
    });
    // Счётчики в меню
    Api.get('admin/users', { per_page: 1 }).then((d) => { this.userTotal = d.total; }).catch(() => {});
    Api.get('admin/webinars', { per_page: 1 }).then((d) => { this.webinarTotal = d.total; }).catch(() => {});
  },

  methods: {
    selectView(key) {
      HashRouter.go(key);
    },

    barHeight(v) {
      return Math.round((v / this.seriesMax) * 100) + '%';
    },

    async loadSecurity() {
      try {
        this.security = await Api.get('admin/security');
      } catch (err) {
        this.error = err.message;
      }
    },

    /** Параметры запроса без пустых значений. */
    query(state) {
      const q = {};
      Object.entries(state).forEach(([k, v]) => { if (v !== '' && v !== null) q[k] = v; });
      return q;
    },

    debounced(key) {
      clearTimeout(this.searchTimer);
      this.searchTimer = setTimeout(() => this.refilter(key), 350);
    },

    refilter(key) {
      this[key].page = 1;
      this.loadView({ u: 'users', w: 'webinars', e: 'errors' }[key]);
    },

    goPage(key, page) {
      this[key].page = page;
      this.loadView({ u: 'users', w: 'webinars', e: 'errors' }[key]);
    },

    /** Клик по заголовку: первый — по возрастанию, повторный — по убыванию. */
    sortBy(key, field) {
      const st = this[key];
      st.order = st.sort === field && st.order === 'asc' ? 'desc' : 'asc';
      st.sort = field;
      this.refilter(key);
    },

    sortClass(key, field) {
      const st = this[key];
      return ['sortable', st.sort === field ? (st.order === 'asc' ? 'sorted-asc' : 'sorted-desc') : ''];
    },

    /** Загружает данные раздела при переходе на него. */
    async loadView(path) {
      this.error = '';
      this.loading = true;
      try {
        if (path === 'stats') {
          const d = await Api.get('admin/stats');
          this.stats = d.stats;
          this.series = d.series;
          this.platforms = d.platforms || {};
        }
        if (path === 'users') {
          const d = await Api.get('admin/users', this.query(this.u));
          this.users = d.users;
          this.uMeta = d;
          this.u.page = d.page;
          this.userTotal = d.total;
        }
        if (path === 'webinars') {
          const d = await Api.get('admin/webinars', this.query(this.w));
          this.webinars = d.webinars;
          this.wMeta = d;
          this.w.page = d.page;
          this.webinarTotal = d.total;
        }
        if (path === 'categories') this.categories = (await Api.get('categories')).categories;
        if (path === 'errors') {
          const d = await Api.get('admin/errors', this.query(this.e));
          this.errors = d.errors;
          this.eMeta = d;
        }
        if (path === 'log') this.log = (await Api.get('admin/security-log', { type: this.logType, limit: 300 })).log;
        if (path === 'security') await this.loadSecurity();
      } catch (err) {
        this.error = err.message;
      } finally {
        this.loading = false;
      }
    },

    notify(message) {
      this.$toast.success(message);
    },

    // ---------- Пользователи ----------
    async changeRole(u, role) {
      this.error = '';
      if (!confirm(`Изменить роль пользователя «${u.name}»?`)) {
        await this.loadView('users');
        return;
      }
      try {
        await Api.patch(`admin/users/${u.id}`, { role });
        u.role = role;
        this.notify(`Роль пользователя «${u.name}» изменена`);
      } catch (err) {
        this.$toast.error(err.message);
        await this.loadView('users');
      }
    },

    async toggleBan(u) {
      const ban = !u.is_banned;
      if (ban && !confirm(`Заблокировать пользователя «${u.name}»?`)) return;
      try {
        await Api.patch(`admin/users/${u.id}`, { is_banned: ban });
        u.is_banned = ban;
        this.notify(ban ? 'Пользователь заблокирован' : 'Пользователь разблокирован');
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    async resetUserPassword(u) {
      if (!confirm(`Выдать пользователю «${u.name}» временный пароль? Прежний пароль перестанет работать.`)) return;
      try {
        const d = await Api.post(`admin/users/${u.id}/reset-password`);
        this.tempPassword = { name: u.name, value: d.temporary_password };
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    async deleteUser(u) {
      if (!confirm(`Удалить пользователя «${u.name}» вместе с его вебинарами? Действие необратимо.`)) return;
      try {
        await Api.del(`admin/users/${u.id}`);
        this.notify('Пользователь удалён');
        await this.loadView('users');
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    openUserEdit(u) {
      this.editError = '';
      this.uEdit = { id: u.id, name: u.name, email: u.email };
    },

    async saveUserEdit() {
      try {
        await Api.patch(`admin/users/${this.uEdit.id}`, { name: this.uEdit.name.trim(), email: this.uEdit.email.trim() });
        this.uEdit = null;
        this.notify('Данные пользователя сохранены');
        await this.loadView('users');
      } catch (err) {
        this.editError = err.message;
      }
    },

    /** CSV: выгружаются все записи под текущими фильтрами (страницами по 200 с сервера). */
    async exportUsers() {
      const rows = [];
      try {
        for (let page = 1; page < 50; page += 1) {
          const d = await Api.get('admin/users', { ...this.query(this.u), page, per_page: 200 });
          rows.push(...d.users);
          if (page >= d.pages) break;
        }
      } catch (err) {
        this.$toast.error(err.message);
        return;
      }
      downloadCsv('users.csv',
        ['ID', 'Имя', 'Email', 'Роль', 'Вебинаров', 'Регистраций', 'Создан', 'Последний вход', 'Заблокирован'],
        rows.map((u) => [u.id, u.name, u.email, u.role, u.organized_count,
          u.registered_count, u.created_at, u.last_login_at, u.is_banned ? 'да' : 'нет']));
    },

    // ---------- Вебинары ----------
    async setWebinarStatus(w, status) {
      try {
        await Api.patch(`admin/webinars/${w.id}`, { status });
        w.status = status;
        this.notify(`Статус вебинара «${w.title}» изменён`);
      } catch (err) {
        this.$toast.error(err.message);
        await this.loadView('webinars');
      }
    },

    openWebinarEdit(w) {
      this.editError = '';
      this.wEdit = {
        id: w.id, title: w.title, description: w.description || '', stream_url: w.stream_url || '',
        recording_url: w.recording_url || '', status: w.status, category_id: w.category_id || '',
        scheduled_at: String(w.scheduled_at).replace(' ', 'T').slice(0, 16),
      };
    },

    async saveWebinarEdit() {
      const e = this.wEdit;
      try {
        await Api.patch(`admin/webinars/${e.id}`, {
          title: e.title.trim(), description: e.description.trim(), stream_url: e.stream_url.trim(),
          recording_url: e.recording_url.trim(), scheduled_at: e.scheduled_at, status: e.status,
          category_id: e.category_id || null,
        });
        this.wEdit = null;
        this.notify('Вебинар сохранён');
        await this.loadView('webinars');
      } catch (err) {
        this.editError = err.message;
      }
    },

    async deleteWebinar(w) {
      if (!confirm(`Удалить вебинар «${w.title}»? Действие необратимо.`)) return;
      try {
        await Api.del(`webinars/${w.id}`);
        this.notify('Вебинар удалён');
        await this.loadView('webinars');
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    // ---------- Категории ----------
    resetCat() { this.catForm = { id: null, name: '', slug: '', sort_order: 100 }; },
    editCat(c) { this.catForm = { id: c.id, name: c.name, slug: c.slug, sort_order: c.sort_order ?? 100 }; },

    async saveCategory() {
      const f = this.catForm;
      const body = { name: f.name.trim(), slug: f.slug.trim().toLowerCase(), sort_order: f.sort_order };
      try {
        if (f.id) await Api.patch(`admin/categories/${f.id}`, body);
        else await Api.post('admin/categories', body);
        this.notify('Категория сохранена');
        this.resetCat();
        await this.loadView('categories');
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    async deleteCat(c) {
      if (!confirm(`Удалить категорию «${c.name}»? Вебинары останутся без категории.`)) return;
      try {
        await Api.del(`admin/categories/${c.id}`);
        this.notify('Категория удалена');
        await this.loadView('categories');
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    // ---------- Журнал ошибок ----------
    async clearErrors() {
      if (!confirm('Очистить весь журнал ошибок?')) return;
      try {
        await Api.del('admin/errors');
        await this.loadView('errors');
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    // ---------- Журнал ----------
    exportLog() {
      downloadCsv('security-log.csv', ['Время', 'Событие', 'Пользователь', 'IP', 'Детали'],
        this.filteredLog.map((r) => [r.created_at, r.event, r.user_name, r.ip, r.details]));
    },

    // ---------- Безопасность ----------
    async changePassword() {
      this.error = '';
      if (this.pw.next !== this.pw.next2) {
        this.error = 'Новые пароли не совпадают';
        return;
      }
      if (this.pw.next.length < 10) {
        this.error = 'Пароль администратора должен содержать не менее 10 символов';
        return;
      }
      try {
        await Api.post('profile/password', {
          current_password: this.pw.current,
          new_password: this.pw.next,
        });
        this.pw = { current: '', next: '', next2: '' };
        this.notify('Пароль администратора изменён');
        await this.loadSecurity();
      } catch (err) {
        this.error = err.message;
      }
    },

    async createRecoveryKey() {
      this.error = '';
      if (this.security && this.security.has_recovery_key
          && !confirm('Прежний ключ восстановления перестанет действовать. Продолжить?')) return;
      try {
        const d = await Api.post('admin/recovery-key', { password: this.rkPassword });
        this.recoveryKey = d.recovery_key;
        this.rkPassword = '';
        await this.loadSecurity();
      } catch (err) {
        this.error = err.message;
      }
    },

    async copyKey() {
      await copyToClipboard(this.recoveryKey);
      this.notify('Ключ скопирован');
    },
  },
}).mount('#admin-app');
