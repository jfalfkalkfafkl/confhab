/**
 * Vue-приложение страницы восстановления пароля.
 *
 * Реальная отправка письма не подключена: код «приходит» прямо на
 * странице в виде карточки, стилизованной под письмо (учебная имитация).
 */
createConfHubApp({
  data() {
    return {
      email: '',
      code: '',
      newPassword: '',
      error: '',
      success: '',
      loading: false,
      // Данные «письма» с кодом
      letter: null, // { code, name, email, minutes }
    };
  },
  methods: {
    async requestCode() {
      this.error = '';
      this.success = '';
      this.loading = true;
      try {
        const data = await Api.post('auth/password/forgot', { email: this.email.trim() });
        this.letter = {
          code: data.code,
          name: data.name,
          email: this.email.trim(),
          minutes: data.expires_in_minutes,
        };
      } catch (err) {
        this.error = err.message;
        this.letter = null;
      } finally {
        this.loading = false;
      }
    },

    async resetPassword() {
      this.error = '';
      this.success = '';
      this.loading = true;
      try {
        await Api.post('auth/password/reset', {
          email: this.email.trim(),
          code: this.code.trim(),
          new_password: this.newPassword,
        });
        this.success = 'Пароль изменён. Теперь можно войти с новым паролем.';
        this.letter = null;
        this.code = '';
        this.newPassword = '';
      } catch (err) {
        this.error = err.message;
      } finally {
        this.loading = false;
      }
    },
  },
}).mount('#forgot-app');
