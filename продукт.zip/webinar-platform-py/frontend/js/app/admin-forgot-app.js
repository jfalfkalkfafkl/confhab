/**
 * Восстановление пароля администратора. Двухфакторное подтверждение:
 * код из серверного файла logs/admin-reset-codes.log + ключ восстановления
 * (если он был создан в админке). Код на экран не выводится.
 */
createConfHubApp({
  data() {
    return {
      step: 1,
      email: '',
      code: '',
      recoveryKey: '',
      newPassword: '',
      newPassword2: '',
      error: '',
      success: '',
      loading: false,
    };
  },
  methods: {
    async requestCode() {
      this.error = '';
      this.loading = true;
      try {
        await Api.post('auth/admin-password/forgot', { email: this.email.trim() });
        this.step = 2;
      } catch (err) {
        this.error = err.message;
      } finally {
        this.loading = false;
      }
    },

    async resetPassword() {
      this.error = '';
      if (this.newPassword !== this.newPassword2) {
        this.error = 'Пароли не совпадают';
        return;
      }
      this.loading = true;
      try {
        await Api.post('auth/admin-password/reset', {
          email: this.email.trim(),
          code: this.code.trim(),
          recovery_key: this.recoveryKey.trim(),
          new_password: this.newPassword,
        });
        this.success = 'Пароль изменён. Перенаправляем на страницу входа...';
        this.step = 3;
        setTimeout(() => { window.location.href = 'admin-login.html'; }, 1800);
      } catch (err) {
        this.error = err.message;
      } finally {
        this.loading = false;
      }
    },
  },
}).mount('#admin-forgot-app');
