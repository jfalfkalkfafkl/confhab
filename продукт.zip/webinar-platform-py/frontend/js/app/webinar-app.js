/**
 * Vue-приложение страницы вебинара.
 *
 * Объединяет: встроенную трансляцию внешнего сервиса, запись экрана и
 * завершение эфира (js/recorder.js), просмотр записи после завершения,
 * чат в реальном времени (опрос сервера раз в 3 секунды), интерактивные
 * опросы, сессию вопросов-ответов и панель управления для организатора
 * (статус, ссылка на запись, приглашение, участники, редактирование,
 * удаление).
 *
 * Жизненный цикл вебинара: «Запланирован» → «В эфире» (здесь доступна
 * запись экрана) → «Завершён» (здесь смотрят запись).
 */
createConfHubApp({
  mixins: [ScreenRecorderMixin],

  data() {
    return {
      webinarId: Number(new URLSearchParams(window.location.search).get('id')),
      user: null,
      webinar: null,

      tab: 'chat',

      // Предпросмотр камеры (локально, никуда не передаётся)
      camOn: false,
      camStream: null,
      camError: '',
      camMuted: false,

      // Чат
      messages: [],
      chatText: '',
      chatLocked: false,
      chatTimer: null,

      // Опросы
      polls: [],
      pollsError: '',
      pollForm: { question: '', options: ['', ''] },

      // Вопросы и ответы
      questions: [],
      questionText: '',
      answerDrafts: {},

      // Управление (организатор)
      recordingUrl: '',
      showParticipants: false,
      participants: [],
      participantsLoading: false,

      // Модальное окно редактирования
      showEdit: false,
      editError: '',
      editForm: { title: '', description: '', stream_url: '', scheduled_at: '', category_id: '' },

      inviteCopied: false,

      // Справочники и интеграции
      categories: [],
      integrations: { telemost: false },
      telemostBusy: false,
      liveStarted: false,
    };
  },

  computed: {
    isOwner() {
      return !!(this.webinar && this.webinar.is_owner);
    },
    isOrganizer() {
      return !!(this.user && this.user.role === 'organizer');
    },
    /** Чат, опросы и вопросы доступны владельцу, зарегистрированным и администратору. */
    canInteract() {
      return !!(this.user && this.webinar
        && (this.webinar.is_owner || this.webinar.is_registered || this.user.role === 'admin'));
    },
    sidebarViews() {
      if (!this.user) {
        return [
          { key: 'home', label: 'Главная', href: '/' },
          { key: 'login', label: 'Войти', href: 'login.html' },
          { key: 'register', label: 'Регистрация', href: 'register.html' },
        ];
      }
      return [
        { key: 'home', label: 'Главная', href: '/' },
        { key: 'scheduled', label: 'Запланировано', href: 'dashboard.html#scheduled' },
        { key: 'live', label: 'В эфире', href: 'dashboard.html#live' },
        { key: 'finished', label: 'Завершённые', href: 'dashboard.html#finished' },
        { key: 'profile', label: 'Профиль', href: 'profile.html' },
      ];
    },
    calendarUrl() {
      return `/api/v1/webinars/${this.webinarId}/calendar.ics`;
    },
    /** Подсказка под полем ссылки: какая площадка распознана. */
    editPlatform() {
      const v = Video.resolve(this.editForm.stream_url);
      return v.type === 'unknown' ? '' : v.label;
    },
    inviteUrl() {
      if (!this.webinar || !this.webinar.invite_token) return '';
      return inviteUrlFromToken(this.webinar.invite_token);
    },

    /**
     * Что показывать в области видео (пока не идёт запись экрана — тогда
     * шаблон сам показывает живой предпросмотр): плеер внешнего сервиса,
     * видеофайл записи, кнопку перехода (если сервис запрещает встраивание)
     * или заглушку.
     */
    videoState() {
      const w = this.webinar;
      if (!w) return { kind: 'placeholder', text: 'Загрузка...' };

      if (w.status === 'scheduled') {
        return { kind: 'placeholder', text: `Трансляция начнётся ${formatDateTime(w.scheduled_at)}` };
      }
      if (w.status === 'finished' && !w.recording_url) {
        return { kind: 'placeholder', text: 'Вебинар завершён. Запись пока не добавлена.' };
      }

      const url = (w.status === 'finished' && w.recording_url) ? w.recording_url : w.stream_url;
      if (!url) {
        return {
          kind: 'placeholder',
          text: this.isOwner
            ? 'Ссылка на трансляцию не указана — можно записать экран кнопкой ниже.'
            : 'Эфир идёт. Ссылка на трансляцию не указана — запись будет доступна после завершения эфира.',
        };
      }

      const video = Video.resolve(url);
      if (video.type === 'link') {
        return { kind: 'link', href: video.href, label: video.label };
      }
      if (video.type === 'file') {
        return { kind: 'file', src: video.src };
      }
      return { kind: 'embed', src: video.src };
    },
  },

  async mounted() {
    if (!this.webinarId) {
      window.location.href = '/';
      return;
    }

    // Страница вебинара открыта и гостям (из каталога): без входа видны описание и кнопка регистрации
    try {
      this.user = (await Api.get('auth/me')).user || null;
    } catch (e) {
      this.user = null;
    }

    await this.loadWebinar();
    if (this.canInteract) this.startLive();
    if (this.user && this.user.role === 'organizer') {
      Api.get('categories').then((d) => { this.categories = d.categories; }).catch(() => {});
      Api.get('integrations').then((d) => { this.integrations = d; }).catch(() => {});
    }
  },

  beforeUnmount() {
    if (this.chatTimer) clearInterval(this.chatTimer);
    this.stopCamera();
    // Запись экрана и защиту от случайного ухода со страницы гасит миксин.
  },

  methods: {
    // ---------------------- Предпросмотр камеры ----------------------
    /** «Увидеть себя»: включает веб-камеру и показывает картинку в блоке на странице. */
    async startCamera() {
      this.camError = '';
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        this.camError = 'Камера доступна только по https или на localhost.';
        return;
      }
      try {
        this.camStream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false,
        });
        this.camOn = true;
        await this.$nextTick();
        const v = this.$refs.camPreview;
        if (v) { v.srcObject = this.camStream; v.play().catch(() => {}); }
      } catch (err) {
        const map = {
          NotAllowedError: 'Доступ к камере запрещён. Разрешите её в значке замка рядом с адресом.',
          NotFoundError: 'Камера не найдена.',
          NotReadableError: 'Камера занята другим приложением (Телемост, Zoom…). Закройте его.',
        };
        this.camError = map[err.name] || ('Не удалось включить камеру: ' + err.message);
        this.stopCamera();
      }
    },
    stopCamera() {
      if (this.camStream) this.camStream.getTracks().forEach((t) => t.stop());
      this.camStream = null;
      this.camOn = false;
    },

    // ---------------------- Данные вебинара ----------------------
    async loadWebinar() {
      try {
        const { webinar } = await Api.get(`webinars/${this.webinarId}`);
        this.webinar = webinar;
        this.recordingUrl = webinar.recording_url || '';
        // Писать в чат могут только зарегистрированные участники и владелец
        this.chatLocked = !(webinar.is_owner || webinar.is_registered);
        document.title = `${webinar.title} — ConfHub`;
      } catch (err) {
        this.$toast.error(err.message);
        setTimeout(() => { window.location.href = this.user ? 'dashboard.html' : '/'; }, 1500);
      }
    },

    /** Загружает чат, опросы и вопросы и запускает обновление чата раз в 3 секунды. */
    async startLive() {
      if (this.liveStarted) return;
      this.liveStarted = true;
      await Promise.all([this.loadChat(), this.loadPolls(), this.loadQuestions()]);
      this.chatTimer = setInterval(this.loadChat, 3000);
    },

    async registerForWebinar() {
      if (!this.user) {  // гость: сначала вход, потом возвращение на эту страницу
        window.location.href = `login.html?next=${encodeURIComponent('webinar.html?id=' + this.webinarId)}`;
        return;
      }
      try {
        await Api.post(`webinars/${this.webinarId}/registrations`);
        await this.loadWebinar();
        this.chatLocked = false;
        this.$toast.success('Вы зарегистрированы! Напоминание появится в уведомлениях.');
        this.startLive();
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    async setStatus(status) {
      // Пока идёт запись экрана, статус меняется только через её завершение
      if (this.recActive || this.recSaving) {
        if (status === 'finished') {
          this.stopRecording();
        } else if (status !== 'live') {
          this.$toast.error('Сначала завершите эфир — идёт запись экрана.');
        }
        return;
      }
      try {
        await Api.patch(`webinars/${this.webinarId}`, { status });
        await this.loadWebinar();
        this.$toast.success('Статус вебинара изменён');
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    async saveRecording() {
      try {
        await Api.patch(`webinars/${this.webinarId}`, { recording_url: this.recordingUrl.trim() });
        await this.loadWebinar();
        this.$toast.success('Ссылка на запись сохранена');
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    // ------------------- Запись экрана и завершение эфира ----------------
    // Логика записи — в миксине ScreenRecorderMixin (js/recorder.js):
    // startRecording(id) → идёт запись, статус «В эфире»;
    // stopRecording() → файл загружается, статус «Завершён», запись доступна.

    /** «⏹ Завершить эфир»: с записью экрана — сохраняет её, без — просто завершает. */
    async finishLive() {
      if (this.recActive) {
        this.stopRecording();
        return;
      }
      if (!confirm('Завершить эфир? Вебинар перейдёт в статус «Завершён».')) return;
      await this.setStatus('finished');
    },

    // Обработчики миксина: после старта/сохранения обновляем карточку вебинара
    async onRecordingStarted() {
      await this.loadWebinar();
    },
    async onRecordingSaved() {
      await this.loadWebinar();
    },

    async copyInvite() {
      await copyToClipboard(this.inviteUrl);
      this.$toast.success('Ссылка-приглашение скопирована');
      this.inviteCopied = true;
      setTimeout(() => { this.inviteCopied = false; }, 1800);
    },

    async regenerateInvite() {
      if (!confirm('Старая ссылка перестанет работать. Создать новую ссылку-приглашение?')) return;
      try {
        await Api.post(`webinars/${this.webinarId}/invite`);
        await this.loadWebinar();
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    async deleteWebinar() {
      if (!confirm('Вебинар и все связанные данные (чат, опросы, вопросы, регистрации) будут удалены безвозвратно. Продолжить?')) return;
      try {
        await Api.del(`webinars/${this.webinarId}`);
        window.location.href = 'dashboard.html';
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    // ------------------------- Участники -------------------------
    async toggleParticipants() {
      this.showParticipants = !this.showParticipants;
      if (!this.showParticipants) return;

      this.participantsLoading = true;
      try {
        const { participants } = await Api.get(`webinars/${this.webinarId}/participants`);
        this.participants = participants;
      } catch (err) {
        this.$toast.error(err.message);
        this.showParticipants = false;
      } finally {
        this.participantsLoading = false;
      }
    },

    // ----------------------- Редактирование ----------------------
    openEdit() {
      this.editError = '';
      this.editForm = {
        title: this.webinar.title,
        description: this.webinar.description || '',
        stream_url: this.webinar.stream_url || '',
        scheduled_at: String(this.webinar.scheduled_at).replace(' ', 'T').slice(0, 16),
        category_id: this.webinar.category_id || '',
      };
      this.showEdit = true;
    },

    async saveEdit() {
      this.editError = '';
      try {
        await Api.patch(`webinars/${this.webinarId}`, {
          title: this.editForm.title.trim(),
          description: this.editForm.description.trim(),
          stream_url: this.editForm.stream_url.trim(),
          scheduled_at: this.editForm.scheduled_at,
          category_id: this.editForm.category_id || null,
        });
        this.showEdit = false;
        await this.loadWebinar();
        this.$toast.success('Изменения сохранены');
      } catch (err) {
        this.editError = err.message;
      }
    },

    /** Создаёт встречу в Яндекс Телемосте через API (нужен TELEMOST_OAUTH_TOKEN на сервере). */
    async createTelemostMeeting() {
      this.telemostBusy = true;
      try {
        const d = await Api.post('integrations/telemost', { title: this.editForm.title });
        this.editForm.stream_url = d.join_url;
        this.$toast.success('Встреча в Телемосте создана, ссылка вставлена');
      } catch (err) {
        this.$toast.error(err.message);
      } finally {
        this.telemostBusy = false;
      }
    },

    // ---------------------------- Чат ----------------------------
    async loadChat() {
      try {
        const { messages } = await Api.get(`webinars/${this.webinarId}/messages`, { after_id: 0 });
        const box = this.$refs.chatBox;
        const atBottom = !box || (box.scrollTop + box.clientHeight >= box.scrollHeight - 20);

        this.messages = messages;

        if (atBottom) {
          await nextTick();
          if (this.$refs.chatBox) {
            this.$refs.chatBox.scrollTop = this.$refs.chatBox.scrollHeight;
          }
        }
      } catch (err) {
        if (err.status === 403) this.chatLocked = true;
      }
    },

    async sendMessage() {
      const message = this.chatText.trim();
      if (!message) return;
      try {
        await Api.post(`webinars/${this.webinarId}/messages`, { message });
        this.chatText = '';
        await this.loadChat();
      } catch (err) {
        if (err.status === 403) {
          this.chatLocked = true;
        } else {
          this.$toast.error(err.message);
        }
      }
    },

    // --------------------------- Опросы --------------------------
    async loadPolls() {
      try {
        const { polls } = await Api.get(`webinars/${this.webinarId}/polls`);
        this.polls = polls;
      } catch (err) {
        this.pollsError = err.message;
      }
    },

    addPollOption() {
      if (this.pollForm.options.length < 10) this.pollForm.options.push('');
    },

    async createPoll() {
      this.pollsError = '';
      try {
        await Api.post(`webinars/${this.webinarId}/polls`, {
          question: this.pollForm.question.trim(),
          options: this.pollForm.options.map((o) => o.trim()).filter(Boolean),
        });
        this.pollForm = { question: '', options: ['', ''] };
        await this.loadPolls();
        this.$toast.success('Опрос создан');
      } catch (err) {
        this.pollsError = err.message;
      }
    },

    canVote(poll) {
      return poll.is_active && poll.voted_option_id === null;
    },

    async vote(poll, option) {
      if (!this.canVote(poll)) return;
      try {
        await Api.post(`polls/${poll.id}/votes`, { option_id: option.id });
        await this.loadPolls();
        this.$toast.success('Голос учтён');
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    async closePoll(poll) {
      if (!confirm('Завершить опрос? После этого голосовать будет нельзя.')) return;
      try {
        await Api.patch(`polls/${poll.id}`, { is_active: false });
        await this.loadPolls();
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    pollTotal(poll) {
      return poll.options.reduce((sum, o) => sum + o.votes, 0);
    },

    pollPercent(poll, option) {
      const total = this.pollTotal(poll);
      return total > 0 ? Math.round((option.votes / total) * 100) : 0;
    },

    // ------------------------ Вопросы (Q&A) ----------------------
    async loadQuestions() {
      try {
        const { questions } = await Api.get(`webinars/${this.webinarId}/questions`);
        this.questions = questions;
      } catch (err) {
        /* список останется пустым */
      }
    },

    async askQuestion() {
      const text = this.questionText.trim();
      if (!text) return;
      try {
        await Api.post(`webinars/${this.webinarId}/questions`, { question_text: text });
        this.questionText = '';
        await this.loadQuestions();
        this.$toast.success('Вопрос отправлен организатору');
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    async answerQuestion(question) {
      const answer = (this.answerDrafts[question.id] || '').trim();
      if (!answer) return;
      try {
        await Api.patch(`questions/${question.id}`, { answer_text: answer });
        this.answerDrafts[question.id] = '';
        await this.loadQuestions();
        this.$toast.success('Ответ опубликован, автор вопроса получит уведомление');
      } catch (err) {
        this.$toast.error(err.message);
      }
    },
  },
}).mount('#webinar-app');
