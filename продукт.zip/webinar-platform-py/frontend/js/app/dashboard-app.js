/**
 * Vue-приложение главной страницы (dashboard).
 *
 * Три вкладки по статусу вебинара:
 *   «Запланировано» — список предстоящих эфиров;
 *   «В эфире»       — студия с записью экрана (для организатора) и
 *                     список идущих сейчас эфиров;
 *   «Завершённые»   — завершённые эфиры, записи можно смотреть прямо
 *                     в карточке.
 *
 * Общие для всех вкладок: поиск по названию, фильтр «только мои»,
 * напоминание о ближайших вебинарах, создание вебинара (организатор),
 * копирование ссылки-приглашения. Запись экрана и завершение эфира
 * подключены из js/recorder.js (ScreenRecorderMixin).
 */
const DASHBOARD_VIEWS = ['scheduled', 'live', 'finished'];

createConfHubApp({
  mixins: [ScreenRecorderMixin],

  data() {
    return {
      user: null,
      webinars: [],
      loading: true,
      loadError: '',

      // Текущая вкладка задаётся клиентским роутером (js/router.js):
      // dashboard.html#/live (или короткая форма #live)
      view: 'scheduled',

      // Фильтры
      search: '',
      onlyMine: false,

      // Создание вебинара
      showCreate: false,
      createError: '',
      creating: false,
      form: { title: '', description: '', stream_url: '', scheduled_at: '', category_id: '' },
      categories: [],
      categoryFilter: '',
      integrations: { telemost: false },
      telemostBusy: false,

      // Студия эфира: выбранный для записи вебинар
      studioWebinarId: null,

      // Открытые плееры записей: { [webinarId]: true }
      openRecordings: {},
      copiedToken: null,
    };
  },

  computed: {
    isOrganizer() {
      return this.user && this.user.role === 'organizer';
    },

    formPlatform() {
      const v = Video.resolve(this.form.stream_url);
      return v.type === 'unknown' ? '' : v.label;
    },

    isAdmin() {
      return !!this.user && this.user.role === 'admin';
    },

    /** Количество вебинаров по статусам (без учёта фильтров) — для бейджей. */
    counts() {
      const counts = { scheduled: 0, live: 0, finished: 0 };
      this.webinars.forEach((w) => { if (counts[w.status] !== undefined) counts[w.status]++; });
      return counts;
    },

    views() {
      return [
        { key: 'scheduled', label: 'Запланировано', badge: this.counts.scheduled || '' },
        { key: 'live', label: 'В эфире', badge: this.counts.live || '', live: true },
        { key: 'finished', label: 'Завершённые', badge: this.counts.finished || '' },
        { key: 'profile', label: 'Профиль', href: 'profile.html' },
        ...(this.isAdmin ? [{ key: 'admin', label: 'Администрирование', href: 'admin.html' }] : []),
      ];
    },

    viewTitle() {
      return {
        scheduled: 'Запланировано',
        live: 'В эфире',
        finished: 'Завершённые вебинары',
      }[this.view];
    },

    /** Вебинары нужного статуса с учётом поиска и фильтра «только мои». */
    scheduledList() {
      return this.listByStatus('scheduled').sort(byDateAsc);
    },
    liveList() {
      return this.listByStatus('live').sort(byDateAsc);
    },
    finishedList() {
      return this.listByStatus('finished').sort(byDateDesc);
    },

    /** Вебинары организатора, из которых можно начать эфир (сначала идущие). */
    studioOptions() {
      if (!this.user) return [];
      return this.webinars
        .filter((w) => w.organizer_id === this.user.id && (w.status === 'scheduled' || w.status === 'live'))
        .sort((a, b) => (a.status === 'live' ? 0 : 1) - (b.status === 'live' ? 0 : 1) || byDateAsc(a, b));
    },

    /** Название вебинара, для которого сейчас идёт запись. */
    recordingTitle() {
      const w = this.webinars.find((item) => item.id === this.recWebinarId);
      return w ? w.title : '';
    },

    /** Вебинары, которые начнутся в ближайшие 24 часа. */
    soonWebinars() {
      const now = Date.now();
      return this.webinars.filter((w) => {
        if (w.status !== 'scheduled') return false;
        if (!(w.is_registered || w.organizer_id === this.user.id)) return false;
        const start = new Date(String(w.scheduled_at).replace(' ', 'T')).getTime();
        const diffHours = (start - now) / 3600000;
        return diffHours >= 0 && diffHours <= 24;
      });
    },
  },

  async mounted() {
    this.user = await requireUser();
    if (!this.user) return;

    HashRouter.init({
      routes: DASHBOARD_VIEWS.map((path) => ({ path })),
      fallback: 'scheduled',
      context: this.user,
      onChange: (path) => { this.view = path; },
    });

    await this.loadWebinars();
    Api.get('categories').then((d) => { this.categories = d.categories; }).catch(() => {});
    Api.get('integrations').then((d) => { this.integrations = d; }).catch(() => {});
  },

  methods: {
    async loadWebinars() {
      this.loadError = '';
      try {
        const { webinars } = await Api.get('webinars');
        this.webinars = webinars;
        this.ensureStudioSelection();
      } catch (err) {
        this.loadError = err.message;
      } finally {
        // Индикатор «Загрузка...» нужен только при первом заходе. Повторные
        // обновления списка идут молча, чтобы не сбрасывать студию во
        // время записи.
        this.loading = false;
      }
    },

    listByStatus(status) {
      const search = this.search.trim().toLowerCase();
      return this.webinars.filter((w) => {
        if (w.status !== status) return false;
        if (search && !w.title.toLowerCase().includes(search)) return false;
        if (this.onlyMine && !(w.organizer_id === this.user.id || w.is_registered)) return false;
        if (this.categoryFilter && !(w.category && w.category.slug === this.categoryFilter)) return false;
        return true;
      });
    },

    /** Переход между вкладками — через роутер (история браузера работает). */
    selectView(key) {
      HashRouter.go(key);
    },

    isOwner(w) {
      return this.user && this.user.id === w.organizer_id;
    },

    /** Если выбранного вебинара больше нет в списке — берём первый доступный. */
    ensureStudioSelection() {
      if (this.studioOptions.some((w) => w.id === this.studioWebinarId)) return;
      this.studioWebinarId = this.studioOptions.length ? this.studioOptions[0].id : null;
    },

    /** «🎥 В эфир» на карточке запланированного вебинара: открывает студию с этим вебинаром. */
    goLive(w) {
      this.studioWebinarId = w.id;
      this.selectView('live');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },

    // Обработчики миксина записи экрана
    async onRecordingStarted() {
      await this.loadWebinars();
    },
    async onRecordingSaved() {
      await this.loadWebinars();
    },

    /**
     * «Завершить эфир» на карточке идущего вебинара. Если для него идёт
     * запись экрана — останавливаем её (файл сохранится, вебинар завершится
     * сам); иначе просто переводим вебинар в статус «Завершён».
     */
    async finishLive(w) {
      if (this.recActive && this.recWebinarId === w.id) {
        this.stopRecording();
        return;
      }
      if (!confirm(`Завершить эфир «${w.title}»? Он переместится во вкладку «Завершённые».`)) return;
      try {
        await Api.patch(`webinars/${w.id}`, { status: 'finished' });
        await this.loadWebinars();
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    async createWebinar() {
      this.createError = '';
      this.creating = true;
      try {
        await Api.post('webinars', {
          title: this.form.title.trim(),
          description: this.form.description.trim(),
          stream_url: this.form.stream_url.trim(),
          scheduled_at: this.form.scheduled_at,
          category_id: this.form.category_id || null,
        });
        this.form = { title: '', description: '', stream_url: '', scheduled_at: '', category_id: '' };
        this.$toast.success('Вебинар создан');
        this.showCreate = false;
        await this.loadWebinars();
        this.selectView('scheduled');
      } catch (err) {
        this.createError = err.message;
      } finally {
        this.creating = false;
      }
    },

    async createTelemostMeeting() {
      this.telemostBusy = true;
      try {
        const d = await Api.post('integrations/telemost', { title: this.form.title });
        this.form.stream_url = d.join_url;
        this.$toast.success('Встреча в Телемосте создана, ссылка вставлена');
      } catch (err) {
        this.$toast.error(err.message);
      } finally {
        this.telemostBusy = false;
      }
    },

    async registerForWebinar(w) {
      try {
        await Api.post(`webinars/${w.id}/registrations`);
        await this.loadWebinars();
        this.$toast.success(`Вы зарегистрированы на «${w.title}»`);
      } catch (err) {
        this.$toast.error(err.message);
      }
    },

    async copyInvite(w) {
      await copyToClipboard(inviteUrlFromToken(w.invite_token));
      this.$toast.success('Ссылка-приглашение скопирована');
      this.copiedToken = w.id;
      setTimeout(() => {
        if (this.copiedToken === w.id) this.copiedToken = null;
      }, 1800);
    },

    /** Показать/скрыть плеер записи; сервисы без встраивания открываются в новой вкладке. */
    toggleRecording(w) {
      const video = Video.resolve(w.recording_url);
      if (video.type === 'link') {
        window.open(video.href, '_blank', 'noopener');
        return;
      }
      this.openRecordings[w.id] = !this.openRecordings[w.id];
    },

    /** «▶ Смотреть запись» после завершения эфира: переход во вкладку «Завершённые» и запуск плеера. */
    async watchRecording(webinarId) {
      const w = this.webinars.find((item) => item.id === webinarId);
      this.selectView('finished');
      if (!w || !w.recording_url) return;

      const video = Video.resolve(w.recording_url);
      if (video.type === 'link') {
        window.open(video.href, '_blank', 'noopener');
        return;
      }
      this.openRecordings[webinarId] = true;

      await nextTick();
      const card = document.getElementById('card-' + webinarId);
      if (card) card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    },
  },
}).mount('#dashboard-app');

/** Сортировка по дате проведения: ближайшие первыми. */
function byDateAsc(a, b) {
  return String(a.scheduled_at).localeCompare(String(b.scheduled_at));
}

/** Сортировка по дате проведения: свежие первыми. */
function byDateDesc(a, b) {
  return byDateAsc(b, a);
}
