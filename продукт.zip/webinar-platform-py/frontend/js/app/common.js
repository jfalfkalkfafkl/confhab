/**
 * Общие части Vue-приложения ConfHub.
 *
 * Фронтенд построен на Vue 3 (сборка vue.global.prod.js подключается
 * локально из js/vendor — интернет и сборщик не нужны). Каждая страница
 * — отдельное Vue-приложение, которое обращается к REST API (js/api.js).
 *
 * Важно для безопасности: Vue подставляет данные через текстовые узлы,
 * то есть автоматически экранирует HTML. Поэтому XSS через имя
 * пользователя, сообщение в чате или название вебинара невозможен —
 * директива v-html в проекте не используется нигде.
 */

const { createApp, ref, reactive, computed, onMounted, onBeforeUnmount, nextTick } = Vue;

/**
 * Всплывающие уведомления (тосты). Текст вставляется через textContent — HTML из данных не исполняется.
 *   Toast.show('Сохранено', 'success');  // success | error | info
 */
const Toast = {
  host: null,
  show(message, type = 'info', ms = 4200) {
    if (!this.host) {
      this.host = document.createElement('div');
      this.host.className = 'toast-host';
      this.host.setAttribute('role', 'status');
      this.host.setAttribute('aria-live', 'polite');
      document.body.appendChild(this.host);
    }
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    const text = document.createElement('span');
    text.textContent = message;
    const close = document.createElement('button');
    close.className = 't-close';
    close.type = 'button';
    close.setAttribute('aria-label', 'Закрыть');
    close.textContent = '×';
    el.append(text, close);
    const remove = () => {
      el.classList.add('leaving');
      setTimeout(() => el.remove(), 260);
    };
    close.addEventListener('click', remove);
    this.host.appendChild(el);
    while (this.host.children.length > 4) this.host.firstChild.remove();
    setTimeout(remove, ms);
  },
  success(m) { this.show(m, 'success'); },
  error(m) { this.show(m, 'error', 6000); },
};

/** Подписи ролей пользователей. */
const ROLE_LABELS = { organizer: 'Организатор', participant: 'Участник', admin: 'Администратор' };

/** Колокольчик уведомлений: счётчик непрочитанных, список, «прочитать все»; обновляется раз в 30 секунд. */
const NotificationBell = {
  data() {
    return { open: false, items: [], unread: 0, timer: null, lastId: null };
  },
  template: `
    <div class="bell-wrap">
      <button class="bell" type="button" aria-label="Уведомления" :aria-expanded="open" data-tip="Уведомления" @click.stop="toggle">
        🔔<span class="dot" v-if="unread">{{ unread > 99 ? '99+' : unread }}</span>
      </button>
      <div class="bell-menu" v-if="open" role="dialog" aria-label="Уведомления" @click.stop>
        <div class="bell-head">
          <span>Уведомления</span>
          <button class="btn small ghost" type="button" v-if="unread" @click="readAll">Прочитать все</button>
        </div>
        <div class="bell-list">
          <div class="bell-empty" v-if="!items.length">Пока ничего нового</div>
          <component :is="n.webinar_id ? 'a' : 'div'" class="bell-item" :class="{ unread: !n.is_read }"
                     v-for="n in items" :key="n.id" :href="n.webinar_id ? 'webinar.html?id=' + n.webinar_id : null">
            {{ n.text }}<small>{{ fmt(n.created_at) }}</small>
          </component>
        </div>
      </div>
    </div>
  `,
  mounted() {
    this.load();
    this.timer = setInterval(this.load, 30000);
    document.addEventListener('click', this.close);
  },
  beforeUnmount() {
    clearInterval(this.timer);
    document.removeEventListener('click', this.close);
  },
  methods: {
    fmt: formatDateTime,
    close() { this.open = false; },
    toggle() { this.open = !this.open; },
    async load() {
      try {
        const d = await Api.get('notifications', { limit: 15 });
        // Всплывающий тост о новых уведомлениях, появившихся после первой загрузки
        if (this.lastId !== null) {
          d.notifications.filter((n) => n.id > this.lastId && !n.is_read).slice(0, 2).forEach((n) => Toast.show(n.text));
        }
        this.lastId = d.notifications.length ? Math.max(...d.notifications.map((n) => n.id)) : (this.lastId || 0);
        this.items = d.notifications;
        this.unread = d.unread;
      } catch (e) { /* без сети просто не обновляем */ }
    },
    async readAll() {
      try {
        await Api.post('notifications/read', {});
        this.items.forEach((n) => { n.is_read = true; });
        this.unread = 0;
      } catch (e) { Toast.error(e.message); }
    },
  },
};

/** Плашка с именем пользователя, ролью, колокольчиком и кнопкой выхода. */
const UserChip = {
  props: { user: { type: Object, required: true } },
  template: `
    <div id="userChip">
      <notification-bell></notification-bell>
      <span class="name">{{ user.name }}</span>
      <span class="role-badge">{{ roleLabels[user.role] || user.role }}</span>
      <button class="btn small ghost" type="button" @click="logout">Выйти</button>
    </div>
  `,
  data() {
    return { roleLabels: ROLE_LABELS };
  },
  methods: {
    async logout() {
      try {
        await Api.post('auth/logout');
      } catch (e) {
        /* всё равно уходим на страницу входа */
      }
      window.location.href = 'login.html';
    },
  },
};

/**
 * Боковое меню приложения. У пункта может быть необязательный бейдж
 * (badge — число вебинаров в разделе, live — красная подсветка для «В эфире»).
 */
const AppSidebar = {
  props: {
    active: { type: String, default: '' },
    views: { type: Array, default: () => [] },
  },
  emits: ['select'],
  template: `
    <aside class="sidebar">
      <div class="brand">Conf<span>Hub</span></div>
      <ul class="nav-list">
        <li v-for="item in views" :key="item.key">
          <a v-if="item.href" :href="item.href" :class="{ active: active === item.key }">
            <span>{{ item.label }}</span>
            <span v-if="item.badge" class="nav-badge" :class="{ live: item.live }">{{ item.badge }}</span>
          </a>
          <a v-else href="#" :class="['nav-link', { active: active === item.key }]"
             @click.prevent="$emit('select', item.key)">
            <span>{{ item.label }}</span>
            <span v-if="item.badge" class="nav-badge" :class="{ live: item.live }">{{ item.badge }}</span>
          </a>
        </li>
      </ul>
      <div class="sidebar-footer">Платформа для вебинаров<br>и онлайн-конференций</div>
    </aside>
  `,
};

/**
 * Плеер записи вебинара по ссылке: собственный видеофайл (запись экрана) —
 * через <video>, YouTube/Vimeo/RuTube и т.п. — через <iframe>, сервисы
 * встреч, которые нельзя встроить, — кнопкой-переходом.
 */
const VideoPlayer = {
  props: { url: { type: String, required: true } },
  computed: {
    video() {
      return Video.resolve(this.url);
    },
  },
  template: `
    <div class="video-wrap">
      <video v-if="video.type === 'file'" controls preload="metadata" :src="video.src"
             @loadedmetadata="$fixDuration"></video>
      <iframe v-else-if="video.type === 'embed'" :src="video.src"
              allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>
      <div class="video-placeholder" v-else>
        <a class="btn accent" :href="video.href || url" target="_blank" rel="noopener">Открыть запись</a>
      </div>
    </div>
  `,
};

/** Пагинация: «‹ 1 … 4 [5] 6 … 20 ›». Событие change(номер страницы). */
const Pager = {
  props: { page: { type: Number, default: 1 }, pages: { type: Number, default: 1 } },
  emits: ['change'],
  computed: {
    list() {
      const { page, pages } = this;
      const set = new Set([1, pages, page - 1, page, page + 1]);
      const nums = [...set].filter((n) => n >= 1 && n <= pages).sort((a, b) => a - b);
      const out = [];
      nums.forEach((n, i) => {
        if (i && n - nums[i - 1] > 1) out.push('…');
        out.push(n);
      });
      return out;
    },
  },
  template: `
    <nav class="pager" v-if="pages > 1" aria-label="Страницы">
      <button type="button" :disabled="page <= 1" aria-label="Предыдущая страница" @click="$emit('change', page - 1)">‹</button>
      <template v-for="(n, i) in list" :key="i">
        <span class="gap" v-if="n === '…'">…</span>
        <button v-else type="button" :class="{ current: n === page }" :aria-current="n === page ? 'page' : null"
                @click="$emit('change', n)">{{ n }}</button>
      </template>
      <button type="button" :disabled="page >= pages" aria-label="Следующая страница" @click="$emit('change', page + 1)">›</button>
    </nav>
  `,
};

/** Обложка карточки вебинара: одно из 4 оптимизированных изображений (WebP, 480/800 px, lazy-load). */
const WebinarCover = {
  props: { id: { type: Number, required: true } },
  computed: {
    n() { return ((this.id - 1) % 4 + 4) % 4 + 1; },
  },
  template: `
    <picture>
      <img :src="'img/cards/cover' + n + '-480.webp'"
           :srcset="'img/cards/cover' + n + '-480.webp 480w, img/cards/cover' + n + '-800.webp 800w'"
           sizes="(max-width: 640px) 100vw, 360px" width="480" height="270" alt="" loading="lazy" decoding="async">
    </picture>
  `,
};

/** Регистрирует общие компоненты и глобальные утилиты в приложении. */
function createConfHubApp(options) {
  const app = createApp(options);
  app.component('user-chip', UserChip);
  app.component('app-sidebar', AppSidebar);
  app.component('video-player', VideoPlayer);
  app.component('notification-bell', NotificationBell);
  app.component('pager', Pager);
  app.component('webinar-cover', WebinarCover);
  app.config.globalProperties.$toast = Toast;
  app.config.globalProperties.$formatDateTime = formatDateTime;
  app.config.globalProperties.$statusLabels = STATUS_LABELS;
  // Обработчик loadedmetadata для <video>: включает перемотку у записей экрана
  app.config.globalProperties.$fixDuration = (event) => fixVideoDuration(event.target);
  return app;
}

/** Загружает текущего пользователя; при отсутствии — уводит на вход. */
async function requireUser(loginPage = 'login.html') {
  try {
    const { user } = await Api.get('auth/me');
    if (!user) {
      window.location.href = loginPage;
      return null;
    }
    return user;
  } catch (e) {
    window.location.href = loginPage;
    return null;
  }
}

/**
 * Как requireUser(), но дополнительно проверяет роль: пользователь без
 * нужной роли уходит на dashboard.html (защита на сервере всё равно
 * остаётся — API вернёт 403).
 */
async function requireRole(role, loginPage = 'login.html') {
  const user = await requireUser(loginPage);
  if (!user) return null;
  if (user.role !== role) {
    window.location.href = 'dashboard.html';
    return null;
  }
  return user;
}

/** Абсолютная ссылка-приглашение по токену вебинара. */
function inviteUrlFromToken(token) {
  return `${window.location.origin}/join?token=${encodeURIComponent(token)}`;
}

/** Абсолютная ссылка на файл в public/ (например, загруженную запись экрана). */
function absoluteUrlFromPublicPath(relativePath) {
  return `${window.location.origin}/${String(relativePath).replace(/^\/+/, '')}`;
}

/** Копирование в буфер обмена с запасным вариантом через prompt(). */
async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (e) {
    window.prompt('Скопируйте ссылку-приглашение:', text);
    return false;
  }
}
