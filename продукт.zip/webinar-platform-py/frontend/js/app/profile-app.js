/**
 * Vue-приложение страницы профиля: просмотр данных и статистики,
 * изменение имени и смена пароля (с проверкой текущего).
 */
createConfHubApp({
  data() {
    return {
      user: null,
      stats: { organized_count: 0, registered_count: 0 },

      name: '',
      profileError: '',
      profileInfo: '',

      currentPassword: '',
      newPassword: '',
      passwordError: '',
      passwordInfo: '',
    };
  },

  computed: {
    views() {
      return [
        { key: 'scheduled', label: 'Запланировано', href: 'dashboard.html#scheduled' },
        { key: 'live', label: 'В эфире', href: 'dashboard.html#live' },
        { key: 'finished', label: 'Завершённые', href: 'dashboard.html#finished' },
        { key: 'profile', label: 'Профиль', href: 'profile.html' },
        ...(this.user && this.user.role === 'admin'
          ? [{ key: 'admin', label: 'Администрирование', href: 'admin.html' }]
          : []),
      ];
    },

    roleLabel() {
      if (!this.user) return '';
      return ROLE_LABELS[this.user.role] || this.user.role;
    },
  },

  async mounted() {
    this.user = await requireUser();
    if (!this.user) return;
    await this.loadProfile();
  },

  methods: {
    async loadProfile() {
      try {
        const data = await Api.get('profile');
        this.user = data.user;
        this.stats = data.stats;
        this.name = data.user.name;
      } catch (err) {
        this.profileError = err.message;
      }
    },

    async saveName() {
      this.profileError = '';
      this.profileInfo = '';
      try {
        const data = await Api.patch('profile', { name: this.name.trim() });
        this.user = data.user;
        this.profileInfo = 'Имя сохранено';
      } catch (err) {
        this.profileError = err.message;
      }
    },

    async changePassword() {
      this.passwordError = '';
      this.passwordInfo = '';
      try {
        await Api.post('profile/password', {
          current_password: this.currentPassword,
          new_password: this.newPassword,
        });
        this.currentPassword = '';
        this.newPassword = '';
        this.passwordInfo = 'Пароль изменён';
      } catch (err) {
        this.passwordError = err.message;
      }
    },
  },
}).mount('#profile-app');
