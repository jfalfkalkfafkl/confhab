/**
 * Vue-приложения страниц входа и регистрации.
 *
 * После успешного входа/регистрации сервер может вернуть
 * joined_webinar_id — это значит, что пользователь пришёл по
 * ссылке-приглашению и уже записан на вебинар, поэтому его сразу
 * переносим на страницу этого вебинара.
 */

/** Безопасный адрес возврата ?next=: только относительная ссылка на страницу проекта (защита от open redirect). */
function safeNext() {
  const next = new URLSearchParams(window.location.search).get('next') || '';
  return /^[a-z-]+\.html(\?[\w=&%-]*)?$/i.test(next) ? next : null;
}

function redirectAfterAuth(data) {
  const next = safeNext();
  if (next) {
    window.location.href = next;
  } else if (data && data.joined_webinar_id) {
    window.location.href = `webinar.html?id=${data.joined_webinar_id}`;
  } else {
    window.location.href = 'dashboard.html';
  }
}

// ---------------------------- Вход -----------------------------------
if (document.getElementById('login-app')) {
  createConfHubApp({
    data() {
      return {
        email: '',
        password: '',
        error: '',
        loading: false,
        search: window.location.search,
        // Показываем подсказку, если пользователь перешёл по приглашению
        invite: new URLSearchParams(window.location.search).get('invite') === '1',
      };
    },
    methods: {
      async submit() {
        this.error = '';
        this.loading = true;
        try {
          const data = await Api.post('auth/login', {
            email: this.email.trim(),
            password: this.password,
          });
          redirectAfterAuth(data);
        } catch (err) {
          this.error = err.message;
        } finally {
          this.loading = false;
        }
      },
    },
  }).mount('#login-app');
}

// ------------------- Вход в режим администратора ---------------------
if (document.getElementById('admin-login-app')) {
  createConfHubApp({
    data() {
      return { email: '', password: '', error: '', loading: false };
    },
    async mounted() {
      // Уже вошёл администратор — сразу в панель
      try {
        const { user } = await Api.get('auth/me');
        if (user && user.role === 'admin') window.location.href = 'admin.html';
      } catch (e) { /* остаёмся на форме входа */ }
    },
    methods: {
      async submit() {
        this.error = '';
        this.loading = true;
        try {
          await Api.post('auth/admin-login', {
            email: this.email.trim(),
            password: this.password,
          });
          window.location.href = 'admin.html';
        } catch (err) {
          this.error = err.message;
        } finally {
          this.loading = false;
        }
      },
    },
  }).mount('#admin-login-app');
}

// ------------------------- Регистрация -------------------------------
if (document.getElementById('register-app')) {
  createConfHubApp({
    data() {
      return {
        name: '',
        email: '',
        password: '',
        role: 'participant',
        error: '',
        loading: false,
        search: window.location.search,
      };
    },
    methods: {
      async submit() {
        this.error = '';
        this.loading = true;
        try {
          const data = await Api.post('auth/register', {
            name: this.name.trim(),
            email: this.email.trim(),
            password: this.password,
            role: this.role,
          });
          redirectAfterAuth(data);
        } catch (err) {
          this.error = err.message;
        } finally {
          this.loading = false;
        }
      },
    },
  }).mount('#register-app');
}
