/**
 * Главная страница (index.html).
 *  1. Кнопки шапки/слайдера подстраиваются под вход пользователя (гость → «Войти», вошёл → «В кабинет»).
 *  2. Каталог (Vue): поиск с задержкой 350 мс, категории, фильтры, сортировка и пагинация — всё на сервере
 *     (GET /api/v1/webinars); состояние фильтров хранится в адресной строке, поэтому ссылкой можно поделиться.
 *  3. Анимации при прокрутке (AOS), бургер-меню на телефоне.
 */

// ---------- 1. Состояние входа (без Vue — чтобы слайдер и шапка работали сразу) ----------
(async function authAware() {
  let user = null;
  try {
    user = (await Api.get('auth/me')).user;
  } catch (e) { /* гость */ }
  document.querySelectorAll('[data-auth="guest"]').forEach((el) => { el.hidden = !!user; });
  document.querySelectorAll('[data-auth="user"]').forEach((el) => { el.hidden = !user; });
})();

// ---------- 3. Бургер-меню и AOS ----------
(function menuAndAnimations() {
  const burger = document.getElementById('burger');
  const nav = document.getElementById('siteNav');
  if (burger && nav) {
    burger.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      burger.setAttribute('aria-expanded', String(open));
      burger.textContent = open ? '✕' : '☰';
    });
    nav.addEventListener('click', (e) => {
      if (e.target.tagName === 'A') { nav.classList.remove('open'); burger.textContent = '☰'; burger.setAttribute('aria-expanded', 'false'); }
    });
  }
  if (window.AOS) {
    AOS.init({ duration: 650, easing: 'ease-out-cubic', once: true, offset: 40,
      disable: () => window.matchMedia('(prefers-reduced-motion: reduce)').matches });
  }
})();

// ---------- 2. Каталог ----------
const DEFAULT_FILTERS = { q: '', category: '', status: '', platform: '', sort: 'date_asc' };

createConfHubApp({
  data() {
    const params = new URLSearchParams(location.search);
    const filters = { ...DEFAULT_FILTERS };
    Object.keys(filters).forEach((k) => { if (params.get(k)) filters[k] = params.get(k); });
    return {
      filters,
      page: Math.max(1, Number(params.get('page')) || 1),
      perPage: window.matchMedia('(max-width: 640px)').matches ? 6 : 9,
      items: [],
      meta: { total: 0, page: 1, pages: 1, per_page: 9 },
      categories: [],
      stat: { total: 0, live: 0, organizers: 0, registrations: 0 },
      loading: true,
      error: '',
      debounce: null,
      requestId: 0,
    };
  },

  computed: {
    hasFilters() {
      return Object.keys(DEFAULT_FILTERS).some((k) => k !== 'sort' && this.filters[k]) || this.filters.sort !== DEFAULT_FILTERS.sort;
    },
  },

  watch: {
    // Поиск — с задержкой, остальные фильтры — сразу; любое изменение возвращает на первую страницу
    'filters.q'() { clearTimeout(this.debounce); this.debounce = setTimeout(() => this.refilter(), 350); },
    'filters.status'() { this.refilter(); },
    'filters.platform'() { this.refilter(); },
    'filters.sort'() { this.refilter(); },
  },

  mounted() {
    this.$nextTick(() => { if (window.AOS) AOS.refreshHard(); });   // Vue пересоздал узлы — AOS пересканирует разметку
    this.load();
    Api.get('categories').then((d) => { this.categories = d.categories; }).catch(() => {});
    Api.get('public/summary').then((d) => { this.animateStats(d); }).catch(() => {});
  },

  methods: {
    shorten(text) {
      const t = (text || 'Без описания').trim();
      return t.length > 120 ? t.slice(0, 117) + '…' : t;
    },

    refilter() {
      this.page = 1;
      this.load();
    },

    setCategory(slug) {
      this.filters.category = slug;
      this.refilter();
    },

    resetFilters() {
      this.filters = { ...DEFAULT_FILTERS };
      this.refilter();
    },

    goPage(n) {
      this.page = n;
      this.load();
      document.getElementById('catalog').scrollIntoView({ behavior: 'smooth', block: 'start' });
    },

    async load() {
      const id = ++this.requestId;       // защита от «гонки»: берём только ответ последнего запроса
      this.loading = true;
      this.error = '';
      const query = { page: this.page, per_page: this.perPage };
      Object.entries(this.filters).forEach(([k, v]) => { if (v) query[k] = v; });
      try {
        const d = await Api.get('webinars', query);
        if (id !== this.requestId) return;
        this.items = d.webinars;
        this.meta = { total: d.total, page: d.page, pages: d.pages, per_page: d.per_page };
        this.page = d.page;
        this.syncUrl();
      } catch (e) {
        if (id !== this.requestId) return;
        this.error = e.message || 'Не удалось загрузить каталог';
      } finally {
        if (id === this.requestId) this.loading = false;
      }
    },

    /** Фильтры → адресная строка (без перезагрузки страницы). */
    syncUrl() {
      const params = new URLSearchParams();
      Object.entries(this.filters).forEach(([k, v]) => { if (v && v !== DEFAULT_FILTERS[k]) params.set(k, v); });
      if (this.page > 1) params.set('page', this.page);
      const qs = params.toString();
      history.replaceState(null, '', location.pathname + (qs ? '?' + qs : '') + location.hash);
    },

    /** Плавный счётчик цифр в полосе статистики. */
    animateStats(target) {
      const keys = ['total', 'live', 'organizers', 'registrations'];
      const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (reduce) { keys.forEach((k) => { this.stat[k] = target[k]; }); return; }
      const start = performance.now();
      const step = (now) => {
        const t = Math.min(1, (now - start) / 900);
        keys.forEach((k) => { this.stat[k] = Math.round(target[k] * (1 - Math.pow(1 - t, 3))); });
        if (t < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    },
  },
}).mount('#catalog-app');
