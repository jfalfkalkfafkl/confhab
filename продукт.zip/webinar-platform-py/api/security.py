"""Сессии Django для FastAPI, CSRF, rate limiting, журнал безопасности, проверка ролей."""
import logging
import time
from datetime import timedelta

from django.conf import settings
from django.contrib.auth import BACKEND_SESSION_KEY, HASH_SESSION_KEY, SESSION_KEY
from django.contrib.sessions.backends.db import SessionStore
from django.db import transaction
from django.utils import timezone
from fastapi import Depends, Request
from starlette.concurrency import run_in_threadpool
from starlette.middleware.base import BaseHTTPMiddleware
import hashlib
import hmac
import secrets

from core.models import RateLimitHit, SecurityLog, User, Webinar, Registration

from .errors import ApiError

log = logging.getLogger("api.security")


# ---------------------------------------------------------------------
# Сессии (те же, что у Django: таблица django_session, cookie CONFHUB_SESSID)
# ---------------------------------------------------------------------
class DjangoSessionMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        cookie_key = request.cookies.get(settings.SESSION_COOKIE_NAME)
        session = await run_in_threadpool(self._open, cookie_key)
        request.state.session = session

        response = await call_next(request)

        await run_in_threadpool(self._close, request, response, session, cookie_key)
        return response

    @staticmethod
    def _open(key):
        session = SessionStore(key)
        if SESSION_KEY in session:
            now = int(time.time())
            last_seen = int(session.get("last_activity", now))
            login_time = int(session.get("login_time", now))
            if (now - last_seen) > settings.SESSION_IDLE_TIMEOUT or \
                    (now - login_time) > settings.SESSION_ABSOLUTE_TIMEOUT:
                session.flush()          # сессия истекла
            elif now - last_seen > 60:
                session["last_activity"] = now
        return session

    @staticmethod
    def _close(request: Request, response, session, cookie_key):
        if session.is_empty():
            if cookie_key:
                response.delete_cookie(settings.SESSION_COOKIE_NAME, path="/")
            return
        if session.modified:
            session.save()
        if session.session_key and session.session_key != cookie_key:
            https = request.url.scheme == "https" or settings.SESSION_COOKIE_SECURE
            response.set_cookie(
                settings.SESSION_COOKIE_NAME, session.session_key, path="/",
                httponly=True, samesite="lax", secure=bool(https),
            )


def get_session(request: Request):
    return request.state.session


# ---------------------------------------------------------------------
# CSRF
# ---------------------------------------------------------------------
def csrf_token(session) -> str:
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_hex(32)
        session["csrf_token"] = token
    return token


async def csrf_guard(request: Request) -> None:
    """Глобальная защита: POST/PATCH/PUT/DELETE обязаны прислать действующий CSRF-токен."""
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return
    sent = request.headers.get("x-csrf-token")
    if sent is None and "application/json" in request.headers.get("content-type", ""):
        try:
            payload = await request.json()
            sent = payload.get("csrf_token") if isinstance(payload, dict) else None
        except Exception:
            sent = None
    expected = request.state.session.get("csrf_token") or ""
    if not expected or not isinstance(sent, str) or not hmac.compare_digest(expected, sent):
        await run_in_threadpool(security_log, request, "csrf_failed", None, request.url.path)
        raise ApiError("Недействительный CSRF-токен. Обновите страницу и повторите действие.", 419)


# ---------------------------------------------------------------------
# IP, журнал безопасности, rate limit
# ---------------------------------------------------------------------
def client_ip(request: Request) -> str:
    return (request.client.host if request.client else "0.0.0.0")[:45]


def security_log(request: Request, event: str, user_id: int | None = None, details: str = "") -> None:
    try:
        SecurityLog.objects.create(
            user_id=user_id, event=event[:50], ip=client_ip(request),
            user_agent=request.headers.get("user-agent", "")[:255], details=details[:255],
        )
    except Exception as exc:  # журнал не должен ронять запрос
        log.error("security_log: %s", exc)


def rate_limit_check(action: str, key: str, limit: int, window: int) -> bool:
    try:
        bucket = f"{action}|{key}"[:190]
        now = timezone.now()
        if secrets.randbelow(20) == 0:
            RateLimitHit.objects.filter(created_at__lt=now - timedelta(days=1)).delete()
        count = RateLimitHit.objects.filter(
            bucket=bucket, created_at__gte=now - timedelta(seconds=window)).count()
        RateLimitHit.objects.create(bucket=bucket)
        return count < limit
    except Exception as exc:
        log.error("rate_limit: %s", exc)
        return True


def rate_limit_or_fail(request: Request, action: str, key: str, limit: int, window: int, message: str) -> None:
    if not rate_limit_check(action, key, limit, window):
        security_log(request, "rate_limited", None, f"{action} / {key}")
        raise ApiError(message, 429, {"Retry-After": str(window)})


def rate_limit_reset(action: str, key: str) -> None:
    try:
        RateLimitHit.objects.filter(bucket=f"{action}|{key}"[:190]).delete()
    except Exception as exc:
        log.error("rate_limit_reset: %s", exc)


# ---------------------------------------------------------------------
# Аутентификация и роли
# ---------------------------------------------------------------------
def user_dict(user: User) -> dict:
    return {"id": user.id, "name": user.name, "email": user.email, "role": user.role}


def login_user(request: Request, user: User) -> None:
    """Вход: перевыпуск ключа сессии (защита от session fixation) + данные в формате django.contrib.auth,
    поэтому один и тот же вход открывает и /admin/ (для роли admin)."""
    session = request.state.session
    session.cycle_key()
    session[SESSION_KEY] = str(user.pk)
    session[BACKEND_SESSION_KEY] = "django.contrib.auth.backends.ModelBackend"
    session[HASH_SESSION_KEY] = user.get_session_auth_hash()
    now = int(time.time())
    session["login_time"] = now
    session["last_activity"] = now
    session["ua"] = _ua_hash(request)   # защита от кражи cookie: с другим браузером сессия не работает
    session.pop("csrf_token", None)
    csrf_token(session)
    user.last_login = timezone.now()
    user.save(update_fields=["last_login"])


def _ua_hash(request: Request) -> str:
    return hashlib.sha256(request.headers.get("user-agent", "").encode()).hexdigest()[:32]


def logout_user(request: Request) -> None:
    request.state.session.flush()


def _session_matches_browser(request: Request) -> bool:
    """False, если cookie сессии пришла из другого браузера (другой User-Agent) — сессия сбрасывается."""
    session = request.state.session
    if not settings.SESSION_BIND_USER_AGENT or "ua" not in session:
        return True
    if hmac.compare_digest(session["ua"], _ua_hash(request)):
        return True
    security_log(request, "session_mismatch", int(session.get(SESSION_KEY) or 0) or None, "User-Agent изменился")
    session.flush()
    return False


def current_user(request: Request) -> User | None:
    uid = request.state.session.get(SESSION_KEY)
    if not uid or not _session_matches_browser(request):
        return None
    return User.objects.filter(pk=uid).first()


def require_login(request: Request) -> User:
    uid = request.state.session.get(SESSION_KEY)
    if not uid:
        raise ApiError("Требуется авторизация", 401)
    if not _session_matches_browser(request):
        raise ApiError("Сессия недействительна. Войдите снова.", 401)
    user = User.objects.filter(pk=uid).first()
    if user is None or user.is_banned:
        request.state.session.flush()
        raise ApiError("Аккаунт заблокирован или удалён", 403)
    return user


def require_organizer(user: User = Depends(require_login)) -> User:
    if user.role != User.Role.ORGANIZER:
        raise ApiError("Доступно только организаторам", 403)
    return user


def require_admin(request: Request, user: User = Depends(require_login)) -> User:
    if user.role != User.Role.ADMIN:
        security_log(request, "access_denied", user.id, "admin area")
        raise ApiError("Доступно только администраторам", 403)
    return user


# ---------------------------------------------------------------------
# Проверки принадлежности
# ---------------------------------------------------------------------
def is_webinar_owner(webinar_id: int, user_id: int) -> bool:
    return Webinar.objects.filter(pk=webinar_id, organizer_id=user_id).exists()


def require_webinar_owner(webinar_id: int, user: User) -> None:
    if not Webinar.objects.filter(pk=webinar_id).exists():
        raise ApiError("Вебинар не найден", 404)
    if not is_webinar_owner(webinar_id, user.id):
        raise ApiError("Вы не являетесь организатором этого вебинара", 403)


def ensure_webinar_member(webinar_id: int, user: User) -> None:
    if is_webinar_owner(webinar_id, user.id):
        return
    if not Registration.objects.filter(webinar_id=webinar_id, user_id=user.id).exists():
        raise ApiError("Сначала зарегистрируйтесь на этот вебинар", 403)


def ensure_can_read(webinar_id: int, user: User) -> None:
    """Читать чат, опросы и вопросы может владелец, зарегистрированный участник и администратор."""
    if user.role == User.Role.ADMIN:
        return
    ensure_webinar_member(webinar_id, user)


def complete_pending_invite(request: Request, user: User) -> int | None:
    """Если человек пришёл по ссылке /join до входа — записываем его на вебинар."""
    webinar_id = request.state.session.pop("pending_invite_webinar_id", None)
    if not webinar_id:
        return None
    webinar_id = int(webinar_id)
    if Webinar.objects.filter(pk=webinar_id).exists():
        Registration.objects.get_or_create(webinar_id=webinar_id, user_id=user.id)
        return webinar_id
    return None
