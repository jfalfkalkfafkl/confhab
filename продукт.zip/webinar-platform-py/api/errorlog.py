"""Запись ошибок в журнал (таблица error_log + файл logs/errors.log).

record_error() никогда не бросает исключений: сбой самого журналирования не должен ломать запрос.
"""
import logging

log = logging.getLogger("api.errors")


def record_error(source: str, message: str, trace: str = "", path: str = "", method: str = "",
                 user_id: int | None = None, ip: str = "") -> None:
    log.error("[%s] %s %s %s", source, method, path, message)
    if trace:
        log.error(trace)
    try:
        from core.models import ErrorLog
        ErrorLog.objects.create(source=source, message=message[:500], trace=trace[:20000],
                                path=path[:255], method=method[:10], user_id=user_id, ip=ip[:45])
    except Exception as exc:  # noqa: BLE001
        log.error("record_error: не удалось записать в БД: %s", exc)
