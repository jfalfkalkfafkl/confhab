"""/notifications — уведомления пользователя («колокольчик» в интерфейсе)."""
from fastapi import APIRouter, Depends

from core.models import Notification, User

from ..schemas import NotificationsReadIn
from ..security import require_login
from ..utils import fmt_dt

router = APIRouter(tags=["notifications"])


@router.get("/notifications", summary="Последние уведомления и число непрочитанных")
def list_notifications(limit: int = 20, user: User = Depends(require_login)):
    limit = min(50, max(1, limit))
    rows = Notification.objects.filter(user_id=user.id)[:limit]
    unread = Notification.objects.filter(user_id=user.id, is_read=False).count()
    return {"unread": unread, "notifications": [{
        "id": n.id, "kind": n.kind, "text": n.text, "webinar_id": n.webinar_id,
        "is_read": n.is_read, "created_at": fmt_dt(n.created_at)} for n in rows]}


@router.post("/notifications/read", summary="Отметить прочитанными (все или по списку id)")
def mark_read(body: NotificationsReadIn = NotificationsReadIn(), user: User = Depends(require_login)):
    qs = Notification.objects.filter(user_id=user.id, is_read=False)
    if isinstance(body.ids, list):
        ids = [int(i) for i in body.ids if str(i).isdigit()][:100]
        qs = qs.filter(id__in=ids)
    return {"updated": qs.update(is_read=True)}
