"""/webinars — каталог (поиск, фильтры, сортировка, пагинация), CRUD, запись экрана, участники,
регистрация, приглашения, календарь (.ics), создание встречи в Телемосте."""
import math
import secrets
from datetime import datetime, timedelta

from django.conf import settings
from django.db import IntegrityError
from django.db.models import Count, Exists, OuterRef, Q
from fastapi import APIRouter, Depends, File, Request, Response, UploadFile

from core.models import Category, Notification, Registration, User, Webinar

from .. import integrations
from ..errors import ApiError
from ..notify import notify, notify_registrants
from ..schemas import TelemostIn, WebinarIn
from ..security import (current_user, rate_limit_or_fail, require_login, require_organizer,
                        require_webinar_owner, security_log)
from ..utils import (PLATFORMS, clean_text, detect_platform, fmt_dt, generate_invite_token, ics_escape,
                     is_safe_external_url, parse_datetime, platform_label)

router = APIRouter(tags=["webinars"])

STATUSES = {"scheduled", "live", "finished"}

# Допустимые сортировки каталога: ключ запроса → поля ORDER BY (всегда с id для стабильной пагинации)
SORTS = {
    "date_asc": ("scheduled_at", "id"),
    "date_desc": ("-scheduled_at", "-id"),
    "title": ("title", "id"),
    "popular": ("-participants_count", "-scheduled_at", "id"),
    "new": ("-created_at", "-id"),
}
MAX_PER_PAGE = 50


def _check_length(value, limit: int, message: str) -> None:
    """Слишком длинное значение — ошибка 400, а не тихая обрезка."""
    if value is not None and not isinstance(value, (dict, list)) and len(str(value).strip()) > limit:
        raise ApiError(message)


def _check_not_past(dt) -> None:
    if dt < datetime.now() - timedelta(minutes=5):  # USE_TZ=False: локальное время сервера
        raise ApiError("Дата и время проведения не могут быть в прошлом")


def parse_category(value) -> int | None:
    """category_id из запроса → id существующей категории или None (пусто = «без категории»)."""
    if value in (None, "", 0, "0"):
        return None
    try:
        category_id = int(value)
    except (TypeError, ValueError):
        raise ApiError("Некорректная категория")
    if not Category.objects.filter(pk=category_id).exists():
        raise ApiError("Такой категории не существует")
    return category_id


def validated_stream_url(value, label: str = "трансляцию") -> str:
    url = clean_text(value, 500)
    if url and not is_safe_external_url(url):
        raise ApiError(f"Некорректная ссылка на {label} (допустимы только http/https)")
    return url


def _queryset(user_id: int):
    return (Webinar.objects.select_related("organizer", "category")
            .annotate(participants_count=Count("registrations"),
                      is_registered=Exists(Registration.objects.filter(
                          webinar=OuterRef("pk"), user_id=user_id))))


def serialize_webinar(w: Webinar, viewer_id: int) -> dict:
    return {
        "id": w.id, "title": w.title, "description": w.description,
        "stream_url": w.stream_url, "recording_url": w.recording_url,
        # ссылку-приглашение видит только владелец вебинара
        "invite_token": w.invite_token if w.organizer_id == viewer_id else None,
        "scheduled_at": fmt_dt(w.scheduled_at), "status": w.status,
        "organizer_id": w.organizer_id, "organizer_name": w.organizer.name,
        "participants_count": w.participants_count, "is_registered": bool(w.is_registered),
        "category_id": w.category_id,
        "category": {"id": w.category.id, "name": w.category.name, "slug": w.category.slug} if w.category else None,
        "platform": w.platform, "platform_label": platform_label(w.platform),
    }


_serialize = serialize_webinar  # прежнее имя (его импортируют другие модули)


def webinar_exists(webinar_id: int) -> bool:
    return Webinar.objects.filter(pk=webinar_id).exists()


def apply_status_change(webinar: Webinar, new_status: str) -> None:
    """Смена статуса + уведомление зарегистрированных, когда эфир начался."""
    if webinar.status == new_status:
        return
    Webinar.objects.filter(pk=webinar.pk).update(status=new_status)
    if new_status == "live":
        notify_registrants(webinar, f"Эфир «{webinar.title}» начался — присоединяйтесь!", Notification.Kind.LIVE)


def filter_webinars(qs, *, q: str = "", status: str = "", category: str = "", platform: str = ""):
    """Общие фильтры каталога и админ-таблицы (всё через ORM — параметры подставляются безопасно)."""
    q = clean_text(q, 100)
    if q:
        qs = qs.filter(Q(title__icontains=q) | Q(description__icontains=q) | Q(organizer__name__icontains=q))
    if status:
        if status not in STATUSES:
            raise ApiError("Недопустимый статус")
        qs = qs.filter(status=status)
    if category:
        qs = qs.filter(category__slug=clean_text(category, 60))
    if platform:
        if platform not in PLATFORMS:
            raise ApiError("Неизвестная площадка")
        qs = qs.filter(platform=platform)
    return qs


def paginate(qs, page: int, per_page: int):
    """Возвращает (элементы страницы, метаданные). total считается отдельным COUNT."""
    per_page = min(MAX_PER_PAGE, max(1, per_page))
    total = qs.count()
    pages = max(1, math.ceil(total / per_page))
    page = min(max(1, page), pages)
    items = list(qs[(page - 1) * per_page: page * per_page])
    return items, {"total": total, "page": page, "pages": pages, "per_page": per_page}


@router.get("/webinars", summary="Каталог вебинаров: поиск, фильтры, сортировка, пагинация")
def list_webinars(request: Request, q: str = "", status: str = "", category: str = "", platform: str = "",
                  mine: bool = False, sort: str = "", page: int = 0, per_page: int = 0):
    """Без `page`/`per_page` отдаёт все вебинары (так работает дашборд). С ними — постранично."""
    user = current_user(request)
    uid = user.id if user else 0
    qs = filter_webinars(_queryset(uid), q=q, status=status, category=category, platform=platform)
    if mine and user:
        qs = qs.filter(Q(organizer_id=uid) | Q(is_registered=True))
    if sort and sort not in SORTS:
        raise ApiError("Недопустимая сортировка")
    default_sort = "date_asc" if status in ("scheduled", "live") else "date_desc"
    qs = qs.order_by(*SORTS[sort or default_sort])

    if not page and not per_page:
        items = list(qs)
        meta = {"total": len(items), "page": 1, "pages": 1, "per_page": len(items)}
    else:
        items, meta = paginate(qs, page or 1, per_page or 9)
    return {"webinars": [serialize_webinar(w, uid) for w in items], **meta}


@router.post("/webinars", status_code=201, summary="Создать вебинар (организатор)")
def create_webinar(body: WebinarIn = WebinarIn(), user: User = Depends(require_organizer)):
    _check_length(body.title, 200, "Название вебинара не должно превышать 200 символов")
    _check_length(body.description, 2000, "Описание не должно превышать 2000 символов")
    title = clean_text(body.title, 200)
    description = clean_text(body.description, 2000)
    stream_url = validated_stream_url(body.stream_url)
    scheduled_raw = clean_text(body.scheduled_at, 32)

    if not title:
        raise ApiError("Укажите название вебинара (до 200 символов)")
    if not scheduled_raw:
        raise ApiError("Укажите дату и время проведения")
    scheduled_at = parse_datetime(scheduled_raw)
    if scheduled_at is None:
        raise ApiError("Некорректный формат даты и времени")
    _check_not_past(scheduled_at)

    webinar = Webinar.objects.create(
        title=title, description=description or None, stream_url=stream_url or None,
        platform=detect_platform(stream_url), category_id=parse_category(body.category_id),
        invite_token=generate_invite_token(), scheduled_at=scheduled_at, organizer=user)
    return {"id": webinar.id, "invite_token": webinar.invite_token}


@router.get("/webinars/{webinar_id}", summary="Карточка вебинара (доступна и гостям)")
def get_webinar(webinar_id: int, request: Request):
    user = current_user(request)
    uid = user.id if user else 0
    w = _queryset(uid).filter(pk=webinar_id).first()
    if w is None:
        raise ApiError("Вебинар не найден", 404)
    data = serialize_webinar(w, uid)
    data["is_owner"] = user is not None and user.id == w.organizer_id
    return {"webinar": data}


@router.patch("/webinars/{webinar_id}", summary="Изменить вебинар / статус / ссылку на запись")
def patch_webinar(webinar_id: int, body: WebinarIn = WebinarIn(), user: User = Depends(require_organizer)):
    require_webinar_owner(webinar_id, user)
    webinar = Webinar.objects.get(pk=webinar_id)
    sent = body.model_fields_set  # частичное обновление: меняем только переданные поля
    changes: dict = {}

    if "title" in sent:
        _check_length(body.title, 200, "Название вебинара не должно превышать 200 символов")
        title = clean_text(body.title, 200)
        if not title:
            raise ApiError("Укажите название вебинара (до 200 символов)")
        changes["title"] = title
    if "description" in sent:
        _check_length(body.description, 2000, "Описание не должно превышать 2000 символов")
        changes["description"] = clean_text(body.description, 2000) or None
    if "stream_url" in sent:
        url = validated_stream_url(body.stream_url)
        changes["stream_url"] = url or None
        changes["platform"] = detect_platform(url)
    if "recording_url" in sent:
        changes["recording_url"] = validated_stream_url(body.recording_url, "запись") or None
    if "category_id" in sent:
        changes["category_id"] = parse_category(body.category_id)
    schedule_changed = False
    if "scheduled_at" in sent:
        dt = parse_datetime(clean_text(body.scheduled_at, 32))
        if dt is None:
            raise ApiError("Некорректный формат даты и времени")
        if dt != webinar.scheduled_at:  # неизменённую дату (форма шлёт её всегда) не проверяем
            _check_not_past(dt)
            schedule_changed = True
        changes["scheduled_at"] = dt
    new_status = None
    if "status" in sent:
        if str(body.status) not in STATUSES:
            raise ApiError("Некорректный статус")
        new_status = str(body.status)

    if not changes and new_status is None:
        raise ApiError("Не переданы поля для изменения")
    if changes:
        Webinar.objects.filter(pk=webinar_id, organizer_id=user.id).update(**changes)
    if new_status:
        apply_status_change(webinar, new_status)
    if schedule_changed:
        notify_registrants(webinar, f"Вебинар «{changes.get('title', webinar.title)}» перенесён на "
                                    f"{changes['scheduled_at']:%d.%m.%Y %H:%M}", Notification.Kind.SCHEDULE)
    return {"ok": True}


@router.delete("/webinars/{webinar_id}", status_code=204, summary="Удалить вебинар (владелец или админ)")
def delete_webinar(webinar_id: int, request: Request, user: User = Depends(require_login)):
    if user.role == User.Role.ADMIN:
        if not webinar_exists(webinar_id):
            raise ApiError("Вебинар не найден", 404)
        Webinar.objects.filter(pk=webinar_id).delete()
    else:
        if user.role != User.Role.ORGANIZER:
            raise ApiError("Доступно только организаторам", 403)
        require_webinar_owner(webinar_id, user)
        Webinar.objects.filter(pk=webinar_id, organizer_id=user.id).delete()  # остальное — каскадом
    security_log(request, "webinar_deleted", user.id, f"webinar #{webinar_id}")
    return Response(status_code=204)


@router.get("/webinars/{webinar_id}/calendar.ics", summary="Добавить вебинар в календарь (iCalendar)")
def webinar_ics(webinar_id: int):
    """Файл .ics открывается в Google/Яндекс/Apple Календаре и Outlook. Длительность по умолчанию — 1 час."""
    w = Webinar.objects.filter(pk=webinar_id).select_related("organizer").first()
    if w is None:
        raise ApiError("Вебинар не найден", 404)
    start = w.scheduled_at
    end = start + timedelta(hours=1)
    stamp = datetime.now().strftime("%Y%m%dT%H%M%S")
    desc = (w.description or "") + (f"\n\nТрансляция: {w.stream_url}" if w.stream_url else "")
    lines = [
        "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//ConfHub//Webinars//RU", "CALSCALE:GREGORIAN",
        "BEGIN:VEVENT", f"UID:webinar-{w.id}@confhub", f"DTSTAMP:{stamp}",
        f"DTSTART:{start:%Y%m%dT%H%M%S}", f"DTEND:{end:%Y%m%dT%H%M%S}",
        f"SUMMARY:{ics_escape(w.title)}", f"DESCRIPTION:{ics_escape(desc)}",
        f"ORGANIZER;CN={ics_escape(w.organizer.name)}:mailto:{w.organizer.email}",
        "END:VEVENT", "END:VCALENDAR",
    ]
    return Response("\r\n".join(lines) + "\r\n", media_type="text/calendar; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="webinar-{w.id}.ics"'})


@router.post("/integrations/telemost", summary="Создать видеовстречу в Яндекс Телемосте (организатор)")
def create_telemost(request: Request, body: TelemostIn = TelemostIn(), user: User = Depends(require_organizer)):
    rate_limit_or_fail(request, "telemost_create", str(user.id), 10, 3600,
                       "Слишком много запросов к Телемосту. Попробуйте позже.")
    conference = integrations.telemost_create_conference(clean_text(body.title, 200))
    security_log(request, "telemost_created", user.id, conference.get("id") or "")
    return {"join_url": conference["join_url"]}


# ---------------------------------------------------------------------
# Запись экрана
# ---------------------------------------------------------------------
def detect_video_extension(head: bytes) -> str | None:
    """Формат определяется по содержимому файла (сигнатуре), а не по имени/заголовку запроса."""
    if head[:4] == b"\x1a\x45\xdf\xa3":
        return "webm"      # EBML: WebM / Matroska
    if head[4:8] == b"ftyp":
        return "mp4"
    if head[:4] == b"OggS":
        return "ogv"
    return None


@router.post("/webinars/{webinar_id}/recording", status_code=201, summary="Загрузить запись экрана (владелец)")
def upload_recording(webinar_id: int, request: Request, recording: UploadFile = File(None),
                     user: User = Depends(require_organizer)):
    require_webinar_owner(webinar_id, user)
    rate_limit_or_fail(request, "recording_upload", str(user.id), 20, 3600,
                       "Слишком много загрузок записи подряд. Попробуйте позже.")
    if recording is None:
        raise ApiError("Файл записи не получен")

    head = recording.file.read(16)
    recording.file.seek(0)
    ext = detect_video_extension(head)
    if ext is None:
        raise ApiError("Поддерживаются только записи в формате WebM или MP4")

    settings.RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)
    filename = f"{secrets.token_hex(16)}.{ext}"
    target = settings.RECORDINGS_DIR / filename
    written = 0
    try:
        with open(target, "wb") as out:
            while chunk := recording.file.read(1024 * 1024):
                written += len(chunk)
                if written > settings.MAX_RECORDING_BYTES:
                    raise ApiError("Размер записи должен быть не более 400 МБ")
                out.write(chunk)
        if written == 0:
            raise ApiError("Размер записи должен быть не более 400 МБ")
    except ApiError:
        target.unlink(missing_ok=True)
        raise
    except OSError:
        target.unlink(missing_ok=True)
        raise ApiError("Не удалось сохранить файл записи на сервере", 500)

    security_log(request, "recording_uploaded", user.id, f"webinar #{webinar_id} / {filename}")
    return {"path": f"uploads/recordings/{filename}"}


# ---------------------------------------------------------------------
# Участники, регистрация, приглашение
# ---------------------------------------------------------------------
@router.get("/webinars/{webinar_id}/participants", summary="Участники (владелец)")
def participants(webinar_id: int, user: User = Depends(require_organizer)):
    require_webinar_owner(webinar_id, user)
    rows = (Registration.objects.filter(webinar_id=webinar_id)
            .select_related("user").order_by("registered_at", "id"))
    return {"participants": [
        {"id": r.user.id, "name": r.user.name, "email": r.user.email,
         "registered_at": fmt_dt(r.registered_at)} for r in rows]}


@router.post("/webinars/{webinar_id}/registrations", status_code=201, summary="Зарегистрироваться на вебинар")
def register_for_webinar(webinar_id: int, user: User = Depends(require_login)):
    webinar = Webinar.objects.filter(pk=webinar_id).first()
    if webinar is None:
        raise ApiError("Вебинар не найден", 404)
    try:
        Registration.objects.create(webinar_id=webinar_id, user_id=user.id)
    except IntegrityError:
        raise ApiError("Вы уже зарегистрированы на этот вебинар", 409)
    if webinar.organizer_id != user.id:  # организатору — уведомление о новом участнике
        notify(webinar.organizer_id, f"{user.name} зарегистрировался на «{webinar.title}»",
               Notification.Kind.REGISTRATION, webinar_id)
    return {"ok": True}


@router.post("/webinars/{webinar_id}/invite", summary="Перевыпустить ссылку-приглашение")
def regenerate_invite(webinar_id: int, request: Request, user: User = Depends(require_organizer)):
    require_webinar_owner(webinar_id, user)
    token = generate_invite_token()
    Webinar.objects.filter(pk=webinar_id).update(invite_token=token)
    security_log(request, "invite_regenerated", user.id, f"webinar #{webinar_id}")
    return {"invite_token": token}
