from fastapi import APIRouter, Depends, Request
from django.contrib.auth.hashers import check_password

from core.models import Registration, User, Webinar

from ..errors import ApiError
from ..schemas import ChangePasswordIn, ProfileIn
from ..security import (csrf_token, login_user, rate_limit_or_fail, require_login, security_log,
                        user_dict)
from ..utils import clean_text, password_policy_error

router = APIRouter(tags=["profile"])


@router.get("/profile", summary="Профиль и статистика")
def get_profile(user: User = Depends(require_login)):
    return {
        "user": user_dict(user),
        "stats": {
            "organized_count": Webinar.objects.filter(organizer=user).count(),
            "registered_count": Registration.objects.filter(user=user).count(),
        },
    }


@router.patch("/profile", summary="Изменить имя")
def patch_profile(body: ProfileIn = ProfileIn(), user: User = Depends(require_login)):
    name = clean_text(body.name, 100)
    if not name:
        raise ApiError("Укажите имя (до 100 символов)")
    user.name = name
    user.save(update_fields=["name"])
    return {"user": user_dict(user)}


@router.post("/profile/password", summary="Сменить пароль")
def change_password(request: Request, body: ChangePasswordIn = ChangePasswordIn(),
                    user: User = Depends(require_login)):
    rate_limit_or_fail(request, "change_password", str(user.id), 10, 900,
                       "Слишком много попыток смены пароля. Повторите позже.")
    current = str(body.current_password or "")
    new = str(body.new_password or "")
    if not current:
        raise ApiError("Введите текущий пароль")
    if err := password_policy_error(new, user.email):
        raise ApiError(err)
    if not check_password(current, user.password):
        security_log(request, "change_password_failed", user.id)
        raise ApiError("Текущий пароль указан неверно", 401)

    user.set_password(new)
    user.save(update_fields=["password"])
    login_user(request, user)  # перевыпускаем сессию после смены пароля
    security_log(request, "change_password_success", user.id)
    return {"ok": True, "csrf_token": csrf_token(request.state.session)}
