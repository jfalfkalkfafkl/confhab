"""Публичные и служебные ресурсы: сводка для главной, категории, доступные интеграции, отчёты об ошибках из браузера."""
from django.conf import settings
from django.core.cache import cache
from django.db.models import Count, Q
from fastapi import APIRouter, Request

from core.models import Category, Registration, User, Webinar

from .. import integrations
from ..errorlog import record_error
from ..schemas import ClientErrorIn
from ..security import client_ip, current_user, rate_limit_or_fail
from ..utils import clean_text

router = APIRouter(tags=["public"])


def category_list() -> list[dict]:
    """Список категорий с количеством вебинаров; кэшируется на PUBLIC_CACHE_SECONDS секунд."""
    data = cache.get("categories")
    if data is None:
        rows = Category.objects.annotate(webinars_count=Count("webinars")).order_by("sort_order", "name")
        data = [{"id": c.id, "name": c.name, "slug": c.slug, "sort_order": c.sort_order, "webinars_count": c.webinars_count} for c in rows]
        cache.set("categories", data, settings.PUBLIC_CACHE_SECONDS)
    return data


def invalidate_public_cache() -> None:
    """Вызывается при изменении категорий/вебинаров, чтобы счётчики на главной не «залипали»."""
    cache.delete_many(["categories", "public_summary"])


@router.get("/categories", summary="Категории вебинаров")
def categories():
    return {"categories": category_list()}


@router.get("/public/summary", summary="Сводка для главной страницы (кэшируется)")
def public_summary():
    data = cache.get("public_summary")
    if data is None:
        w = Webinar.objects.aggregate(
            total=Count("id"), live=Count("id", filter=Q(status="live")),
            scheduled=Count("id", filter=Q(status="scheduled")), finished=Count("id", filter=Q(status="finished")))
        data = {**w, "organizers": User.objects.filter(role="organizer").count(),
                "registrations": Registration.objects.count()}
        cache.set("public_summary", data, settings.PUBLIC_CACHE_SECONDS)
    return data


@router.get("/integrations", summary="Какие внешние интеграции включены")
def integrations_state():
    return integrations.enabled()


@router.post("/client-errors", status_code=204, summary="Отчёт об ошибке JavaScript из браузера")
def client_error(request: Request, body: ClientErrorIn = ClientErrorIn()):
    """Принимает ошибки фронтенда (window.onerror). Ограничение: 10 отчётов в минуту с одного IP."""
    from fastapi import Response
    rate_limit_or_fail(request, "client_error", client_ip(request), 10, 60, "Слишком много отчётов об ошибках")
    user = current_user(request)
    message = clean_text(body.message, 300) or "(без текста)"
    trace = "\n".join(filter(None, [clean_text(body.source, 200), f"line {clean_text(body.line, 12)}",
                                    clean_text(body.stack, 3000)]))
    record_error("client", message, trace, clean_text(body.page, 255), "JS", user.id if user else None,
                 client_ip(request))
    return Response(status_code=204)
