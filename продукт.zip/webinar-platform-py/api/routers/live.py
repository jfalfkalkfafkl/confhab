"""Живое взаимодействие внутри вебинара: чат, опросы, вопросы Q&A."""
from django.db import IntegrityError, transaction
from django.db.models import F
from fastapi import APIRouter, Depends, Request

from core.models import ChatMessage, Notification, Poll, PollOption, PollVote, Question, User

from ..errors import ApiError
from ..notify import notify
from ..schemas import AnswerIn, MessageIn, PollIn, PollPatchIn, QuestionIn, VoteIn
from ..security import (ensure_can_read, ensure_webinar_member, rate_limit_or_fail, require_login,
                        require_organizer, require_webinar_owner)
from ..utils import clean_text, fmt_dt
from .webinars import webinar_exists

router = APIRouter()


def _check_readable(webinar_id: int, user: User) -> None:
    """Чат, опросы и вопросы видят только владелец, зарегистрированные участники и администратор."""
    if not webinar_exists(webinar_id):
        raise ApiError("Вебинар не найден", 404)
    ensure_can_read(webinar_id, user)


# ----------------------------- Чат ----------------------------------
@router.get("/webinars/{webinar_id}/messages", tags=["chat"], summary="Сообщения чата")
def list_messages(webinar_id: int, after_id: int = 0, user: User = Depends(require_login)):
    _check_readable(webinar_id, user)
    rows = (ChatMessage.objects.filter(webinar_id=webinar_id, id__gt=after_id)
            .select_related("user").order_by("id")[:200])
    return {"messages": [
        {"id": m.id, "message": m.message, "created_at": fmt_dt(m.created_at),
         "user_id": m.user_id, "user_name": m.user.name, "user_role": m.user.role} for m in rows]}


@router.post("/webinars/{webinar_id}/messages", status_code=201, tags=["chat"], summary="Отправить сообщение")
def send_message(webinar_id: int, request: Request, body: MessageIn = MessageIn(),
                 user: User = Depends(require_login)):
    rate_limit_or_fail(request, "chat", str(user.id), 20, 60, "Слишком много сообщений подряд. Немного подождите.")
    message = clean_text(body.message, 1000)
    if not message:
        raise ApiError("Сообщение не может быть пустым")
    ensure_webinar_member(webinar_id, user)
    msg = ChatMessage.objects.create(webinar_id=webinar_id, user_id=user.id, message=message)
    return {"id": msg.id}


# ---------------------------- Опросы ---------------------------------
@router.get("/webinars/{webinar_id}/polls", tags=["polls"], summary="Опросы вебинара")
def list_polls(webinar_id: int, user: User = Depends(require_login)):
    _check_readable(webinar_id, user)
    uid = user.id
    polls = list(Poll.objects.filter(webinar_id=webinar_id).prefetch_related("options").order_by("-id"))
    voted = dict(PollVote.objects.filter(poll__in=polls, user_id=uid).values_list("poll_id", "option_id"))
    return {"polls": [{
        "id": p.id, "question": p.question, "is_active": p.is_active,
        "options": [{"id": o.id, "option_text": o.option_text, "votes": o.votes}
                    for o in sorted(p.options.all(), key=lambda o: o.id)],
        "voted_option_id": voted.get(p.id),
    } for p in polls]}


@router.post("/webinars/{webinar_id}/polls", status_code=201, tags=["polls"], summary="Создать опрос (владелец)")
def create_poll(webinar_id: int, body: PollIn = PollIn(), user: User = Depends(require_organizer)):
    require_webinar_owner(webinar_id, user)
    question = clean_text(body.question, 255)
    raw = body.options if isinstance(body.options, list) else []
    options = [t for t in (clean_text(o, 255) for o in raw) if t]

    if not question:
        raise ApiError("Укажите вопрос опроса (до 255 символов)")
    if len(options) < 2:
        raise ApiError("Добавьте минимум 2 варианта ответа")
    if len(options) > 10:
        raise ApiError("Не более 10 вариантов ответа")

    with transaction.atomic():
        poll = Poll.objects.create(webinar_id=webinar_id, question=question)
        PollOption.objects.bulk_create([PollOption(poll=poll, option_text=t) for t in options])
    return {"id": poll.id}


@router.patch("/polls/{poll_id}", tags=["polls"], summary="Завершить опрос (владелец)")
def close_poll(poll_id: int, body: PollPatchIn = PollPatchIn(), user: User = Depends(require_organizer)):
    if not Poll.objects.filter(pk=poll_id, webinar__organizer_id=user.id).exists():
        raise ApiError("Вы не являетесь организатором вебинара, к которому относится этот опрос", 403)
    if body.is_active is not False:
        raise ApiError('Допустимо только завершение опроса: {"is_active": false}')
    Poll.objects.filter(pk=poll_id).update(is_active=False)
    return {"ok": True}


@router.post("/polls/{poll_id}/votes", status_code=201, tags=["polls"], summary="Проголосовать")
def vote(poll_id: int, body: VoteIn = VoteIn(), user: User = Depends(require_login)):
    try:
        option_id = int(body.option_id or 0)
    except (TypeError, ValueError):
        option_id = 0
    if option_id <= 0:
        raise ApiError("Некорректные данные голосования")

    option = PollOption.objects.select_related("poll").filter(pk=option_id, poll_id=poll_id).first()
    if option is None:
        raise ApiError("Вариант ответа не найден", 404)
    ensure_webinar_member(option.poll.webinar_id, user)   # голосуют только участники этого вебинара
    if not option.poll.is_active:
        raise ApiError("Этот опрос уже завершён", 409)

    try:
        with transaction.atomic():
            PollVote.objects.create(poll_id=poll_id, option_id=option_id, user_id=user.id)
            PollOption.objects.filter(pk=option_id).update(votes=F("votes") + 1)
    except IntegrityError:
        raise ApiError("Вы уже проголосовали в этом опросе", 409)
    return {"ok": True}


# ------------------------------ Q&A ----------------------------------
@router.get("/webinars/{webinar_id}/questions", tags=["questions"], summary="Вопросы Q&A")
def list_questions(webinar_id: int, user: User = Depends(require_login)):
    _check_readable(webinar_id, user)
    rows = (Question.objects.filter(webinar_id=webinar_id).select_related("user")
            .order_by("is_answered", "-id"))
    return {"questions": [
        {"id": q.id, "question_text": q.question_text, "answer_text": q.answer_text,
         "is_answered": q.is_answered, "created_at": fmt_dt(q.created_at),
         "user_id": q.user_id, "user_name": q.user.name} for q in rows]}


@router.post("/webinars/{webinar_id}/questions", status_code=201, tags=["questions"], summary="Задать вопрос")
def ask_question(webinar_id: int, request: Request, body: QuestionIn = QuestionIn(),
                 user: User = Depends(require_login)):
    rate_limit_or_fail(request, "question", str(user.id), 10, 60, "Слишком много вопросов подряд. Немного подождите.")
    text = clean_text(body.question_text, 1000)
    if not text:
        raise ApiError("Вопрос не может быть пустым")
    if not webinar_exists(webinar_id):
        raise ApiError("Вебинар не найден", 404)
    ensure_webinar_member(webinar_id, user)
    q = Question.objects.create(webinar_id=webinar_id, user_id=user.id, question_text=text)
    return {"id": q.id}


@router.patch("/questions/{question_id}", tags=["questions"], summary="Ответить на вопрос (владелец)")
def answer_question(question_id: int, body: AnswerIn = AnswerIn(), user: User = Depends(require_organizer)):
    answer = clean_text(body.answer_text, 2000)
    if not answer:
        raise ApiError("Ответ не может быть пустым")
    question = (Question.objects.select_related("webinar")
                .filter(pk=question_id, webinar__organizer_id=user.id).first())
    if question is None:
        raise ApiError("Вопрос не найден или вы не организатор этого вебинара", 403)
    Question.objects.filter(pk=question_id).update(answer_text=answer, is_answered=True)
    if not question.is_answered:  # автору вопроса — уведомление об ответе
        notify(question.user_id, f"Ответ на ваш вопрос в «{question.webinar.title}»",
               Notification.Kind.ANSWER, question.webinar_id)
    return {"ok": True}
