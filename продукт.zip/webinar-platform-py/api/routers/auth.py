"""/csrf и /auth/* — регистрация, вход, выход, восстановление пароля."""
from datetime import timedelta

from django.conf import settings
from django.contrib.auth.hashers import check_password, make_password
from django.db import IntegrityError
from django.utils import timezone
from fastapi import APIRouter, Request

from core.models import AdminPasswordReset, PasswordReset, User

from ..errors import ApiError
from ..schemas import AdminResetIn, ForgotIn, LoginIn, RegisterIn, ResetIn
from ..security import (client_ip, complete_pending_invite, csrf_token, current_user, login_user,
                        logout_user, rate_limit_or_fail, rate_limit_reset, security_log, user_dict)
from ..utils import (clean_text, generate_numeric_code, is_valid_email, normalize_recovery_key,
                     password_policy_error)

router = APIRouter()


def _email(value) -> str:
    return clean_text(value, 150).lower()


@router.get("/csrf", tags=["auth"], summary="Получить CSRF-токен")
def get_csrf(request: Request):
    return {"csrf_token": csrf_token(request.state.session)}


@router.post("/auth/register", status_code=201, tags=["auth"], summary="Регистрация")
def register(request: Request, body: RegisterIn = RegisterIn()):
    rate_limit_or_fail(request, "register", client_ip(request), 10, 3600,
                       "Слишком много регистраций с этого адреса. Попробуйте позже.")
    name = clean_text(body.name, 100)
    email = _email(body.email)
    password = str(body.password or "")
    role = User.Role.ORGANIZER if body.role == "organizer" else User.Role.PARTICIPANT  # белый список

    if not name:
        raise ApiError("Укажите имя (до 100 символов)")
    if not is_valid_email(email):
        raise ApiError("Некорректный email")
    if err := password_policy_error(password, email):
        raise ApiError(err)
    if User.objects.filter(email=email).exists():
        raise ApiError("Пользователь с таким email уже зарегистрирован", 409)

    try:
        user = User.objects.create_user(email=email, password=password, name=name, role=role)
    except IntegrityError:
        raise ApiError("Пользователь с таким email уже зарегистрирован", 409)

    login_user(request, user)
    security_log(request, "register", user.id, email)
    joined = complete_pending_invite(request, user)
    return {"user": user_dict(user), "csrf_token": csrf_token(request.state.session),
            "joined_webinar_id": joined}


@router.post("/auth/login", tags=["auth"], summary="Вход")
def login(request: Request, body: LoginIn = LoginIn()):
    email = _email(body.email)
    password = str(body.password or "")
    rate_limit_or_fail(request, "login_ip", client_ip(request), 10, 900,
                       "Слишком много попыток входа. Повторите через 15 минут.")
    rate_limit_or_fail(request, "login_email", email, 10, 900,
                       "Слишком много попыток входа в этот аккаунт. Повторите через 15 минут.")
    if not is_valid_email(email) or not password:
        raise ApiError("Укажите email и пароль")

    user = User.objects.filter(email=email).first()
    # Одно сообщение для «нет пользователя» и «неверный пароль» — нельзя узнать, какие email есть в системе.
    if user is None or not check_password(password, user.password):
        security_log(request, "login_failed", user.id if user else None, email)
        raise ApiError("Неверный email или пароль", 401)
    if user.is_banned:
        security_log(request, "login_banned", user.id, email)
        raise ApiError("Аккаунт заблокирован администратором", 403)

    login_user(request, user)
    rate_limit_reset("login_ip", client_ip(request))
    rate_limit_reset("login_email", email)
    security_log(request, "login_success", user.id, email)
    joined = complete_pending_invite(request, user)
    return {"user": user_dict(user), "csrf_token": csrf_token(request.state.session),
            "joined_webinar_id": joined}


@router.post("/auth/admin-login", tags=["auth"], summary="Вход в панель администратора")
def admin_login(request: Request, body: LoginIn = LoginIn()):
    email = _email(body.email)
    password = str(body.password or "")
    rate_limit_or_fail(request, "admin_login_ip", client_ip(request), 5, 900,
                       "Слишком много попыток входа в панель администратора. Повторите через 15 минут.")
    rate_limit_or_fail(request, "admin_login_email", email, 5, 900,
                       "Слишком много попыток входа в этот аккаунт. Повторите через 15 минут.")
    if not is_valid_email(email) or not password:
        raise ApiError("Укажите email и пароль")

    user = User.objects.filter(email=email).first()
    if user is None or not check_password(password, user.password):
        security_log(request, "admin_login_failed", user.id if user else None, email)
        raise ApiError("Неверный email или пароль", 401)
    if user.role != User.Role.ADMIN or user.is_banned:
        security_log(request, "admin_login_denied", user.id, email)
        raise ApiError("Неверный email или пароль", 401)

    login_user(request, user)
    rate_limit_reset("admin_login_ip", client_ip(request))
    rate_limit_reset("admin_login_email", email)
    security_log(request, "admin_login_success", user.id, email)
    return {"user": user_dict(user), "csrf_token": csrf_token(request.state.session)}


@router.post("/auth/logout", tags=["auth"], summary="Выход")
def logout(request: Request):
    user = current_user(request)
    if user:
        security_log(request, "logout", user.id)
    logout_user(request)
    return {"ok": True}


@router.get("/auth/me", tags=["auth"], summary="Текущий пользователь")
def me(request: Request):
    user = current_user(request)
    if request.state.session.get("_auth_user_id") and (user is None or user.is_banned):
        logout_user(request)
        raise ApiError("Аккаунт заблокирован или удалён", 403)
    return {"user": user_dict(user) if user else None, "csrf_token": csrf_token(request.state.session)}


# ---------------------------------------------------------------------
# Восстановление пароля обычного пользователя (демо: код возвращается в ответе)
# ---------------------------------------------------------------------
@router.post("/auth/password/forgot", tags=["auth"], summary="Запрос кода восстановления")
def password_forgot(request: Request, body: ForgotIn = ForgotIn()):
    rate_limit_or_fail(request, "forgot", client_ip(request), 5, 3600,
                       "Слишком много запросов кода. Попробуйте через час.")
    email = _email(body.email)
    if not is_valid_email(email):
        raise ApiError("Укажите корректный email")
    user = User.objects.filter(email=email).first()
    if user is None or user.role == User.Role.ADMIN:
        raise ApiError("Пользователь с таким email не найден", 404)

    PasswordReset.objects.filter(user=user, used=False).update(used=True)
    code = generate_numeric_code(6)
    PasswordReset.objects.create(user=user, code=code, expires_at=timezone.now() + timedelta(minutes=10))
    security_log(request, "password_reset_requested", user.id, email)
    # ДЕМО: как и в исходном проекте, код показывается на экране вместо отправки письма.
    return {"ok": True, "code": code, "expires_in_minutes": 10, "name": user.name}


@router.post("/auth/password/reset", tags=["auth"], summary="Сброс пароля по коду")
def password_reset(request: Request, body: ResetIn = ResetIn()):
    rate_limit_or_fail(request, "reset", client_ip(request), 10, 3600,
                       "Слишком много попыток сброса пароля. Попробуйте позже.")
    email = _email(body.email)
    code = clean_text(body.code, 6)
    new_password = str(body.new_password or "")
    if not is_valid_email(email):
        raise ApiError("Укажите корректный email")
    if not (len(code) == 6 and code.isascii() and code.isdigit()):
        raise ApiError("Код должен состоять из 6 цифр")
    if err := password_policy_error(new_password, email):
        raise ApiError(err)

    user = User.objects.filter(email=email).first()
    if user is None or user.role == User.Role.ADMIN:
        raise ApiError("Неверный или истёкший код", 400)
    reset = (PasswordReset.objects.filter(user=user, used=False, expires_at__gte=timezone.now())
             .order_by("-id").first())
    import hmac
    if reset is None or not hmac.compare_digest(reset.code, code):
        security_log(request, "password_reset_failed", user.id, email)
        raise ApiError("Неверный или истёкший код", 400)

    user.set_password(new_password)
    user.save(update_fields=["password"])
    reset.used = True
    reset.save(update_fields=["used"])
    security_log(request, "password_reset_success", user.id, email)
    return {"ok": True}


# ---------------------------------------------------------------------
# Восстановление пароля администратора: код из серверного лога + ключ восстановления
# ---------------------------------------------------------------------
def deliver_admin_reset_code(request: Request, email: str, code: str, ttl_minutes: int) -> None:
    """Код пишется в серверный файл logs/admin-reset-codes.log, на экран НЕ выводится."""
    path = settings.ADMIN_RESET_LOG
    path.parent.mkdir(parents=True, exist_ok=True)
    line = (f"[{timezone.now():%Y-%m-%d %H:%M:%S}] admin={email} code={code} "
            f"ttl={ttl_minutes}min ip={client_ip(request)}\n")
    with open(path, "a", encoding="utf-8") as fh:
        fh.write(line)


@router.post("/auth/admin-password/forgot", tags=["auth"], summary="Код смены пароля админа (в серверный лог)")
def admin_password_forgot(request: Request, body: ForgotIn = ForgotIn()):
    rate_limit_or_fail(request, "admin_forgot", client_ip(request), 3, 3600,
                       "Слишком много запросов. Повторите через час.")
    email = _email(body.email)
    if not is_valid_email(email):
        raise ApiError("Укажите корректный email")

    user = User.objects.filter(email=email).first()
    if user and user.role == User.Role.ADMIN and not user.is_banned:
        AdminPasswordReset.objects.filter(user=user, used=False).update(used=True)
        code = generate_numeric_code(8)
        AdminPasswordReset.objects.create(
            user=user, code_hash=make_password(code), expires_at=timezone.now() + timedelta(minutes=10))
        deliver_admin_reset_code(request, email, code, 10)
        security_log(request, "admin_reset_requested", user.id, email)
    else:
        security_log(request, "admin_reset_unknown", None, email)
    return {"ok": True}  # ответ одинаковый для любого email


@router.post("/auth/admin-password/reset", tags=["auth"], summary="Смена пароля админа: код + ключ восстановления")
def admin_password_reset(request: Request, body: AdminResetIn = AdminResetIn()):
    rate_limit_or_fail(request, "admin_reset", client_ip(request), 10, 3600,
                       "Слишком много попыток. Повторите через час.")
    email = _email(body.email)
    code = clean_text(body.code, 8)
    recovery_key = normalize_recovery_key(str(body.recovery_key or ""))
    new_password = str(body.new_password or "")

    if not is_valid_email(email):
        raise ApiError("Укажите корректный email")
    if not (len(code) == 8 and code.isascii() and code.isdigit()):
        raise ApiError("Код должен состоять из 8 цифр")
    if err := password_policy_error(new_password, email):
        raise ApiError(err)
    if len(new_password) < 10:
        raise ApiError("Пароль администратора должен содержать не менее 10 символов")

    generic_fail = "Неверный код подтверждения или ключ восстановления"
    user = User.objects.filter(email=email).first()
    row = None
    if user and user.role == User.Role.ADMIN and not user.is_banned:
        row = (AdminPasswordReset.objects
               .filter(user=user, used=False, attempts__lt=5, expires_at__gte=timezone.now())
               .order_by("-id").first())
    if row is None:
        security_log(request, "admin_reset_failed", user.id if user else None, email)
        raise ApiError(generic_fail, 400)

    ok = check_password(code, row.code_hash)
    if ok and user.admin_recovery_hash is not None:
        ok = bool(recovery_key) and check_password(recovery_key, user.admin_recovery_hash)
    if not ok:
        row.attempts += 1
        row.save(update_fields=["attempts"])
        security_log(request, "admin_reset_failed", user.id, email)
        raise ApiError(generic_fail, 400)

    user.set_password(new_password)
    user.save(update_fields=["password"])
    AdminPasswordReset.objects.filter(user=user).update(used=True)
    security_log(request, "admin_reset_success", user.id, email)
    return {"ok": True}
