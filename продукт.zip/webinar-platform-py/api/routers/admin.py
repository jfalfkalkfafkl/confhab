"""/admin/* — панель администратора (только роль admin)."""
import re
import secrets
from datetime import timedelta

from django.conf import settings
from django.contrib.auth.hashers import check_password, make_password
from django.db.models import Count, Q
from django.db.models.functions import TruncDate
from django.utils import timezone
from fastapi import APIRouter, Depends, Request, Response

from core.models import Category, ErrorLog, Notification, Registration, SecurityLog, User, Webinar

from ..errors import ApiError
from ..notify import notify_registrants
from ..schemas import AdminUserPatchIn, AdminWebinarPatchIn, CategoryIn, PasswordConfirmIn
from ..security import rate_limit_or_fail, require_admin, security_log
from ..utils import (clean_text, detect_platform, fmt_dt, is_valid_email, parse_datetime)
from .public import invalidate_public_cache
from .webinars import (_check_length, _queryset, apply_status_change, filter_webinars,
                       paginate, parse_category, serialize_webinar, validated_stream_url)

router = APIRouter(prefix="/admin", tags=["admin"])

ROLES = {"participant", "organizer", "admin"}
STATUSES = {"scheduled", "live", "finished"}


@router.get("/stats", summary="Сводная статистика платформы")
def stats(_: User = Depends(require_admin)):
    u = User.objects.aggregate(
        users_total=Count("id"),
        organizers=Count("id", filter=Q(role="organizer")),
        participants=Count("id", filter=Q(role="participant")),
        admins=Count("id", filter=Q(role="admin")),
        banned=Count("id", filter=Q(is_banned=True)))
    w = Webinar.objects.aggregate(
        webinars_total=Count("id"),
        webinars_scheduled=Count("id", filter=Q(status="scheduled")),
        webinars_live=Count("id", filter=Q(status="live")),
        webinars_finished=Count("id", filter=Q(status="finished")))
    result = {**u, **w, "registrations_total": Registration.objects.count(),
              "errors_24h": ErrorLog.objects.filter(created_at__gte=timezone.now() - timedelta(hours=24)).count()}
    platforms = {r["platform"] or "none": r["c"] for r in Webinar.objects.values("platform").annotate(c=Count("id"))}

    today = timezone.now().date()
    start = today - timedelta(days=13)
    series = {(start + timedelta(days=i)): {"users": 0, "registrations": 0} for i in range(14)}
    for row in (User.objects.filter(created_at__date__gte=start)
                .annotate(d=TruncDate("created_at")).values("d").annotate(c=Count("id"))):
        if row["d"] in series:
            series[row["d"]]["users"] = row["c"]
    for row in (Registration.objects.filter(registered_at__date__gte=start)
                .annotate(d=TruncDate("registered_at")).values("d").annotate(c=Count("id"))):
        if row["d"] in series:
            series[row["d"]]["registrations"] = row["c"]
    days = [{"date": d.isoformat(), **v} for d, v in series.items()]
    return {"stats": result, "series": days, "platforms": platforms}


USER_SORTS = {
    "name": "name", "email": "email", "role": "role", "created_at": "created_at", "last_login": "last_login",
    "organized": "organized_count", "registered": "registered_count",
}


def _paged_params(page: int, per_page: int, default_per_page: int = 10):
    return max(1, page or 1), min(200, max(1, per_page or default_per_page))


def _order(sort_map: dict, sort: str, order: str, default: str):
    """ORDER BY из белого списка (названия колонок никогда не берутся из запроса напрямую)."""
    if sort and sort not in sort_map:
        raise ApiError("Недопустимое поле сортировки")
    field = sort_map.get(sort or default)
    return [("-" if order == "desc" else "") + field, "id"]


@router.get("/users", summary="Пользователи: поиск, фильтры, сортировка, пагинация")
def users(q: str = "", role: str = "", status: str = "", sort: str = "created_at", order: str = "desc",
          page: int = 1, per_page: int = 10, _: User = Depends(require_admin)):
    if role and role not in ROLES:
        raise ApiError("Недопустимая роль")
    qs = User.objects.annotate(organized_count=Count("webinars", distinct=True),
                               registered_count=Count("registrations", distinct=True))
    q = clean_text(q, 100)
    if q:
        qs = qs.filter(Q(name__icontains=q) | Q(email__icontains=q))
    if role:
        qs = qs.filter(role=role)
    if status == "banned":
        qs = qs.filter(is_banned=True)
    elif status == "active":
        qs = qs.filter(is_banned=False)
    qs = qs.order_by(*_order(USER_SORTS, sort, order, "created_at"))
    page, per_page = _paged_params(page, per_page)
    rows, meta = paginate(qs, page, per_page)
    return {"users": [{
        "id": r.id, "name": r.name, "email": r.email, "role": r.role, "is_banned": r.is_banned,
        "created_at": fmt_dt(r.created_at), "last_login_at": fmt_dt(r.last_login),
        "organized_count": r.organized_count, "registered_count": r.registered_count} for r in rows], **meta}


def _target_user(target_id: int, admin: User, self_message: str) -> User:
    # Администратор не может изменить/удалить сам себя — чтобы не лишить платформу единственного админа.
    if target_id == admin.id:
        raise ApiError(self_message, 403)
    target = User.objects.filter(pk=target_id).first()
    if target is None:
        raise ApiError("Пользователь не найден", 404)
    return target


@router.patch("/users/{user_id}", summary="Сменить роль / заблокировать")
def patch_user(user_id: int, request: Request, body: AdminUserPatchIn = AdminUserPatchIn(),
               admin: User = Depends(require_admin)):
    target = _target_user(user_id, admin, "Нельзя изменять собственную учётную запись из панели администратора")
    sent = body.model_fields_set
    if "name" in sent or "email" in sent:
        update = []
        if "name" in sent:
            name = clean_text(body.name, 100)
            if not name:
                raise ApiError("Имя не может быть пустым")
            target.name = name
            update.append("name")
        if "email" in sent:
            email = clean_text(body.email, 150).lower()
            if not is_valid_email(email):
                raise ApiError("Некорректный email")
            if User.objects.filter(email=email).exclude(pk=target.pk).exists():
                raise ApiError("Этот email уже занят", 409)
            target.email = email
            update.append("email")
        target.save(update_fields=update)
        security_log(request, "admin_user_edited", admin.id, f"user #{user_id}: {', '.join(update)}")
    if "role" in sent:
        if str(body.role) not in ROLES:
            raise ApiError("Недопустимая роль")
        target.role = str(body.role)
        target.save(update_fields=["role"])
        security_log(request, "admin_role_changed", admin.id, f"user #{user_id} → {target.role}")
    if "is_banned" in sent:
        banned = body.is_banned in (True, 1, "1", "true", "True", "on", "yes")
        target.is_banned = banned
        target.save(update_fields=["is_banned"])
        security_log(request, "admin_user_banned" if banned else "admin_user_unbanned", admin.id, f"user #{user_id}")
    return {"ok": True}


@router.delete("/users/{user_id}", status_code=204, summary="Удалить пользователя")
def delete_user(user_id: int, request: Request, admin: User = Depends(require_admin)):
    target = _target_user(user_id, admin, "Нельзя изменять собственную учётную запись из панели администратора")
    target.delete()  # вебинары, регистрации, сообщения удаляются каскадно
    security_log(request, "admin_user_deleted", admin.id, f"user #{user_id}")
    return Response(status_code=204)


@router.post("/users/{user_id}/reset-password", summary="Выдать временный пароль")
def reset_user_password(user_id: int, request: Request, admin: User = Depends(require_admin)):
    target = _target_user(user_id, admin, "Свой пароль меняйте в разделе «Безопасность»")
    if target.role == User.Role.ADMIN:
        raise ApiError("Пароль администратора может сменить только он сам", 403)
    alphabet = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    temp = "".join(secrets.choice(alphabet) for _ in range(12)) + str(10 + secrets.randbelow(90))
    target.set_password(temp)
    target.save(update_fields=["password"])
    security_log(request, "admin_user_password_reset", admin.id, f"user #{user_id}")
    return {"temporary_password": temp}  # показывается один раз


ADMIN_WEBINAR_SORTS = {
    "title": "title", "organizer": "organizer__name", "date": "scheduled_at", "status": "status",
    "participants": "participants_count", "created": "created_at",
}


@router.get("/webinars", summary="Вебинары: поиск, фильтры, сортировка, пагинация")
def admin_webinars(q: str = "", status: str = "", category: str = "", platform: str = "",
                   sort: str = "date", order: str = "desc", page: int = 1, per_page: int = 10,
                   admin: User = Depends(require_admin)):
    qs = filter_webinars(_queryset(admin.id), q=q, status=status, category=category, platform=platform)
    qs = qs.order_by(*_order(ADMIN_WEBINAR_SORTS, sort, order, "date"))
    page, per_page = _paged_params(page, per_page)
    rows, meta = paginate(qs, page, per_page)
    return {"webinars": [serialize_webinar(w, admin.id) for w in rows], **meta}


@router.patch("/webinars/{webinar_id}", summary="Редактировать вебинар / сменить статус")
def edit_webinar(webinar_id: int, request: Request, body: AdminWebinarPatchIn = AdminWebinarPatchIn(),
                 admin: User = Depends(require_admin)):
    """Администратор меняет любые поля любого вебинара (в т.ч. дату в прошлом — для исправления данных)."""
    webinar = Webinar.objects.filter(pk=webinar_id).first()
    if webinar is None:
        raise ApiError("Вебинар не найден", 404)
    sent = body.model_fields_set
    changes: dict = {}
    if "title" in sent:
        _check_length(body.title, 200, "Название вебинара не должно превышать 200 символов")
        title = clean_text(body.title, 200)
        if not title:
            raise ApiError("Укажите название вебинара (до 200 символов)")
        changes["title"] = title
    if "description" in sent:
        _check_length(body.description, 2000, "Описание не должно превышать 2000 символов")
        changes["description"] = clean_text(body.description, 2000) or None
    if "stream_url" in sent:
        url = validated_stream_url(body.stream_url)
        changes["stream_url"], changes["platform"] = url or None, detect_platform(url)
    if "recording_url" in sent:
        changes["recording_url"] = validated_stream_url(body.recording_url, "запись") or None
    if "category_id" in sent:
        changes["category_id"] = parse_category(body.category_id)
    if "scheduled_at" in sent:
        dt = parse_datetime(clean_text(body.scheduled_at, 32))
        if dt is None:
            raise ApiError("Некорректный формат даты и времени")
        changes["scheduled_at"] = dt
    new_status = None
    if "status" in sent:
        new_status = str(body.status or "")
        if new_status not in STATUSES:
            raise ApiError("Недопустимый статус")
    if not changes and new_status is None:
        raise ApiError("Не переданы поля для изменения")

    if changes:
        Webinar.objects.filter(pk=webinar_id).update(**changes)
    if new_status:
        apply_status_change(webinar, new_status)
    if "scheduled_at" in changes and changes["scheduled_at"] != webinar.scheduled_at:
        notify_registrants(webinar, f"Вебинар «{changes.get('title', webinar.title)}» перенесён на "
                                    f"{changes['scheduled_at']:%d.%m.%Y %H:%M}", Notification.Kind.SCHEDULE)
    invalidate_public_cache()
    detail = ", ".join(list(changes) + ([f"status → {new_status}"] if new_status else []))
    security_log(request, "admin_webinar_edited", admin.id, f"webinar #{webinar_id}: {detail}"[:255])
    return {"ok": True}


# ----------------------------- Категории -----------------------------------
def _category_fields(body: CategoryIn, partial: bool = False) -> dict:
    sent = body.model_fields_set
    data: dict = {}
    if not partial or "name" in sent:
        name = clean_text(body.name, 60)
        if not name:
            raise ApiError("Укажите название категории (до 60 символов)")
        data["name"] = name
    if not partial or "slug" in sent:
        slug = clean_text(body.slug, 60).lower()
        if not slug:  # слаг по умолчанию — латиница из названия не строится, поэтому просим явно
            raise ApiError("Укажите слаг: латиница, цифры и дефис (например, it-news)")
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", slug):
            raise ApiError("Слаг: только латиница, цифры и дефис")
        data["slug"] = slug
    if not partial or "sort_order" in sent:
        try:
            data["sort_order"] = min(32000, max(0, int(body.sort_order if body.sort_order not in (None, "") else 100)))
        except (TypeError, ValueError):
            raise ApiError("Порядок должен быть числом")
    return data


@router.post("/categories", status_code=201, summary="Создать категорию")
def create_category(request: Request, body: CategoryIn = CategoryIn(), admin: User = Depends(require_admin)):
    data = _category_fields(body)
    if Category.objects.filter(Q(name__iexact=data["name"]) | Q(slug=data["slug"])).exists():
        raise ApiError("Категория с таким названием или слагом уже есть", 409)
    category = Category.objects.create(**data)
    invalidate_public_cache()
    security_log(request, "admin_category_created", admin.id, category.name)
    return {"id": category.id}


@router.patch("/categories/{category_id}", summary="Изменить категорию")
def update_category(category_id: int, request: Request, body: CategoryIn = CategoryIn(),
                    admin: User = Depends(require_admin)):
    category = Category.objects.filter(pk=category_id).first()
    if category is None:
        raise ApiError("Категория не найдена", 404)
    data = _category_fields(body, partial=True)
    clash = Category.objects.exclude(pk=category_id)
    if ("name" in data and clash.filter(name__iexact=data["name"]).exists()) or \
            ("slug" in data and clash.filter(slug=data["slug"]).exists()):
        raise ApiError("Категория с таким названием или слагом уже есть", 409)
    for key, value in data.items():
        setattr(category, key, value)
    category.save()
    invalidate_public_cache()
    security_log(request, "admin_category_edited", admin.id, category.name)
    return {"ok": True}


@router.delete("/categories/{category_id}", status_code=204, summary="Удалить категорию (вебинары останутся без категории)")
def delete_category(category_id: int, request: Request, admin: User = Depends(require_admin)):
    category = Category.objects.filter(pk=category_id).first()
    if category is None:
        raise ApiError("Категория не найдена", 404)
    category.delete()  # FK webinar.category — SET_NULL
    invalidate_public_cache()
    security_log(request, "admin_category_deleted", admin.id, category.name)
    return Response(status_code=204)


# ----------------------------- Журнал ошибок -------------------------------
@router.get("/errors", summary="Журнал ошибок приложения (?source=server|client|integration)")
def error_log(source: str = "", page: int = 1, per_page: int = 20, _: User = Depends(require_admin)):
    qs = ErrorLog.objects.select_related("user").order_by("-id")
    if source:
        if source not in {"server", "client", "integration"}:
            raise ApiError("Недопустимый источник")
        qs = qs.filter(source=source)
    page, per_page = _paged_params(page, per_page, 20)
    rows, meta = paginate(qs, page, per_page)
    return {"errors": [{
        "id": e.id, "source": e.source, "message": e.message, "trace": e.trace, "path": e.path, "method": e.method,
        "user_name": e.user.name if e.user else None, "ip": e.ip, "created_at": fmt_dt(e.created_at)} for e in rows],
        **meta}


@router.delete("/errors", status_code=204, summary="Очистить журнал ошибок")
def clear_errors(request: Request, admin: User = Depends(require_admin)):
    ErrorLog.objects.all().delete()
    security_log(request, "admin_errors_cleared", admin.id)
    return Response(status_code=204)


@router.get("/security", summary="Состояние безопасности аккаунта админа")
def security_state(admin: User = Depends(require_admin)):
    return {
        "has_recovery_key": admin.admin_recovery_hash is not None,
        # True — пароль всё ещё учебный по умолчанию, его нужно сменить
        "default_password": check_password(settings.DEFAULT_ADMIN_PASSWORD, admin.password),
        "last_login_at": fmt_dt(admin.last_login),
    }


@router.post("/recovery-key", summary="Создать ключ восстановления (нужен пароль)")
def create_recovery_key(request: Request, body: PasswordConfirmIn = PasswordConfirmIn(),
                        admin: User = Depends(require_admin)):
    rate_limit_or_fail(request, "admin_recovery_key", str(admin.id), 5, 900,
                       "Слишком много попыток. Повторите позже.")
    if not check_password(str(body.password or ""), admin.password):
        security_log(request, "admin_recovery_key_failed", admin.id)
        raise ApiError("Пароль указан неверно", 401)
    raw = secrets.token_hex(10).upper()               # 20 HEX-символов (80 бит)
    key = "-".join(raw[i:i + 4] for i in range(0, 20, 4))
    admin.admin_recovery_hash = make_password(raw)
    admin.save(update_fields=["admin_recovery_hash"])
    security_log(request, "admin_recovery_key_created", admin.id)
    return {"recovery_key": key}  # показывается один раз


@router.get("/security-log", summary="Журнал событий безопасности (?type=all|admin|auth|denied)")
def security_log_list(type: str = "all", limit: int = 100, _: User = Depends(require_admin)):
    limit = min(500, max(1, limit))
    filters = {
        "all": Q(),
        "admin": Q(event__startswith="admin"),
        "auth": Q(event__startswith="login") | Q(event__in=["logout", "register"]),
        "denied": Q(event__contains="failed") | Q(event__contains="denied") | Q(event__contains="banned"),
    }
    rows = SecurityLog.objects.select_related("user").filter(filters.get(type, filters["all"])).order_by("-id")[:limit]
    return {"log": [{
        "id": r.id, "user_id": r.user_id, "user_name": r.user.name if r.user else None,
        "event": r.event, "ip": r.ip, "details": r.details, "created_at": fmt_dt(r.created_at)} for r in rows]}
