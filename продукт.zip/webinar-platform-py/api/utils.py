"""Валидация и вспомогательные функции (порт includes/security.php и functions.php)."""
import re
import secrets
from datetime import datetime
from urllib.parse import urlparse

from django.core.exceptions import ValidationError
from django.core.validators import validate_email

_CONTROL = re.compile(r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]")
_WEAK = {"password", "password1", "12345678", "123456789", "qwerty123", "qwertyui", "iloveyou"}


def clean_text(value, max_length: int) -> str:
    """Убирает управляющие символы и лишние пробелы, обрезает до max_length."""
    if value is None or isinstance(value, (dict, list)):
        return ""
    text = _CONTROL.sub("", str(value)).strip()
    return text[:max_length]


def is_valid_email(email: str) -> bool:
    if not email or len(email) > 150:
        return False
    try:
        validate_email(email)
        return True
    except ValidationError:
        return False


def is_safe_external_url(url: str) -> bool:
    """Только http/https, без логина:пароля в ссылке (защита от javascript:/data: и фишинга)."""
    if not url or len(url) > 500 or re.search(r"\s", url):
        return False
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    if parsed.scheme.lower() not in ("http", "https") or not parsed.hostname:
        return False
    return parsed.username is None


def password_policy_error(password: str, email: str = "") -> str | None:
    if len(password) < 8:
        return "Пароль должен содержать не менее 8 символов"
    if len(password) > 128:
        return "Пароль слишком длинный (максимум 128 символов)"
    if not re.search(r"[^\W\d_]", password) or not re.search(r"\d", password):
        return "Пароль должен содержать хотя бы одну букву и одну цифру"
    if password.lower() in _WEAK:
        return "Этот пароль слишком простой — выберите другой"
    if email and password.lower() == email.lower():
        return "Пароль не должен совпадать с email"
    return None


def parse_datetime(value: str) -> datetime | None:
    for fmt in ("%Y-%m-%dT%H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None


def fmt_dt(value: datetime | None) -> str | None:
    return value.strftime("%Y-%m-%d %H:%M:%S") if value else None


def generate_invite_token() -> str:
    return secrets.token_hex(12)


def generate_numeric_code(digits: int) -> str:
    return str(secrets.randbelow(10 ** digits)).zfill(digits)


def normalize_recovery_key(key: str) -> str:
    return re.sub(r"[^0-9A-F]", "", key.upper())


# ---------------------------------------------------------------------
# Площадки трансляции (Яндекс Телемост, VK Видео и др.)
# ---------------------------------------------------------------------
# ключ → (название для интерфейса, можно ли встроить плеер на страницу)
PLATFORMS = {
    "telemost": ("Яндекс Телемост", False),   # Телемост запрещает iframe — даём кнопку-переход
    "vk": ("VK Видео", True),
    "rutube": ("RuTube", True),
    "vimeo": ("Vimeo", True),
    "kinescope": ("Kinescope", True),
    "zoom": ("Zoom", False),
    "meet": ("Google Meet", False),
    "teams": ("Microsoft Teams", False),
    "file": ("Видеозапись", True),
    "other": ("Другая площадка", False),
    "": ("", False),
}

# хост (или его суффикс) → ключ площадки
_HOSTS = (
    ("telemost.yandex.ru", "telemost"), ("telemost.360.yandex.ru", "telemost"), ("telemost.yandex.com", "telemost"),
    ("vk.com", "vk"), ("vkvideo.ru", "vk"), ("vk.ru", "vk"),
    ("rutube.ru", "rutube"), ("vimeo.com", "vimeo"), ("kinescope.io", "kinescope"),
    ("zoom.us", "zoom"), ("meet.google.com", "meet"),
    ("teams.microsoft.com", "teams"), ("teams.live.com", "teams"),
)


def detect_platform(url: str | None) -> str:
    """Определяет площадку по ссылке: telemost / vk / rutube / ... / other (пустая ссылка → \"\")."""
    if not url:
        return ""
    try:
        parsed = urlparse(url)
    except ValueError:
        return "other"
    host = (parsed.hostname or "").lower().removeprefix("www.")
    if re.search(r"\.(webm|mp4|ogv|ogg|mov)$", parsed.path, re.I):
        return "file"
    for suffix, key in _HOSTS:
        if host == suffix or host.endswith("." + suffix):
            return key
    return "other"


def platform_label(key: str) -> str:
    return PLATFORMS.get(key, PLATFORMS["other"])[0]


def ics_escape(value: str) -> str:
    """Экранирование текста для iCalendar (RFC 5545)."""
    return (value.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,")
            .replace("\r\n", "\\n").replace("\n", "\\n"))
