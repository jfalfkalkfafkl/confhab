"""Единый формат ошибок REST API: {"error": "текст"} + корректные HTTP-коды."""
import traceback

from django.contrib.auth import SESSION_KEY
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400, headers: dict | None = None):
        self.message = message
        self.status = status
        self.headers = headers or {}


def json_error(message: str, status: int = 400, headers: dict | None = None) -> JSONResponse:
    return JSONResponse({"error": message}, status_code=status, headers=headers)


def register_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(ApiError)
    async def _api_error(_: Request, exc: ApiError):
        return json_error(exc.message, exc.status, exc.headers)

    @app.exception_handler(RequestValidationError)
    async def _validation(request: Request, exc: RequestValidationError):
        if any(err.get("loc", [""])[0] == "path" for err in exc.errors()):
            return json_error(f"Ресурс не найден: {request.url.path}", 404)
        return json_error("Некорректные данные запроса", 400)

    @app.exception_handler(StarletteHTTPException)
    async def _http(request: Request, exc: StarletteHTTPException):
        if exc.status_code == 404:
            return json_error(f"Ресурс не найден: {request.url.path}", 404)
        if exc.status_code == 405:
            return json_error("Метод не поддерживается", 405)
        return json_error(str(exc.detail), exc.status_code)

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception):
        """Любая непредвиденная ошибка: полный трейс — в журнал (файл + БД + Telegram), пользователю — общий текст."""
        from starlette.concurrency import run_in_threadpool

        from . import integrations
        from .errorlog import record_error

        session = getattr(request.state, "session", None)
        uid = None
        try:
            uid = int(session.get(SESSION_KEY)) if session is not None and session.get(SESSION_KEY) else None
        except Exception:  # noqa: BLE001
            uid = None
        trace = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        ip = request.client.host if request.client else ""
        message = f"{type(exc).__name__}: {exc}"
        await run_in_threadpool(record_error, "server", message, trace, request.url.path, request.method, uid, ip)
        integrations.telegram_alert(f"⚠ ConfHub: ошибка сервера\n{request.method} {request.url.path}\n{message}")
        return json_error("Внутренняя ошибка сервера. Мы уже получили отчёт — попробуйте позже.", 500)
