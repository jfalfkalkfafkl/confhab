"""FastAPI-приложение ConfHub.

  /api/v1/*            — REST API (Swagger UI: /api/v1/docs)
  /uploads/recordings  — отдача записей экрана
  всё остальное        — Django (страницы фронтенда, /join, /admin/)
"""
from django.conf import settings
from fastapi import Depends, FastAPI
from starlette.middleware.gzip import GZipMiddleware
from starlette.staticfiles import StaticFiles

from core.middleware import CSP, SECURITY_HEADERS

from .errors import register_error_handlers
from .routers import admin, auth, live, notifications, profile, public, webinars
from .security import DjangoSessionMiddleware, csrf_guard

DOC_PATHS = ("/api/v1/docs", "/api/v1/redoc", "/api/v1/openapi.json")


class SecurityHeadersASGI:
    """Заголовки безопасности для ответов FastAPI (Django добавляет свои сам)."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        path = scope.get("path", "")
        is_docs = path.startswith(DOC_PATHS)

        # HTTPS: за TLS-прокси (uvicorn --proxy-headers) http-запросы перенаправляются на https
        if settings.FORCE_HTTPS and scope.get("scheme") == "http":
            host = dict(scope.get("headers", [])).get(b"host", b"").decode()
            target = f"https://{host}{scope.get('path', '')}"
            if scope.get("query_string"):
                target += "?" + scope["query_string"].decode()
            await send({"type": "http.response.start", "status": 308,
                        "headers": [(b"location", target.encode()), (b"content-length", b"0")]})
            return await send({"type": "http.response.body", "body": b""})

        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                present = {k.lower() for k, _ in message.get("headers", [])}
                headers = list(message.get("headers", []))
                extra = dict(SECURITY_HEADERS)
                if settings.FORCE_HTTPS:
                    extra["Strict-Transport-Security"] = f"max-age={settings.HSTS_SECONDS}; includeSubDomains"
                if not is_docs and not path.startswith("/admin/"):
                    extra["Content-Security-Policy"] = CSP
                for name, value in extra.items():
                    if name.lower().encode() not in present:
                        headers.append((name.lower().encode(), value.encode()))
                message["headers"] = headers
            await send(message)

        await self.app(scope, receive, send_wrapper)


def build_api() -> FastAPI:
    api = FastAPI(
        title="ConfHub REST API", version="1.0.0",
        description="REST API платформы вебинаров. Авторизация — cookie-сессия, "
                    "изменяющие запросы требуют заголовок X-CSRF-Token (см. GET /csrf).",
        dependencies=[Depends(csrf_guard)],
    )
    api.add_middleware(DjangoSessionMiddleware)
    api.add_middleware(GZipMiddleware, minimum_size=700)   # JSON-ответы списков сжимаются
    register_error_handlers(api)
    for module in (auth, profile, public, webinars, live, notifications, admin):
        api.include_router(module.router)
    return api


def create_app(django_app):
    root = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
    settings.RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)

    root.mount("/api/v1", build_api())
    root.mount("/uploads/recordings", StaticFiles(directory=settings.RECORDINGS_DIR), name="recordings")
    root.mount("/", django_app)  # страницы, /join, /admin/, статика фронтенда
    return SecurityHeadersASGI(root)
