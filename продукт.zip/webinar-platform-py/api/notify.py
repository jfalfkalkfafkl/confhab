"""Уведомления пользователям: запись в таблицу notifications (колокольчик) + копия на e-mail."""
from core.models import Notification, Registration, User, Webinar

from . import integrations


def notify(user_id: int, text: str, kind: str = Notification.Kind.SYSTEM, webinar_id: int | None = None,
           email: bool = False) -> None:
    Notification.objects.create(user_id=user_id, kind=kind, text=text[:255], webinar_id=webinar_id)
    if email:
        address = User.objects.filter(pk=user_id).values_list("email", flat=True).first()
        if address:
            integrations.email_user(address, "ConfHub: " + text, text)


def notify_registrants(webinar: Webinar, text: str, kind: str, exclude_user_id: int | None = None) -> int:
    """Уведомление всем зарегистрированным на вебинар (одним INSERT, без цикла запросов)."""
    ids = (Registration.objects.filter(webinar_id=webinar.id)
           .exclude(user_id=exclude_user_id or 0).values_list("user_id", flat=True))
    items = [Notification(user_id=uid, kind=kind, text=text[:255], webinar_id=webinar.id) for uid in ids]
    Notification.objects.bulk_create(items)
    return len(items)
