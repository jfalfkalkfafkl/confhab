"""Pydantic-схемы тел запросов. Поля намеренно «мягкие» (Any): проверка и сообщения об ошибках
делаются в обработчиках — так сохраняются точные русские тексты ошибок исходного API,
а OpenAPI-документация (/api/v1/docs) всё равно описывает все поля."""
from typing import Any

from pydantic import BaseModel, ConfigDict


class Loose(BaseModel):
    model_config = ConfigDict(extra="ignore")


class RegisterIn(Loose):
    name: Any = None
    email: Any = None
    password: Any = None
    role: Any = "participant"


class LoginIn(Loose):
    email: Any = None
    password: Any = None


class ForgotIn(Loose):
    email: Any = None


class ResetIn(Loose):
    email: Any = None
    code: Any = None
    new_password: Any = None


class AdminResetIn(ResetIn):
    recovery_key: Any = None


class ProfileIn(Loose):
    name: Any = None


class ChangePasswordIn(Loose):
    current_password: Any = None
    new_password: Any = None


class WebinarIn(Loose):
    title: Any = None
    description: Any = None
    stream_url: Any = None
    recording_url: Any = None
    scheduled_at: Any = None
    status: Any = None
    category_id: Any = None


class MessageIn(Loose):
    message: Any = None


class PollIn(Loose):
    question: Any = None
    options: Any = None


class PollPatchIn(Loose):
    is_active: Any = None


class VoteIn(Loose):
    option_id: Any = None


class QuestionIn(Loose):
    question_text: Any = None


class AnswerIn(Loose):
    answer_text: Any = None


class AdminUserPatchIn(Loose):
    role: Any = None
    is_banned: Any = None
    name: Any = None
    email: Any = None


class AdminWebinarPatchIn(WebinarIn):
    """Администратор может изменить любое поле вебинара (те же поля, что у организатора)."""


class CategoryIn(Loose):
    name: Any = None
    slug: Any = None
    sort_order: Any = None


class ClientErrorIn(Loose):
    message: Any = None
    source: Any = None
    line: Any = None
    stack: Any = None
    page: Any = None


class NotificationsReadIn(Loose):
    ids: Any = None


class TelemostIn(Loose):
    title: Any = None


class PasswordConfirmIn(Loose):
    password: Any = None
