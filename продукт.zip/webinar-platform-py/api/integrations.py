"""Интеграции с внешними сервисами. Все они необязательные и включаются переменными окружения.

* Яндекс Телемост API — создание видеовстречи кнопкой в форме вебинара
  (TELEMOST_OAUTH_TOKEN, право telemost-api:conferences.create).
* Telegram Bot API — оповещения администратору об ошибках сервера и новых организаторах
  (TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID).
* E-mail (SMTP) — копия уведомления на почту пользователя (EMAIL_HOST и др., см. .env.example).
  Без настроек письма выводятся в консоль сервера.

Ошибки внешних сервисов не роняют запрос: пишутся в журнал ошибок (источник «integration»)
и превращаются в понятное сообщение пользователю.
"""
import logging
import threading

import httpx
from django.conf import settings
from django.core.mail import send_mail

from .errors import ApiError

log = logging.getLogger("api.integrations")

TELEMOST_URL = "https://cloud-api.yandex.net/v1/telemost-api/conferences"
TELEGRAM_URL = "https://api.telegram.org/bot{token}/sendMessage"
HTTP_TIMEOUT = 8.0


def enabled() -> dict:
    """Какие интеграции включены — отдаётся фронтенду (GET /integrations)."""
    return {
        "telemost": bool(settings.TELEMOST_OAUTH_TOKEN),
        "telegram": bool(settings.TELEGRAM_BOT_TOKEN and settings.TELEGRAM_CHAT_ID),
        "email": bool(settings.EMAIL_HOST),
    }


# ----------------------------- Яндекс Телемост -------------------------------
def telemost_create_conference(title: str = "") -> dict:
    """Создаёт публичную видеовстречу в Телемосте. Возвращает {"id", "join_url"}."""
    if not settings.TELEMOST_OAUTH_TOKEN:
        raise ApiError("Интеграция с Телемостом не настроена (TELEMOST_OAUTH_TOKEN). "
                       "Создайте встречу в Телемосте вручную и вставьте ссылку.", 503)
    try:
        response = httpx.post(
            TELEMOST_URL, timeout=HTTP_TIMEOUT,
            headers={"Authorization": f"OAuth {settings.TELEMOST_OAUTH_TOKEN}",
                     "Content-Type": "application/json"},
            json={"waiting_room_level": "PUBLIC"},
        )
    except httpx.HTTPError as exc:
        _integration_error("telemost", f"сеть: {exc}")
        raise ApiError("Не удалось связаться с Яндекс Телемостом. Попробуйте позже.", 502)

    if response.status_code in (401, 403):
        _integration_error("telemost", f"{response.status_code}: {response.text[:200]}")
        raise ApiError("Телемост отклонил токен или у него нет права создавать встречи.", 502)
    if response.status_code >= 400:
        _integration_error("telemost", f"{response.status_code}: {response.text[:200]}")
        raise ApiError("Телемост вернул ошибку. Создайте встречу вручную.", 502)

    data = response.json()
    join_url = data.get("join_url")
    if not join_url:
        _integration_error("telemost", "в ответе нет join_url")
        raise ApiError("Телемост не вернул ссылку на встречу.", 502)
    return {"id": data.get("id"), "join_url": join_url}


# ----------------------------- Telegram ---------------------------------------
def telegram_alert(text: str) -> bool:
    """Отправляет сообщение администратору в Telegram (в фоне, молча при сбое)."""
    if not (settings.TELEGRAM_BOT_TOKEN and settings.TELEGRAM_CHAT_ID):
        return False

    def _send():
        try:
            httpx.post(TELEGRAM_URL.format(token=settings.TELEGRAM_BOT_TOKEN), timeout=HTTP_TIMEOUT,
                       json={"chat_id": settings.TELEGRAM_CHAT_ID, "text": text[:3500]})
        except httpx.HTTPError as exc:  # не пишем в ErrorLog — иначе возможна петля «ошибка → алерт → ошибка»
            log.warning("telegram: %s", exc)

    threading.Thread(target=_send, daemon=True).start()
    return True


# ----------------------------- E-mail -----------------------------------------
def email_user(address: str, subject: str, body: str) -> None:
    """Письмо в фоне; без EMAIL_HOST ничего не делает (внутреннее уведомление всё равно создано)."""
    if not settings.EMAIL_HOST:
        return

    def _send():
        try:
            send_mail(subject[:150], body, settings.DEFAULT_FROM_EMAIL, [address], fail_silently=False)
        except Exception as exc:  # noqa: BLE001
            log.warning("email: %s", exc)

    threading.Thread(target=_send, daemon=True).start()


def _integration_error(service: str, details: str) -> None:
    from .errorlog import record_error
    record_error("integration", f"{service}: {details}"[:500])
