@echo off
chcp 65001 >nul
cd /d "%~dp0"

set PY=python
where python >nul 2>nul || set PY=py

if not exist ".venv\Scripts\python.exe" (
    echo Создаю виртуальное окружение...
    %PY% -m venv .venv || goto :error
)

if not exist ".venv\installed.flag" (
    echo Устанавливаю зависимости, подождите...
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto :error
    echo ok> ".venv\installed.flag"
)

echo.
echo Сайт откроется на http://localhost:8000  (вход: admin@confhub.local / Admin12345)
echo Остановить: Ctrl+C
echo.
start "" http://localhost:8000
".venv\Scripts\python.exe" -m uvicorn confhub.asgi:app --port 8000
goto :eof

:error
echo.
echo Ошибка. Проверьте, что установлен Python 3.10+ (python.org, галочка "Add Python to PATH").
pause
