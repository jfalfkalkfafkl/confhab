#!/bin/sh
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
[ -f .venv/installed.flag ] || { .venv/bin/python -m pip install -r requirements.txt && touch .venv/installed.flag; }
echo "Сайт: http://localhost:8000  (admin@confhub.local / Admin12345)"
exec .venv/bin/python -m uvicorn confhub.asgi:app --port 8000
