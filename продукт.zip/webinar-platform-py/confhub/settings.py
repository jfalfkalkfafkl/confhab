"""Настройки Django для ConfHub.

Django отвечает за: модели и миграции (ORM), подключение к СУБД, сессии,
аутентификацию, админ-панель /admin/ и отдачу страниц фронтенда.
REST API (/api/v1) реализован на FastAPI (папка api/) и работает поверх
тех же моделей Django.
"""
import os
from pathlib import Path

import dj_database_url
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def env_bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, "1" if default else "0").strip().lower() in ("1", "true", "yes", "on")


DEBUG = env_bool("DJANGO_DEBUG", True)
SECRET_KEY = os.getenv("DJANGO_SECRET_KEY") or ("dev-insecure-key" if DEBUG else "")
if not SECRET_KEY:
    raise RuntimeError("Задайте DJANGO_SECRET_KEY (в режиме DJANGO_DEBUG=0 он обязателен).")
ALLOWED_HOSTS = [h.strip() for h in os.getenv("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1").split(",") if h.strip()]
CSRF_TRUSTED_ORIGINS = [o.strip() for o in os.getenv("DJANGO_CSRF_TRUSTED_ORIGINS", "").split(",") if o.strip()]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "core",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "core.middleware.TextGzipMiddleware",            # сжатие html/css/js/json (уменьшает время загрузки)
    "whitenoise.middleware.WhiteNoiseMiddleware",  # отдаёт frontend/ (html, css, js) из корня сайта
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "core.middleware.SecurityHeadersMiddleware",
]

ROOT_URLCONF = "confhub.urls"
WSGI_APPLICATION = "confhub.wsgi.application"
ASGI_APPLICATION = "confhub.asgi.application"

TEMPLATES = [{
    "BACKEND": "django.template.backends.django.DjangoTemplates",
    "DIRS": [BASE_DIR / "core" / "templates"],
    "APP_DIRS": True,
    "OPTIONS": {"context_processors": [
        "django.template.context_processors.request",
        "django.contrib.auth.context_processors.auth",
        "django.contrib.messages.context_processors.messages",
    ]},
}]

# ---------------------------------------------------------------------
# СУБД: берётся из DATABASE_URL (PostgreSQL / MySQL / SQLite)
# ---------------------------------------------------------------------
DATABASES = {
    "default": dj_database_url.config(
        env="DATABASE_URL",
        default=f"sqlite:///{BASE_DIR / 'db.sqlite3'}",
        conn_max_age=60,
    )
}
if DATABASES["default"]["ENGINE"].endswith("mysql"):
    DATABASES["default"].setdefault("OPTIONS", {})["charset"] = "utf8mb4"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

AUTH_USER_MODEL = "core.User"
AUTHENTICATION_BACKENDS = ["django.contrib.auth.backends.ModelBackend"]
# Парольная политика проекта реализована в api/security.py (как в PHP-версии),
# для Django-админки используем те же правила через валидатор не требуется.
PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.Argon2PasswordHasher"
    if env_bool("USE_ARGON2") else "django.contrib.auth.hashers.PBKDF2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2PasswordHasher",
]

LANGUAGE_CODE = "ru"
TIME_ZONE = os.getenv("TIME_ZONE", "Europe/Moscow")
USE_I18N = True
# Даты хранятся «как есть» (локальное время сервера), как и в PHP-версии
# (поле datetime-local в форме не содержит часового пояса).
USE_TZ = False

# ---------------------------------------------------------------------
# Сессии: общие для Django-админки и FastAPI (cookie CONFHUB_SESSID)
# ---------------------------------------------------------------------
SESSION_ENGINE = "django.contrib.sessions.backends.db"
SESSION_COOKIE_NAME = "CONFHUB_SESSID"
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
SESSION_COOKIE_SECURE = env_bool("SESSION_COOKIE_SECURE", not DEBUG)
SESSION_COOKIE_AGE = 43200  # 12 часов
CSRF_COOKIE_SECURE = SESSION_COOKIE_SECURE
SESSION_IDLE_TIMEOUT = 7200        # 2 часа без активности
SESSION_ABSOLUTE_TIMEOUT = 43200   # 12 часов с момента входа

# ---------------------------------------------------------------------
# HTTPS (включается переменными окружения, когда сайт стоит за TLS-прокси: Caddy / nginx)
# ---------------------------------------------------------------------
FORCE_HTTPS = env_bool("FORCE_HTTPS", False)             # http → https (редирект 308) + заголовок HSTS
HSTS_SECONDS = int(os.getenv("HSTS_SECONDS", "31536000"))
if env_bool("TRUST_PROXY_SSL", FORCE_HTTPS):             # прокси передаёт X-Forwarded-Proto
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
SESSION_BIND_USER_AGENT = env_bool("SESSION_BIND_USER_AGENT", True)  # сессия «привязана» к браузеру

# ---------------------------------------------------------------------
# Статика и загрузки
# ---------------------------------------------------------------------
STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
WHITENOISE_ROOT = BASE_DIR / "frontend"
WHITENOISE_USE_FINDERS = DEBUG
# Кэш браузера: картинки и библиотеки — месяц, html/css/js приложения — 5 минут (файлы без хешей в имени).
WHITENOISE_MAX_AGE = 0 if DEBUG else 300
from core.middleware import static_cache_headers  # noqa: E402  (модуль без зависимостей от Django)
WHITENOISE_ADD_HEADERS_FUNCTION = static_cache_headers

# Кэш приложения (счётчики главной страницы, список категорий). Для нескольких процессов — Redis/Memcached.
CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache", "LOCATION": "confhub"}}
PUBLIC_CACHE_SECONDS = int(os.getenv("PUBLIC_CACHE_SECONDS", "60"))

# ---------------------------------------------------------------------
# Внешние сервисы (все необязательные, см. api/integrations.py)
# ---------------------------------------------------------------------
TELEMOST_OAUTH_TOKEN = os.getenv("TELEMOST_OAUTH_TOKEN", "")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
EMAIL_HOST = os.getenv("EMAIL_HOST", "")
EMAIL_PORT = int(os.getenv("EMAIL_PORT", "587"))
EMAIL_HOST_USER = os.getenv("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = os.getenv("EMAIL_HOST_PASSWORD", "")
EMAIL_USE_TLS = env_bool("EMAIL_USE_TLS", True)
DEFAULT_FROM_EMAIL = os.getenv("DEFAULT_FROM_EMAIL", "ConfHub <no-reply@confhub.local>")
EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"

MEDIA_ROOT = BASE_DIR / "media"
RECORDINGS_DIR = MEDIA_ROOT / "recordings"
MAX_RECORDING_BYTES = 400 * 1024 * 1024

ADMIN_RESET_LOG = BASE_DIR / "logs" / "admin-reset-codes.log"
DEFAULT_ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@confhub.local")
DEFAULT_ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "Admin12345")

# ---------------------------------------------------------------------
# Логирование: консоль + файлы с ротацией (logs/app.log — всё, logs/errors.log — только ошибки).
# Ошибки API дополнительно пишутся в таблицу error_log (см. api/errorlog.py) и видны в панели админа.
# ---------------------------------------------------------------------
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {"std": {"format": "%(asctime)s %(levelname)s %(name)s: %(message)s"}},
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "std"},
        "app_file": {"class": "logging.handlers.RotatingFileHandler", "formatter": "std", "encoding": "utf-8",
                     "filename": str(LOG_DIR / "app.log"), "maxBytes": 2_000_000, "backupCount": 5},
        "error_file": {"class": "logging.handlers.RotatingFileHandler", "formatter": "std", "encoding": "utf-8",
                       "filename": str(LOG_DIR / "errors.log"), "maxBytes": 2_000_000, "backupCount": 5,
                       "level": "ERROR"},
    },
    "root": {"handlers": ["console", "app_file", "error_file"], "level": "INFO"},
}
