from django.contrib import admin
from django.urls import path

from core import views

urlpatterns = [
    path("admin/", admin.site.urls),          # админ-панель Django (только роль admin)
    path("join", views.join_invite, name="join"),   # ссылка-приглашение: /join?token=...
    path("", views.index, name="index"),
]
