"""ASGI-вход: FastAPI (/api/v1, /uploads) + Django (всё остальное).

Запуск:  uvicorn confhub.asgi:app --reload
"""
import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "confhub.settings")

from django.core.asgi import get_asgi_application  # noqa: E402

django_app = get_asgi_application()  # инициализирует Django (apps, ORM) до импорта API

from core.bootstrap import bootstrap_database  # noqa: E402

bootstrap_database()  # создаёт БД (если нет), применяет миграции, создаёт admin

from api.main import create_app  # noqa: E402

app = create_app(django_app)
