"""WSGI-вход нужен только для `manage.py runserver`/админки без API.
Для полноценной работы (включая REST API) запускайте ASGI: uvicorn confhub.asgi:app"""
import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "confhub.settings")
application = get_wsgi_application()

from core.bootstrap import bootstrap_database  # noqa: E402

bootstrap_database()  # создаёт БД (если нет), применяет миграции, создаёт admin
