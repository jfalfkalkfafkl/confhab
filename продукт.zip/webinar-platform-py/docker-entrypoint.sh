#!/bin/sh
set -e
python manage.py migrate --noinput          # создаёт/обновляет таблицы в СУБД
python manage.py seed_admin                 # администратор по умолчанию (если admin ещё нет)
python manage.py collectstatic --noinput    # статика Django-админки
exec "$@"
