# ConfHub — платформа вебинаров (Django + FastAPI + СУБД, Vue 3 на фронтенде)

Публичная главная со слайдером и каталогом, личный кабинет организатора/участника, эфиры через
**Яндекс Телемост** и **VK Видео**, чат, опросы, вопросы, записи экрана, уведомления и панель администратора.

```
Браузер ──► uvicorn (один ASGI-процесс)
              ├─ /api/v1/*            FastAPI  — REST API (Swagger: /api/v1/docs)
              ├─ /uploads/recordings  FastAPI  — отдача записей экрана (с Range)
              └─ всё остальное        Django   — страницы фронтенда, /join, /admin/
                                          │
                       Django ORM + сессии ──► СУБД (PostgreSQL / MySQL / SQLite)
```

## Что реализовано (по этапам проекта)

| Этап | Где смотреть |
|---|---|
| **Детальная страница сущности, поиск, фильтрация, список записей в админке** | `webinar.html` (доступна и гостям), каталог на `/` — серверный поиск, категории, статус, площадка, сортировка, пагинация: `GET /api/v1/webinars?q=&category=&status=&platform=&sort=&page=&per_page=` |
| **Админка: статусы, редактирование, удаление, пагинация, сортировка, пользователи** | `admin.html`: пользователи и вебинары (серверные поиск/фильтры/сортировка по клику на заголовок/пагинация), правка вебинара и пользователя, смена статуса и роли, блокировка, сброс пароля, удаление, категории, журналы |
| **Адаптив 390×844, слайдер (4 изображения, автопрокрутка 3 с), оптимизация графики** | `index.html` + `js/slider.js` (`INTERVAL = 3000`); для каждого слайда 4 файла (мобильный кадр 390×480 и @2x, широкий 960×400 и 1344×560, WebP + JPEG), обложки карточек 480/800 px, `<picture>`, `srcset`, lazy-load, preload первого кадра. Исходники — `assets_src/`, скрипт — `python tools/optimize_images.py` (из 5.6 МБ получилось 9–130 КБ на файл) |
| **Анимации, микроанимации, CSS-библиотеки** | Bootstrap Grid (сетка), Animate.css (подмножество, 3.5 КБ), AOS (появление при прокрутке) — всё локально в `frontend/vendor/`; свои микроанимации в `css/ui.css` (кнопки, карточки, тосты, колокольчик, пульс «в эфире», Ken Burns в слайдере, скелетоны); учитывается `prefers-reduced-motion` |
| **БД, индексы, специфические функции** | `docs/er-diagram.png` (+ `.svg`, `.dot`). Новые таблицы `categories`, `notifications`, `error_log`; поля `webinars.category/platform/updated_at`; составные индексы под реальные запросы (проверено `EXPLAIN`, см. ниже). Специфика: определение площадки по ссылке, уведомления, календарь `.ics`, Телемост API |
| **Внешние API, логирование ошибок** | `api/integrations.py`: Яндекс Телемост API (создание встречи), Telegram Bot API (оповещения об ошибках), SMTP. Логи: `logs/app.log`, `logs/errors.log` (ротация), таблица `error_log`, раздел «Ошибки» в админке, отчёты об ошибках JS из браузера |
| **Безопасность: XSS, CSRF, SQLi, валидация, права на уровне API** | CSRF-токен на всех изменяющих запросах (419); ORM без сырого SQL; белые списки сортировок и фильтров; Vue экранирует вывод, `v-html` не используется (проверяет тест); CSP с allowlist плееров; валидация URL (только http/https), длины, ролей; чат/опросы/вопросы доступны только участникам вебинара (раньше читались без входа); голосовать и задавать вопросы могут только зарегистрированные |
| **HTTPS, защита сессий, роли** | `FORCE_HTTPS=1` — редирект 308 + HSTS; cookie `HttpOnly`, `SameSite=Lax`, `Secure`; перевыпуск ключа сессии при входе; тайм-ауты (2 ч простоя / 12 ч); **привязка сессии к User-Agent**; роли participant/organizer/admin; `deploy/Caddyfile`, `deploy/nginx.conf` |
| **Интеграции и тесты API** | `tests/test_api.py` — 27 тестов (в т.ч. Телемост с подменой HTTP) + `tests/e2e_smoke.py` — 66 проверок |
| **Кэширование, скорость** | кэш сводки главной и категорий (`PUBLIC_CACHE_SECONDS`), gzip для html/css/js/json, `Cache-Control` для статики (картинки и библиотеки — 30 дней), индексы, `select_related`/`annotate` без N+1, `preload` LCP-картинки, `font-display: swap` |
| **Рефакторинг, комментарии** | единые модули `api/integrations.py`, `api/notify.py`, `api/errorlog.py`; docstring у каждого эндпоинта (виден в Swagger); общие компоненты Vue (`pager`, `webinar-cover`, `notification-bell`, тосты) |
| **UX: подсказки, уведомления** | колокольчик с непрочитанными (регистрации, начало эфира, перенос, ответ на вопрос), тосты вместо `alert`, подсказки `data-tip`, распознавание площадки по ссылке на лету, скелетоны загрузки, пустые состояния, возврат на страницу после входа (`?next=`), «Добавить в календарь» |
| **Тестирование, документация** | `docs/TESTING.md`, этот README |

### Вместо YouTube — Яндекс Телемост и VK Видео
* Поле «Ссылка на трансляцию» (создание и правка вебинара) подсказывает именно эти площадки и показывает «Распознано: …».
* **VK Видео** (`vk.com/video-1_2`, `vkvideo.ru/…`, `video_ext.php`) встраивается плеером на странице вебинара.
* **Яндекс Телемост** запрещает встраивание в чужие сайты — вместо плеера кнопка «Перейти в Яндекс Телемост»; чат, опросы и вопросы остаются на платформе. Если задан `TELEMOST_OAUTH_TOKEN`, кнопка «Создать в Телемосте» создаёт встречу через API.
* Фильтр «Площадка» в каталоге и в админке, счётчики по площадкам в обзоре админки.
* Прежние ссылки на YouTube не ломаются (открываются кнопкой-ссылкой), но площадкой не предлагаются.
* Iframe теперь разрешён только для проверенных плееров (CSP `frame-src` + `js/video.js`); неизвестные сайты открываются ссылкой.

## Быстрый старт

### Вариант 1. Docker (PostgreSQL поднимется сам)
```bash
docker compose up --build
```
Открыть http://localhost:8000. Миграции и администратор создаются автоматически.

### Вариант 2. Локально
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # впишите свой DATABASE_URL (см. ниже)
uvicorn confhub.asgi:app --reload
```
База данных создаётся **автоматически при старте** (`core/bootstrap.py`): если базы нет —
выполняется `CREATE DATABASE` (PostgreSQL / MySQL; SQLite-файл создаётся сам), затем применяются
миграции и создаётся администратор `admin@confhub.local / Admin12345` (из `.env`), если admin ещё нет.
Повторные запуски безопасны. Отключить: `AUTO_MIGRATE=0` / `AUTO_SEED_ADMIN=0`.
Для создания БД у пользователя СУБД должно быть право `CREATE DATABASE`.
> Запускать нужно именно `uvicorn confhub.asgi:app`. `manage.py runserver` отдаёт только
> Django (без REST API).

`DATABASE_URL`:
| СУБД | Значение |
|---|---|
| PostgreSQL | `postgres://confhub:confhub@localhost:5432/confhub` |
| MySQL / MariaDB (как в OSPanel/phpMyAdmin) | `mysql://root:@127.0.0.1:3306/webinar_platform` — база создастся сама; раскомментируйте `mysqlclient` в `requirements.txt` |
| SQLite (без установки СУБД) | `sqlite:///db.sqlite3` |

Адреса: сайт `/`, админ-панель Django `/admin/`, документация API `/api/v1/docs`.

## Демо-данные и тесты
```bash
python tools/seed_demo.py            # 14 вебинаров, организатор demo-org@confhub.local / Demo12345
pip install -r requirements-dev.txt
pytest -q                            # 27 тестов, временная SQLite, сервер не нужен
python tests/e2e_smoke.py http://127.0.0.1:8000   # сквозной тест на ЧИСТОЙ базе (66 проверок)
```

## Структура
```
confhub/      настройки Django, urls, asgi.py (точка входа: FastAPI + Django)
core/         Django-приложение: models.py, admin.py, views.py (/, /join), middleware.py,
              migrations/, команда seed_admin
api/          FastAPI: main.py, security.py (сессии, CSRF, rate-limit, роли), utils.py,
              schemas.py, errors.py, routers/{auth,profile,webinars,live,admin}.py
frontend/     html + css + js (бывшая public/)
media/recordings/   записи экрана        logs/   admin-reset-codes.log
tests/              pytest (test_api.py, conftest.py) и e2e_smoke.py
docs/               ER-диаграмма (png/svg/dot), TESTING.md
deploy/             Caddyfile и nginx.conf для HTTPS
tools/              optimize_images.py (оптимизация графики), seed_demo.py (демо-данные)
assets_src/         исходные изображения слайдера (на сайт не попадают)
```

## Что чему соответствует
| Было (PHP) | Стало (Python) |
|---|---|
| `config/database.php` (mysqli, автосоздание таблиц) | `DATABASES` в `settings.py` + миграции Django |
| `database/schema.sql` | `core/models.py`, `core/migrations/0001_initial.py` |
| `public/api/v1/index.php` (роутер) | `api/routers/*.py` (FastAPI) |
| `includes/security.php` (сессии, CSRF, rate limit, лог) | `api/security.py`, `api/utils.py`, `core/middleware.py` |
| `password_hash` / `password_verify` | Django `make_password` / `check_password` (PBKDF2) |
| `$_SESSION` | Django-сессии в таблице `django_session` |
| `join.php`, `index.php` | `core/views.py`: `/join?token=…`, `/` |
| `seedAdmin()` | `python manage.py seed_admin` |
| `.htaccess` (заголовки, запрет скриптов в uploads) | middleware заголовков; записи отдаются как статика, формат проверяется по сигнатуре файла |

Сохранено поведение исходного API: коды ответов (в т.ч. 419 для CSRF, 429 для rate-limit),
тексты ошибок, формат JSON `{"error": "..."}`, формат дат `YYYY-MM-DD HH:MM:SS`,
CSRF-токен в `X-CSRF-Token`, ограничения частоты в БД, журнал безопасности,
двухфакторный сброс пароля администратора (код пишется в `logs/admin-reset-codes.log`
+ ключ восстановления), лимит записи 400 МБ.

В `frontend/js` изменены только `api.js` (убран подбор формата адресов под mod_rewrite;
загрузка файла теперь тоже шлёт заголовок `X-CSRF-Token`) и `common.js` (ссылка-приглашение
`/join?token=…` вместо `join.php`).

## Важно перед боевым запуском
* Смените `DJANGO_SECRET_KEY` и `ADMIN_PASSWORD`; в профиле админа — пароль, в разделе
  «Безопасность» создайте ключ восстановления.
* За HTTPS-прокси: `SESSION_COOKIE_SECURE=1`, `DJANGO_ALLOWED_HOSTS=ваш.домен`,
  `DJANGO_CSRF_TRUSTED_ORIGINS=https://ваш.домен`; uvicorn запускается с `--proxy-headers`
  (в Docker-образе это уже есть), иначе rate-limit будет считать IP прокси.
* Как и в исходном проекте: код сброса пароля *обычного* пользователя показывается на экране
  (демо вместо письма). Чат, опросы и вопросы теперь читают только участники вебинара.
* Несколько процессов uvicorn (`--workers N`): кэш `LocMemCache` у каждого свой — для боевого режима подключите Redis.

## Что не переносилось
* **Данные из старой MySQL-базы.** Новая база создаётся пустой. Хеши паролей PHP (`$2y$…`)
  Django не распознаёт, поэтому при переносе пользователям пришлось бы сбросить пароли.
* Старые файлы записей из `public/uploads/recordings`. Чтобы они проигрывались, положите их в
  `media/recordings/` (имена файлов остаются прежними).
* Вложенная папка `webinar-platform/webinar-platform` (более ранняя PHP-версия без REST API,
  с отдельными `*_api.php`) — рабочий проект её не использует.

## Проверено (предыдущая версия)
Сквозной тест `tests/e2e_smoke.py` (регистрация, вход, CSRF, роли, вебинары, чат, опросы, Q&A,
загрузка и отдача записи, приглашения, бан, сброс паролей, админ-панель, Swagger, `/admin/`)
проходит 66/66 на SQLite, на PostgreSQL 16 и в режиме `DJANGO_DEBUG=0` с `collectstatic`.
Не проверялись: MySQL (нужен драйвер `mysqlclient`) и сборка Docker-образа.
