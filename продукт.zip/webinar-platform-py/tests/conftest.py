"""Общие фикстуры pytest: приложение запускается «внутри» теста на временной SQLite-базе (сервер не нужен)."""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = tempfile.mkdtemp(prefix="confhub-test-")
os.environ.update({"DATABASE_URL": f"sqlite:///{_tmp}/test.sqlite3", "DJANGO_DEBUG": "1",
                   "ADMIN_EMAIL": "admin@confhub.local", "ADMIN_PASSWORD": "Admin12345",
                   "TELEMOST_OAUTH_TOKEN": "", "TELEGRAM_BOT_TOKEN": "", "EMAIL_HOST": ""})

import pytest  # noqa: E402
from starlette.testclient import TestClient  # noqa: E402

from confhub.asgi import app  # noqa: E402  (создаёт БД, миграции, администратора)


# Лимиты частоты (регистрация 10/час с IP и т.п.) в тестах отключены — все запросы идут с одного адреса.
# Тест лимитов включает их явно через фикстуру `real_rate_limit`.
import api.security as _sec  # noqa: E402

RATE = {"on": False}
_original_rate_limit = _sec.rate_limit_check
_sec.rate_limit_check = lambda *a, **k: _original_rate_limit(*a, **k) if RATE["on"] else True


@pytest.fixture()
def real_rate_limit():
    RATE["on"] = True
    yield
    RATE["on"] = False


class Client:
    """Клиент с cookie-сессией и автоматической подстановкой CSRF-токена."""

    def __init__(self, user_agent: str = "pytest-browser"):
        self.http = TestClient(app, headers={"user-agent": user_agent})
        self.token = self.http.get("/api/v1/csrf").json()["csrf_token"]

    def _call(self, method, url, **kw):
        r = self.http.request(method, "/api/v1/" + url.lstrip("/"), headers={"X-CSRF-Token": self.token}, **kw)
        if r.headers.get("content-type", "").startswith("application/json"):
            body = r.json()
            if isinstance(body, dict) and "csrf_token" in body:
                self.token = body["csrf_token"]
        return r

    def get(self, url, **kw): return self._call("GET", url, **kw)
    def post(self, url, json=None, **kw): return self._call("POST", url, json=json or {}, **kw)
    def patch(self, url, json=None, **kw): return self._call("PATCH", url, json=json or {}, **kw)
    def delete(self, url, **kw): return self._call("DELETE", url, **kw)


_counter = {"n": 0}


def make_user(role="participant", name=None):
    _counter["n"] += 1
    c = Client()
    email = f"u{_counter['n']}@test.com"
    r = c.post("auth/register", {"name": name or f"User{_counter['n']}", "email": email,
                                 "password": "Passw0rd!x", "role": role})
    assert r.status_code == 201, r.text
    c.email, c.id = email, r.json()["user"]["id"]
    return c


@pytest.fixture(scope="session")
def admin():
    c = Client()
    r = c.post("auth/admin-login", {"email": "admin@confhub.local", "password": "Admin12345"})
    assert r.status_code == 200, r.text
    return c


@pytest.fixture()
def organizer(): return make_user("organizer", "Оля Организатор")


@pytest.fixture()
def participant(): return make_user("participant", "Иван Участник")


@pytest.fixture()
def anon(): return Client()


def create_webinar(org, **kw):
    body = {"title": "Тест", "scheduled_at": "2030-01-01T10:00", **kw}
    r = org.post("webinars", body)
    assert r.status_code == 201, r.text
    return r.json()["id"]
