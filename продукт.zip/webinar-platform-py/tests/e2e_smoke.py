"""Сквозной смоук-тест REST API. Запуск на ЧИСТОЙ базе:
    uvicorn confhub.asgi:app --port 8000   (в другом терминале)
    python tests/e2e_smoke.py [http://127.0.0.1:8000]
Нужен пакет httpx (pip install httpx) и ADMIN_PASSWORD по умолчанию (Admin12345)."""
import httpx, time, os, sys, pathlib
B=sys.argv[1] if len(sys.argv)>1 else "http://127.0.0.1:8000"
LOG=pathlib.Path(__file__).resolve().parent.parent/"logs"/"admin-reset-codes.log"
def client():
    c=httpx.Client(base_url=B, timeout=20, follow_redirects=False)
    t=c.get("/api/v1/csrf").json()["csrf_token"]; c.headers["X-CSRF-Token"]=t; return c
def ok(cond,msg): print(("PASS " if cond else "FAIL ")+msg); 
    
def setcsrf(c,r):
    j=r.json()
    if "csrf_token" in j: c.headers["X-CSRF-Token"]=j["csrf_token"]

org=client(); part=client(); adm=client(); anon=client()
# CSRF
r=httpx.post(B+"/api/v1/auth/login",json={}); ok(r.status_code==419,f"CSRF без токена -> 419 ({r.status_code})")
# регистрация
r=org.post("/api/v1/auth/register",json={"name":"Оля","email":"Org@Test.com","password":"Passw0rd!x","role":"organizer"}); setcsrf(org,r)
ok(r.status_code==201 and r.json()["user"]["role"]=="organizer",f"register organizer {r.status_code}")
r=part.post("/api/v1/auth/register",json={"name":"Иван","email":"ivan@test.com","password":"Passw0rd!x"}); setcsrf(part,r)
ok(r.status_code==201 and r.json()["user"]["role"]=="participant","register participant")
r=anon.post("/api/v1/auth/register",json={"name":"x","email":"ivan@test.com","password":"Passw0rd!x"}); ok(r.status_code==409,"дубликат email 409")
r=anon.post("/api/v1/auth/register",json={"name":"x","email":"a@b.co","password":"short"}); ok(r.status_code==400,"слабый пароль 400: "+r.json()["error"])
r=anon.post("/api/v1/auth/register",json={"name":"x","email":"a@b.co","password":"Passw0rd!x","role":"admin"}); setcsrf(anon,r); ok(r.json()["user"]["role"]=="participant","role=admin при регистрации игнорируется")
# me
r=org.get("/api/v1/auth/me"); ok(r.json()["user"]["email"]=="org@test.com","me, email lowercased")
# вебинар
r=part.post("/api/v1/webinars",json={"title":"X","scheduled_at":"2026-12-01T10:00"}); ok(r.status_code==403,"участник не создаёт вебинар 403")
r=org.post("/api/v1/webinars",json={"title":"Python вебинар","description":"d","scheduled_at":"2026-12-01T10:00","stream_url":"javascript:alert(1)"}); ok(r.status_code==400,"javascript: url отклонён")
r=org.post("/api/v1/webinars",json={"title":"Python вебинар","description":"d","scheduled_at":"2026-12-01T10:00","stream_url":"https://youtu.be/abc"}); ok(r.status_code==201,"create webinar"); wid=r.json()["id"]; tok=r.json()["invite_token"]
r=part.get(f"/api/v1/webinars/{wid}"); w=r.json()["webinar"]; ok(w["invite_token"] is None and not w["is_owner"] and w["scheduled_at"]=="2026-12-01 10:00:00","карточка для участника: токен скрыт, дата в формате MySQL")
r=org.get(f"/api/v1/webinars/{wid}"); ok(r.json()["webinar"]["invite_token"]==tok and r.json()["webinar"]["is_owner"],"владелец видит токен")
r=anon.get("/api/v1/webinars/abc"); ok(r.status_code==404,"/webinars/abc -> 404")
# чат без регистрации
r=part.post(f"/api/v1/webinars/{wid}/messages",json={"message":"hi"}); ok(r.status_code==403,"чат без регистрации 403")
r=part.post(f"/api/v1/webinars/{wid}/registrations"); ok(r.status_code==201,"регистрация на вебинар")
r=part.post(f"/api/v1/webinars/{wid}/registrations"); ok(r.status_code==409,"повторная регистрация 409")
r=part.post(f"/api/v1/webinars/{wid}/messages",json={"message":"Привет <b>всем</b>"}); ok(r.status_code==201,"сообщение")
r=org.get(f"/api/v1/webinars/{wid}/messages",params={"after_id":0}); m=r.json()["messages"]; ok(len(m)==1 and m[0]["user_name"]=="Иван","чат читается")
# опросы
r=org.post(f"/api/v1/webinars/{wid}/polls",json={"question":"Q?","options":["a","b"]}); ok(r.status_code==201,"создать опрос"); pid=r.json()["id"]
r=org.post(f"/api/v1/webinars/{wid}/polls",json={"question":"Q?","options":["a"]}); ok(r.status_code==400,"<2 вариантов 400")
oid=part.get(f"/api/v1/webinars/{wid}/polls").json()["polls"][0]["options"][0]["id"]
r=part.post(f"/api/v1/polls/{pid}/votes",json={"option_id":oid}); ok(r.status_code==201,"голос")
r=part.post(f"/api/v1/polls/{pid}/votes",json={"option_id":oid}); ok(r.status_code==409,"повторный голос 409")
p=part.get(f"/api/v1/webinars/{wid}/polls").json()["polls"][0]; ok(p["options"][0]["votes"]==1 and p["voted_option_id"]==oid,"счётчик голосов и voted_option_id")
r=org.patch(f"/api/v1/polls/{pid}",json={"is_active":False}); ok(r.status_code==200,"закрыть опрос")
r=org.post(f"/api/v1/polls/{pid}/votes",json={"option_id":oid}); ok(r.status_code==409,"голос в закрытом опросе 409")
# Q&A
r=part.post(f"/api/v1/webinars/{wid}/questions",json={"question_text":"Как?"}); ok(r.status_code==201,"вопрос"); qid=r.json()["id"]
r=part.patch(f"/api/v1/questions/{qid}",json={"answer_text":"так"}); ok(r.status_code==403,"участник не отвечает 403")
r=org.patch(f"/api/v1/questions/{qid}",json={"answer_text":"Вот так"}); ok(r.status_code==200,"ответ организатора")
q=org.get(f"/api/v1/webinars/{wid}/questions").json()["questions"][0]; ok(q["is_answered"] is True,"is_answered bool")
# PATCH вебинара
r=org.patch(f"/api/v1/webinars/{wid}",json={"status":"live"}); ok(r.status_code==200,"status live")
r=org.patch(f"/api/v1/webinars/{wid}",json={"status":"bad"}); ok(r.status_code==400,"bad status 400")
r=org.patch(f"/api/v1/webinars/{wid}",json={}); ok(r.status_code==400,"пустой PATCH 400")
r=part.patch(f"/api/v1/webinars/{wid}",json={"status":"live"}); ok(r.status_code==403,"PATCH чужого 403")
r=org.get(f"/api/v1/webinars/{wid}/participants"); ok(len(r.json()["participants"])==1,"участники")
r=org.post(f"/api/v1/webinars/{wid}/invite"); newtok=r.json()["invite_token"]; ok(newtok!=tok,"перевыпуск приглашения")
# запись
webm=b"\x1a\x45\xdf\xa3"+os.urandom(2000)
r=org.post(f"/api/v1/webinars/{wid}/recording",files={"recording":("r.webm",webm,"video/webm")}); ok(r.status_code==201,f"upload webm {r.status_code} {r.text[:80]}"); path=r.json()["path"]
r=org.post(f"/api/v1/webinars/{wid}/recording",files={"recording":("r.php",b"<?php echo 1;","video/webm")}); ok(r.status_code==400,"подделанный MIME отклонён")
r=httpx.get(B+"/"+path,headers={"Range":"bytes=0-9"}); ok(r.status_code==206 and r.content==webm[:10],f"отдача записи с Range ({r.status_code})")
# join
j=httpx.Client(base_url=B)
r=j.get("/join",params={"token":newtok}); ok(r.status_code==302 and "login.html" in r.headers["location"],"join без входа -> login.html")
r=httpx.get(B+"/join?token=zzz"); ok(r.status_code==404,"join плохой токен 404")
# invite после входа: через сессию j
t=j.get("/api/v1/csrf").json()["csrf_token"]; j.headers["X-CSRF-Token"]=t
j.get("/join",params={"token":newtok})   # запоминаем pending
r=j.post("/api/v1/auth/register",json={"name":"Новый","email":"new@test.com","password":"Passw0rd!x"}); ok(r.json().get("joined_webinar_id")==wid,"pending invite -> joined_webinar_id")
# сброс пароля пользователя
r=anon.post("/api/v1/auth/password/forgot",json={"email":"ivan@test.com"}); code=r.json()["code"]
r=anon.post("/api/v1/auth/password/reset",json={"email":"ivan@test.com","code":code,"new_password":"NewPassw0rd1"}); ok(r.status_code==200,"reset password")
r=anon.post("/api/v1/auth/login",json={"email":"ivan@test.com","password":"NewPassw0rd1"}); setcsrf(anon,r); ok(r.status_code==200,"логин с новым паролем")
# смена пароля в профиле
r=part.post("/api/v1/profile/password",json={"current_password":"x","new_password":"Another12345"}); ok(r.status_code==401,"неверный текущий пароль 401")
# админ
r=part.get("/api/v1/admin/stats"); ok(r.status_code==403,"admin API для участника 403")
r=anon.post("/api/v1/auth/admin-login",json={"email":"ivan@test.com","password":"NewPassw0rd1"}); ok(r.status_code==401,f"admin-login для не-админа 401 ({r.status_code})")
r=adm.post("/api/v1/auth/admin-login",json={"email":"admin@confhub.local","password":"Admin12345"}); setcsrf(adm,r); ok(r.status_code==200,"admin-login")
r=adm.get("/api/v1/admin/stats").json(); ok(r["stats"]["users_total"]>=4 and len(r["series"])==14 and r["stats"]["webinars_live"]==1,f"stats {r['stats']}")
us=adm.get("/api/v1/admin/users").json()["users"]; ivan=[u for u in us if u["email"]=="ivan@test.com"][0]; ok(ivan["registered_count"]==1,"users + counts")
r=adm.patch(f"/api/v1/admin/users/{ivan['id']}",json={"is_banned":True}); ok(r.status_code==200,"ban")
r=part.get("/api/v1/auth/me"); ok(r.status_code==403,"забаненный теряет сессию 403")
r=adm.post(f"/api/v1/admin/users/{ivan['id']}/reset-password"); ok(len(r.json()["temporary_password"])==14,"temp password")
r=adm.get("/api/v1/admin/security").json(); ok(r["default_password"] is True and r["has_recovery_key"] is False,f"security {r}")
r=adm.post("/api/v1/admin/recovery-key",json={"password":"Admin12345"}); rk=r.json()["recovery_key"]; ok(len(rk)==24,"recovery key "+rk)
r=adm.get("/api/v1/admin/security-log",params={"type":"denied"}).json(); ok(len(r["log"])>0,"security-log denied")
# сброс пароля админа (код из лога + ключ)
r=anon.post("/api/v1/auth/admin-password/forgot",json={"email":"admin@confhub.local"}); ok(r.json()=={"ok":True},"admin forgot")
import re; code=re.findall(r"code=(\d{8})",LOG.read_text())[-1]
r=anon.post("/api/v1/auth/admin-password/reset",json={"email":"admin@confhub.local","code":code,"new_password":"VeryStrong123"}); ok(r.status_code==400,"reset без ключа 400")
r=anon.post("/api/v1/auth/admin-password/forgot",json={"email":"admin@confhub.local"})
code=re.findall(r"code=(\d{8})",LOG.read_text())[-1]
r=anon.post("/api/v1/auth/admin-password/reset",json={"email":"admin@confhub.local","code":code,"recovery_key":rk.lower(),"new_password":"VeryStrong123"}); ok(r.status_code==200,"admin reset с ключом")
# удаление
r=org.delete(f"/api/v1/webinars/{wid}"); ok(r.status_code==204,"delete 204")
# logout
r=org.post("/api/v1/auth/logout"); setcsrf(org,r); r=org.get("/api/v1/auth/me"); ok(r.json()["user"] is None,"logout")
# страницы / заголовки
r=httpx.get(B+"/"); ok(r.status_code==200 and "data-slider" in r.text and "Content-Security-Policy" in r.headers,"/ -> главная со слайдером")
r=httpx.get(B+"/login.html"); ok(r.status_code==200 and "Content-Security-Policy" in r.headers,"статическая страница + CSP")
r=httpx.get(B+"/css/style.css"); ok(r.status_code==200,"css")
r=httpx.get(B+"/api/v1/docs"); ok(r.status_code==200,"swagger /api/v1/docs")
r=httpx.get(B+"/admin/login/"); ok(r.status_code==200,"django admin login")
r=httpx.get(B+"/api/v1/nope"); ok(r.status_code==404 and "error" in r.json(),"404 json")
