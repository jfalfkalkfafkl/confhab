"""Тесты REST API: каталог, площадки, права доступа, админка, уведомления, интеграции, журнал ошибок.
Запуск:  pip install pytest httpx && pytest -q"""
import pytest
from conftest import Client, create_webinar, make_user


# ------------------------------ Каталог: поиск, фильтры, сортировка, пагинация ------------------------------
def test_catalog_search_filter_sort_pagination(organizer, anon):
    for i in range(1, 8):
        create_webinar(organizer, title=f"Каталог-тест {i:02d}", description="про python" if i % 2 else "про дизайн")
    r = anon.get("webinars", params={"q": "Каталог-тест", "per_page": 3, "page": 1, "sort": "title"})
    d = r.json()
    assert d["total"] == 7 and d["pages"] == 3 and len(d["webinars"]) == 3
    assert [w["title"] for w in d["webinars"]] == ["Каталог-тест 01", "Каталог-тест 02", "Каталог-тест 03"]
    last = anon.get("webinars", params={"q": "Каталог-тест", "per_page": 3, "page": 99, "sort": "title"}).json()
    assert last["page"] == 3 and len(last["webinars"]) == 1           # страница за пределами → последняя
    assert anon.get("webinars", params={"q": "про python Каталог"}).json()["total"] == 0
    assert anon.get("webinars", params={"q": "python", "per_page": 50}).json()["total"] >= 4
    assert anon.get("webinars", params={"sort": "drop table"}).status_code == 400
    assert anon.get("webinars", params={"status": "zzz"}).status_code == 400


def test_catalog_search_is_sql_injection_safe(anon):
    for q in ("' OR 1=1 --", "'; DROP TABLE webinars; --", "%", "_", "\\"):
        assert anon.get("webinars", params={"q": q}).status_code == 200
    assert anon.get("webinars").status_code == 200       # таблица на месте


def test_catalog_category_and_platform_filters(organizer, admin, anon):
    cat = admin.post("admin/categories", {"name": "Тест-кат", "slug": "test-cat", "sort_order": 5}).json()["id"]
    a = create_webinar(organizer, title="Фильтр-А", category_id=cat, stream_url="https://telemost.yandex.ru/j/123")
    create_webinar(organizer, title="Фильтр-Б", stream_url="https://vk.com/video-1_2")
    by_cat = anon.get("webinars", params={"category": "test-cat"}).json()["webinars"]
    assert [w["id"] for w in by_cat] == [a] and by_cat[0]["category"]["slug"] == "test-cat"
    tm = anon.get("webinars", params={"platform": "telemost", "q": "Фильтр"}).json()["webinars"]
    assert len(tm) == 1 and tm[0]["platform"] == "telemost" and tm[0]["platform_label"] == "Яндекс Телемост"
    vk = anon.get("webinars", params={"platform": "vk", "q": "Фильтр"}).json()["webinars"]
    assert len(vk) == 1 and vk[0]["platform_label"] == "VK Видео"


def test_platform_detected_on_create_and_patch(organizer):
    wid = create_webinar(organizer, stream_url="https://vkvideo.ru/video-5_6")
    assert organizer.get(f"webinars/{wid}").json()["webinar"]["platform"] == "vk"
    organizer.patch(f"webinars/{wid}", {"stream_url": "https://telemost.yandex.ru/j/777"})
    assert organizer.get(f"webinars/{wid}").json()["webinar"]["platform"] == "telemost"
    organizer.patch(f"webinars/{wid}", {"stream_url": ""})
    assert organizer.get(f"webinars/{wid}").json()["webinar"]["platform"] == ""
    assert organizer.patch(f"webinars/{wid}", {"stream_url": "javascript:alert(1)"}).status_code == 400
    assert organizer.post("webinars", {"title": "x", "scheduled_at": "2030-01-01T10:00", "category_id": 99999}).status_code == 400


def test_calendar_ics(organizer, anon):
    wid = create_webinar(organizer, title="Календарь, тест; 1")
    r = anon.get(f"webinars/{wid}/calendar.ics")
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/calendar")
    assert "BEGIN:VEVENT" in r.text and "DTSTART:20300101T100000" in r.text and "Календарь\\, тест\\; 1" in r.text
    assert anon.get("webinars/999999/calendar.ics").status_code == 404


# ------------------------------ Права доступа ------------------------------
def test_chat_polls_questions_require_membership(organizer, participant, anon):
    wid = create_webinar(organizer)
    for res in ("messages", "polls", "questions"):
        assert anon.get(f"webinars/{wid}/{res}").status_code == 401
        assert participant.get(f"webinars/{wid}/{res}").status_code == 403     # не зарегистрирован
        assert organizer.get(f"webinars/{wid}/{res}").status_code == 200
    assert participant.post(f"webinars/{wid}/questions", {"question_text": "?"}).status_code == 403
    participant.post(f"webinars/{wid}/registrations")
    assert participant.get(f"webinars/{wid}/messages").status_code == 200
    assert participant.post(f"webinars/{wid}/questions", {"question_text": "Когда запись?"}).status_code == 201
    assert anon.get("webinars/424242/messages").status_code == 401


def test_voting_requires_registration(organizer, participant):
    wid = create_webinar(organizer)
    pid = organizer.post(f"webinars/{wid}/polls", {"question": "Q?", "options": ["a", "b"]}).json()["id"]
    oid = organizer.get(f"webinars/{wid}/polls").json()["polls"][0]["options"][0]["id"]
    assert participant.post(f"polls/{pid}/votes", {"option_id": oid}).status_code == 403
    participant.post(f"webinars/{wid}/registrations")
    assert participant.post(f"polls/{pid}/votes", {"option_id": oid}).status_code == 201


def test_roles_and_ownership(organizer, participant, admin):
    wid = create_webinar(organizer)
    other = make_user("organizer")
    assert participant.post("webinars", {"title": "x", "scheduled_at": "2030-01-01T10:00"}).status_code == 403
    assert other.patch(f"webinars/{wid}", {"title": "hack"}).status_code == 403
    assert other.delete(f"webinars/{wid}").status_code == 403
    for url in ("admin/users", "admin/webinars", "admin/errors", "admin/stats"):
        assert participant.get(url).status_code == 403 and organizer.get(url).status_code == 403
        assert Client().get(url).status_code == 401
    assert participant.post("admin/categories", {"name": "x", "slug": "x"}).status_code == 403
    assert admin.get(f"webinars/{wid}/messages").status_code == 200      # админ читает любой вебинар


def test_csrf_required(organizer):
    r = organizer.http.post("/api/v1/webinars", json={"title": "x", "scheduled_at": "2030-01-01T10:00"})
    assert r.status_code == 419


def test_session_bound_to_user_agent(organizer):
    stolen = Client(user_agent="evil-browser")
    stolen.http.cookies.update(organizer.http.cookies)
    assert stolen.get("auth/me").json()["user"] is None
    # при подозрении на кражу сессия уничтожается на сервере целиком — владельцу придётся войти заново
    assert organizer.get("auth/me").json()["user"] is None


def test_session_works_with_same_user_agent(organizer):
    assert organizer.get("auth/me").json()["user"]["role"] == "organizer"


# ------------------------------ Уведомления ------------------------------
def test_notifications_flow(organizer, participant):
    wid = create_webinar(organizer, title="Уведомления")
    participant.post(f"webinars/{wid}/registrations")
    n = organizer.get("notifications").json()
    assert n["unread"] == 1 and "зарегистрировался" in n["notifications"][0]["text"]
    organizer.patch(f"webinars/{wid}", {"status": "live"})                 # старт эфира → участнику
    p = participant.get("notifications").json()
    assert p["unread"] == 1 and "начался" in p["notifications"][0]["text"]
    qid = participant.post(f"webinars/{wid}/questions", {"question_text": "Вопрос?"}).json()["id"]
    organizer.patch(f"questions/{qid}", {"answer_text": "Ответ"})
    assert participant.get("notifications").json()["unread"] == 2
    assert participant.post("notifications/read", {}).json()["updated"] == 2
    assert participant.get("notifications").json()["unread"] == 0
    assert Client().get("notifications").status_code == 401


def test_reschedule_notifies_registrants(organizer, participant):
    wid = create_webinar(organizer)
    participant.post(f"webinars/{wid}/registrations")
    organizer.patch(f"webinars/{wid}", {"scheduled_at": "2031-05-05T12:30"})
    assert any("перенесён" in x["text"] for x in participant.get("notifications").json()["notifications"])


# ------------------------------ Админка ------------------------------
def test_admin_users_pagination_sort_search(admin):
    for i in range(12):
        make_user("participant", f"Пагинация {i:02d}")
    d = admin.get("admin/users", params={"q": "Пагинация", "per_page": 5, "page": 2, "sort": "name", "order": "asc"}).json()
    assert d["total"] == 12 and d["pages"] == 3 and d["page"] == 2
    assert [u["name"] for u in d["users"]] == [f"Пагинация {i:02d}" for i in range(5, 10)]
    desc = admin.get("admin/users", params={"q": "Пагинация", "sort": "name", "order": "desc", "per_page": 1}).json()
    assert desc["users"][0]["name"] == "Пагинация 11"
    assert admin.get("admin/users", params={"sort": "password"}).status_code == 400
    assert admin.get("admin/users", params={"role": "root"}).status_code == 400


def test_admin_edit_ban_delete_user(admin):
    u = make_user("participant", "Редактируемый")
    assert admin.patch(f"admin/users/{u.id}", {"name": "Новое Имя", "email": "NEW@Test.com"}).status_code == 200
    row = admin.get("admin/users", params={"q": "new@test.com"}).json()["users"][0]
    assert row["name"] == "Новое Имя" and row["email"] == "new@test.com"
    assert admin.patch(f"admin/users/{u.id}", {"email": "bad"}).status_code == 400
    other = make_user("participant")
    assert admin.patch(f"admin/users/{u.id}", {"email": other.email}).status_code == 409
    assert admin.patch(f"admin/users/{u.id}", {"is_banned": True}).status_code == 200
    assert u.get("webinars").status_code == 200 and u.get("notifications").status_code == 403   # забанен
    assert admin.delete(f"admin/users/{u.id}").status_code == 204


def test_admin_webinars_list_edit_status_delete(admin, organizer, participant):
    wid = create_webinar(organizer, title="Админ-вебинар")
    participant.post(f"webinars/{wid}/registrations")
    d = admin.get("admin/webinars", params={"q": "Админ-вебинар", "sort": "title"}).json()
    assert d["total"] == 1 and d["webinars"][0]["organizer_name"] == "Оля Организатор"
    r = admin.patch(f"admin/webinars/{wid}", {"title": "Изменён админом", "stream_url": "https://vk.com/video-1_2",
                                              "scheduled_at": "2020-01-01T10:00", "status": "live"})
    assert r.status_code == 200, r.text                                     # админ может править даты в прошлом
    w = organizer.get(f"webinars/{wid}").json()["webinar"]
    assert w["title"] == "Изменён админом" and w["status"] == "live" and w["platform"] == "vk"
    assert participant.get("notifications").json()["unread"] >= 1
    assert admin.patch(f"admin/webinars/{wid}", {"status": "bad"}).status_code == 400
    assert admin.patch(f"admin/webinars/{wid}", {}).status_code == 400
    assert admin.patch("admin/webinars/99999", {"status": "live"}).status_code == 404
    assert admin.get("admin/webinars", params={"sort": "x"}).status_code == 400
    assert admin.delete(f"webinars/{wid}").status_code == 204


def test_admin_categories_crud(admin, anon):
    r = admin.post("admin/categories", {"name": "Новая", "slug": "novaya", "sort_order": 1})
    assert r.status_code == 201
    cid = r.json()["id"]
    assert admin.post("admin/categories", {"name": "Новая", "slug": "other"}).status_code == 409
    assert admin.post("admin/categories", {"name": "X", "slug": "Bad Slug"}).status_code == 400
    assert admin.patch(f"admin/categories/{cid}", {"name": "Переименована"}).status_code == 200
    assert any(c["name"] == "Переименована" for c in anon.get("categories").json()["categories"])  # кэш сброшен
    assert admin.delete(f"admin/categories/{cid}").status_code == 204
    assert admin.delete(f"admin/categories/{cid}").status_code == 404


def test_admin_stats_has_platforms(admin):
    d = admin.get("admin/stats").json()
    assert "platforms" in d and "errors_24h" in d["stats"]


# ------------------------------ Журнал ошибок и интеграции ------------------------------
def test_client_error_reported_and_visible(admin, anon):
    assert anon.post("client-errors", {"message": "boom", "source": "x.js", "line": 3, "stack": "at f"}).status_code == 204
    errs = admin.get("admin/errors", params={"source": "client"}).json()["errors"]
    assert any(e["message"] == "boom" for e in errs)


def test_unhandled_server_error_is_logged(admin, monkeypatch):
    import api.routers.public as pub
    monkeypatch.setattr(pub, "category_list", lambda: 1 / 0)
    c = TestClientNoRaise()
    r = c.get("/api/v1/categories")
    assert r.status_code == 500 and "Внутренняя ошибка" in r.json()["error"]
    monkeypatch.undo()
    errs = admin.get("admin/errors", params={"source": "server"}).json()["errors"]
    assert any("ZeroDivisionError" in e["message"] and e["trace"] for e in errs)


def TestClientNoRaise():
    from starlette.testclient import TestClient

    from confhub.asgi import app
    return TestClient(app, raise_server_exceptions=False)


def test_telemost_integration_not_configured(organizer):
    r = organizer.post("integrations/telemost", {"title": "x"})
    assert r.status_code == 503 and "не настроена" in r.json()["error"]
    assert organizer.get("integrations").json() == {"telemost": False, "telegram": False, "email": False}


def test_telemost_integration_with_mocked_api(organizer, admin, monkeypatch):
    import httpx
    from django.conf import settings
    monkeypatch.setattr(settings, "TELEMOST_OAUTH_TOKEN", "tok")
    seen = {}

    def fake_post(url, **kw):
        seen.update(url=url, headers=kw["headers"])
        return httpx.Response(201, json={"id": "1", "join_url": "https://telemost.yandex.ru/j/12345678901234"})
    monkeypatch.setattr(httpx, "post", fake_post)
    r = organizer.post("integrations/telemost", {"title": "Мой вебинар"})
    assert r.status_code == 200 and r.json()["join_url"].endswith("/j/12345678901234")
    assert seen["url"].endswith("/telemost-api/conferences") and seen["headers"]["Authorization"] == "OAuth tok"

    monkeypatch.setattr(httpx, "post", lambda *a, **k: httpx.Response(403, json={"error": "ApiRestrictedToOrganizations"}))
    r = organizer.post("integrations/telemost", {"title": "x"})
    assert r.status_code == 502
    assert any(e["source"] == "integration" for e in admin.get("admin/errors").json()["errors"])
    assert make_user("participant").post("integrations/telemost", {}).status_code == 403


# ------------------------------ Публичные ресурсы и безопасность ------------------------------
def test_public_summary_and_guest_webinar(organizer, anon):
    wid = create_webinar(organizer, title="Для гостя")
    assert anon.get("public/summary").json()["total"] >= 1
    w = anon.get(f"webinars/{wid}").json()["webinar"]
    assert w["title"] == "Для гостя" and w["invite_token"] is None and w["is_owner"] is False


def test_xss_payload_stored_as_plain_text(organizer, participant):
    wid = create_webinar(organizer, title="<script>alert(1)</script>")
    participant.post(f"webinars/{wid}/registrations")
    participant.post(f"webinars/{wid}/messages", {"message": "<img src=x onerror=alert(1)>"})
    # API отдаёт текст как есть (JSON); экранирование выполняет Vue ({{ }} → textContent), v-html в проекте не используется
    assert organizer.get(f"webinars/{wid}").json()["webinar"]["title"] == "<script>alert(1)</script>"


def test_security_headers_and_csp(anon):
    r = anon.http.get("/")
    csp = r.headers["content-security-policy"]
    assert "frame-ancestors 'none'" in csp and "vk.com" in csp and "youtube" not in csp
    assert r.headers["x-content-type-options"] == "nosniff"


def test_no_v_html_in_frontend():
    from pathlib import Path
    root = Path(__file__).resolve().parent.parent / "frontend"
    for f in list(root.glob("*.html")) + list((root / "js").rglob("app/*.js")):
        assert "v-html=" not in f.read_text(), f


def test_login_rate_limit(anon, real_rate_limit):
    codes = [anon.post("auth/login", {"email": "nobody@test.com", "password": "x"}).status_code for _ in range(12)]
    assert 429 in codes
