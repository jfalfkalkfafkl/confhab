"""Заголовки безопасности для страниц, отдаваемых Django (аналог send_security_headers() из PHP)."""

# Встраивать (iframe) можно только проверенные видеоплееры. Телемост, Zoom, Meet, Teams iframe запрещают сами —
# для них на странице вебинара показывается кнопка «Перейти».
FRAME_SRC = ("https://vk.com https://*.vk.com https://vkvideo.ru https://*.vkvideo.ru https://rutube.ru "
             "https://player.vimeo.com https://player.twitch.tv https://kinescope.io https://*.kinescope.io")

CSP = "; ".join([
    "default-src 'self'",
    "script-src 'self' 'unsafe-eval'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "img-src 'self' data: https:",
    "media-src 'self' https:",
    f"frame-src {FRAME_SRC}",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
])

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), microphone=(self), camera=(self)",
    "Cross-Origin-Opener-Policy": "same-origin",
}


def static_cache_headers(headers, path, url):
    """WhiteNoise: долгий кэш для картинок/шрифтов/библиотек, короткий — для html/css/js приложения."""
    from django.conf import settings
    if settings.DEBUG:
        headers["Cache-Control"] = "no-cache"
    elif url.startswith(("/img/", "/vendor/", "/js/vendor/")):
        headers["Cache-Control"] = "public, max-age=2592000"
    else:
        headers["Cache-Control"] = "public, max-age=300, must-revalidate"


_GZIP_TYPES = ("text/", "application/json", "application/javascript", "image/svg+xml", "application/xml")


class TextGzipMiddleware:
    """Сжимает текстовые ответы (html, css, js, json, svg). Картинки и видео не трогает — они уже сжаты."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        if ("gzip" not in request.headers.get("Accept-Encoding", "") or response.has_header("Content-Encoding")
                or request.headers.get("Range") or response.status_code != 200
                or not response.headers.get("Content-Type", "").startswith(_GZIP_TYPES)):
            return response
        import gzip
        body = b"".join(response.streaming_content) if response.streaming else response.content
        if len(body) < 600:
            if response.streaming:  # поток уже прочитан — отдаём как обычный ответ
                response.streaming_content = iter([body])
            return response
        packed = gzip.compress(body, compresslevel=6)
        if response.streaming:
            from django.http import HttpResponse
            new = HttpResponse(packed, status=response.status_code)
            for key, value in response.items():
                if key.lower() not in ("content-length", "accept-ranges"):
                    new[key] = value
            response = new
        else:
            response.content = packed
        response["Content-Encoding"] = "gzip"
        response["Content-Length"] = str(len(packed))
        response.headers["Vary"] = "Accept-Encoding"
        return response


class SecurityHeadersMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        for name, value in SECURITY_HEADERS.items():
            response.headers.setdefault(name, value)
        # У админки Django своя вёрстка (inline-скрипты) — CSP применяем к остальным страницам.
        if not request.path.startswith("/admin/"):
            response.headers.setdefault("Content-Security-Policy", CSP)
        return response
