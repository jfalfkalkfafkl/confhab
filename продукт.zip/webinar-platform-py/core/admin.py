from django.contrib import admin

from . import models


@admin.register(models.User)
class UserAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "email", "role", "is_banned", "last_login", "created_at")
    list_filter = ("role", "is_banned")
    search_fields = ("name", "email")
    exclude = ("password", "admin_recovery_hash")
    readonly_fields = ("last_login", "created_at")


class PollOptionInline(admin.TabularInline):
    model = models.PollOption
    extra = 0


@admin.register(models.Webinar)
class WebinarAdmin(admin.ModelAdmin):
    list_display = ("id", "title", "organizer", "status", "scheduled_at")
    list_filter = ("status",)
    search_fields = ("title",)


@admin.register(models.Poll)
class PollAdmin(admin.ModelAdmin):
    list_display = ("id", "question", "webinar", "is_active")
    inlines = [PollOptionInline]


@admin.register(models.Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ("id", "webinar", "user", "is_answered", "created_at")


@admin.register(models.Registration)
class RegistrationAdmin(admin.ModelAdmin):
    list_display = ("id", "webinar", "user", "registered_at")


@admin.register(models.ChatMessage)
class ChatMessageAdmin(admin.ModelAdmin):
    list_display = ("id", "webinar", "user", "created_at")


@admin.register(models.SecurityLog)
class SecurityLogAdmin(admin.ModelAdmin):
    list_display = ("id", "created_at", "event", "user", "ip", "details")
    list_filter = ("event",)
    search_fields = ("details", "ip")

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(models.Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "slug", "sort_order")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(models.Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "kind", "text", "is_read", "created_at")
    list_filter = ("kind", "is_read")


@admin.register(models.ErrorLog)
class ErrorLogAdmin(admin.ModelAdmin):
    list_display = ("id", "created_at", "source", "method", "path", "message")
    list_filter = ("source",)
    search_fields = ("message", "path")

    def has_add_permission(self, request):
        return False
