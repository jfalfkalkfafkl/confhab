"""Модели ConfHub — точное соответствие таблицам из исходной схемы MySQL."""
from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager
from django.db import models


class UserManager(BaseUserManager):
    use_in_migrations = True

    def create_user(self, email, password=None, **extra):
        if not email:
            raise ValueError("Укажите email")
        user = self.model(email=self.normalize_email(email).lower(), **extra)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra):
        extra.setdefault("name", "Администратор")
        extra["role"] = User.Role.ADMIN
        return self.create_user(email, password, **extra)


class User(AbstractBaseUser):
    class Role(models.TextChoices):
        ORGANIZER = "organizer", "Организатор"
        PARTICIPANT = "participant", "Участник"
        ADMIN = "admin", "Администратор"

    name = models.CharField("Имя", max_length=100)
    email = models.EmailField("Email", max_length=150, unique=True)
    # password и last_login (= last_login_at из PHP-версии) — из AbstractBaseUser
    role = models.CharField("Роль", max_length=12, choices=Role.choices, default=Role.PARTICIPANT)
    is_banned = models.BooleanField("Заблокирован", default=False)
    admin_recovery_hash = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    objects = UserManager()
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["name"]

    class Meta:
        db_table = "users"
        verbose_name = "пользователь"
        verbose_name_plural = "пользователи"

    def __str__(self):
        return f"{self.name} <{self.email}>"

    # --- совместимость с django.contrib.admin: доступ в /admin/ только у роли admin ---
    @property
    def is_active(self):
        return not self.is_banned

    @property
    def is_staff(self):
        return self.role == self.Role.ADMIN and not self.is_banned

    @property
    def is_superuser(self):
        return self.is_staff

    def has_perm(self, perm, obj=None):
        return self.is_staff

    def has_module_perms(self, app_label):
        return self.is_staff


class Category(models.Model):
    """Тематика вебинара (фильтр в каталоге). Управляется администратором."""
    name = models.CharField("Название", max_length=60, unique=True)
    slug = models.SlugField("Слаг (для URL)", max_length=60, unique=True)
    sort_order = models.PositiveSmallIntegerField("Порядок", default=100)

    class Meta:
        db_table = "categories"
        ordering = ["sort_order", "name"]
        verbose_name = "категория"
        verbose_name_plural = "категории"

    def __str__(self):
        return self.name


class Webinar(models.Model):
    class Status(models.TextChoices):
        SCHEDULED = "scheduled", "Запланирован"
        LIVE = "live", "Идёт сейчас"
        FINISHED = "finished", "Завершён"

    title = models.CharField(max_length=200)
    description = models.TextField(null=True, blank=True)
    stream_url = models.CharField(max_length=500, null=True, blank=True)
    recording_url = models.CharField(max_length=500, null=True, blank=True)
    invite_token = models.CharField(max_length=64, null=True, blank=True, unique=True)
    scheduled_at = models.DateTimeField()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.SCHEDULED)
    organizer = models.ForeignKey(User, on_delete=models.CASCADE, related_name="webinars")
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True,
                                 related_name="webinars")
    # Площадка трансляции определяется по ссылке (telemost, vk, rutube, zoom, ...) — см. api/utils.detect_platform
    platform = models.CharField(max_length=20, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "webinars"
        ordering = ["-scheduled_at"]
        indexes = [
            # каталог и вкладки дашборда: фильтр по статусу + сортировка по дате
            models.Index(fields=["status", "scheduled_at"], name="idx_web_status_date"),
            # «мои вебинары» организатора
            models.Index(fields=["organizer", "scheduled_at"], name="idx_web_org_date"),
            models.Index(fields=["platform"], name="idx_web_platform"),
        ]

    def __str__(self):
        return self.title


class Registration(models.Model):
    webinar = models.ForeignKey(Webinar, on_delete=models.CASCADE, related_name="registrations")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="registrations")
    registered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "registrations"
        constraints = [models.UniqueConstraint(fields=["webinar", "user"], name="uniq_registration")]
        indexes = [models.Index(fields=["user", "registered_at"], name="idx_reg_user_time")]


class ChatMessage(models.Model):
    webinar = models.ForeignKey(Webinar, on_delete=models.CASCADE, related_name="chat_messages")
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    message = models.CharField(max_length=1000)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "chat_messages"
        # опрос чата: WHERE webinar_id = ? AND id > ? ORDER BY id (раз в 3 секунды у каждого зрителя)
        indexes = [models.Index(fields=["webinar", "id"], name="idx_chat_webinar_id")]


class Poll(models.Model):
    webinar = models.ForeignKey(Webinar, on_delete=models.CASCADE, related_name="polls")
    question = models.CharField(max_length=255)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "polls"


class PollOption(models.Model):
    poll = models.ForeignKey(Poll, on_delete=models.CASCADE, related_name="options")
    option_text = models.CharField(max_length=255)
    votes = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = "poll_options"


class PollVote(models.Model):
    poll = models.ForeignKey(Poll, on_delete=models.CASCADE, related_name="poll_votes")
    option = models.ForeignKey(PollOption, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "poll_votes"
        constraints = [models.UniqueConstraint(fields=["poll", "user"], name="uniq_vote")]


class Question(models.Model):
    webinar = models.ForeignKey(Webinar, on_delete=models.CASCADE, related_name="questions")
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    question_text = models.CharField(max_length=1000)
    answer_text = models.CharField(max_length=2000, null=True, blank=True)
    is_answered = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "questions"
        indexes = [models.Index(fields=["webinar", "created_at"], name="idx_q_webinar_time")]


class PasswordReset(models.Model):
    """Код восстановления пароля обычного пользователя (6 цифр)."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    code = models.CharField(max_length=6)
    expires_at = models.DateTimeField()
    used = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "password_resets"


class AdminPasswordReset(models.Model):
    """Код восстановления пароля администратора (8 цифр, хранится хешем)."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    code_hash = models.CharField(max_length=255)
    attempts = models.PositiveSmallIntegerField(default=0)
    used = models.BooleanField(default=False)
    expires_at = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "admin_password_resets"


class RateLimitHit(models.Model):
    bucket = models.CharField(max_length=190)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "rate_limit_hits"
        indexes = [models.Index(fields=["bucket", "created_at"], name="idx_bucket_time")]


class SecurityLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    event = models.CharField(max_length=50)
    ip = models.CharField(max_length=45)
    user_agent = models.CharField(max_length=255, null=True, blank=True)
    details = models.CharField(max_length=255, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "security_log"
        indexes = [models.Index(fields=["event", "created_at"], name="idx_event_time")]
        ordering = ["-id"]


class Notification(models.Model):
    """Уведомление внутри платформы (колокольчик в интерфейсе)."""
    class Kind(models.TextChoices):
        REGISTRATION = "registration", "Новая регистрация"
        LIVE = "live", "Эфир начался"
        SCHEDULE = "schedule", "Изменено время"
        ANSWER = "answer", "Ответ на вопрос"
        SYSTEM = "system", "Системное"

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="notifications")
    webinar = models.ForeignKey(Webinar, on_delete=models.CASCADE, null=True, blank=True)
    kind = models.CharField(max_length=20, choices=Kind.choices, default=Kind.SYSTEM)
    text = models.CharField(max_length=255)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "notifications"
        ordering = ["-id"]
        # счётчик непрочитанных и список «последние уведомления пользователя»
        indexes = [models.Index(fields=["user", "is_read", "id"], name="idx_notif_user_read")]


class ErrorLog(models.Model):
    """Журнал ошибок приложения: необработанные исключения сервера и ошибки JS в браузере."""
    class Source(models.TextChoices):
        SERVER = "server", "Сервер"
        CLIENT = "client", "Браузер"
        INTEGRATION = "integration", "Внешний сервис"

    source = models.CharField(max_length=12, choices=Source.choices, default=Source.SERVER)
    message = models.CharField(max_length=500)
    trace = models.TextField(blank=True, default="")
    path = models.CharField(max_length=255, blank=True, default="")
    method = models.CharField(max_length=10, blank=True, default="")
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    ip = models.CharField(max_length=45, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "error_log"
        ordering = ["-id"]
        indexes = [models.Index(fields=["source", "created_at"], name="idx_err_source_time")]
