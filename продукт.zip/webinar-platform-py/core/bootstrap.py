"""Автоматическая подготовка базы данных при старте приложения.

Что делает `bootstrap_database()` (вызывается из confhub/asgi.py и confhub/wsgi.py):

  1. Если СУБД — PostgreSQL или MySQL/MariaDB и самой базы ещё нет, создаёт её
     (`CREATE DATABASE`). Для SQLite файл базы создаётся автоматически.
  2. Применяет миграции (`manage.py migrate`) — создаёт/обновляет все таблицы.
  3. Создаёт администратора по умолчанию (`seed_admin`), если admin ещё нет.

Всё идемпотентно: при повторных запусках ничего не ломается и не дублируется.
Несколько процессов (uvicorn --workers N) не мешают друг другу — используется файловая блокировка.

Отключить: AUTO_MIGRATE=0 (миграции вручную), AUTO_SEED_ADMIN=0 (без авто-админа).
Ожидание недоступной СУБД: DB_WAIT_SECONDS (по умолчанию 15).
"""
import logging
import os
import time
from contextlib import contextmanager

from django.conf import settings
from django.core.management import call_command
from django.db import OperationalError, connections

log = logging.getLogger("confhub.bootstrap")


def _flag(name: str, default: bool = True) -> bool:
    return os.getenv(name, "1" if default else "0").strip().lower() in ("1", "true", "yes", "on")


@contextmanager
def _file_lock():
    """Межпроцессная блокировка (чтобы воркеры не мигрировали одновременно)."""
    lock_dir = settings.BASE_DIR / "logs"
    lock_dir.mkdir(parents=True, exist_ok=True)
    fh = open(lock_dir / ".bootstrap.lock", "a+")
    try:
        try:
            import fcntl
            fcntl.flock(fh, fcntl.LOCK_EX)
            unlock = lambda: fcntl.flock(fh, fcntl.LOCK_UN)  # noqa: E731
        except ImportError:  # Windows
            import msvcrt
            fh.seek(0)
            msvcrt.locking(fh.fileno(), msvcrt.LK_LOCK, 1)
            unlock = lambda: (fh.seek(0), msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1))  # noqa: E731
        try:
            yield
        finally:
            unlock()
    finally:
        fh.close()


# ---------------------------------------------------------------------
# Создание самой базы (CREATE DATABASE)
# ---------------------------------------------------------------------
def _create_postgres_db(cfg: dict) -> None:
    try:
        import psycopg
        from psycopg import sql
        connect = psycopg.connect
    except ImportError:  # psycopg2
        import psycopg2 as psycopg
        from psycopg2 import sql
        connect = psycopg.connect

    params = dict(host=cfg.get("HOST") or None, port=cfg.get("PORT") or None,
                  user=cfg.get("USER") or None, password=cfg.get("PASSWORD") or None)
    params = {k: v for k, v in params.items() if v}
    conn = connect(dbname="postgres", **params)
    try:
        conn.autocommit = True
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (cfg["NAME"],))
            if cur.fetchone() is None:
                cur.execute(sql.SQL("CREATE DATABASE {} ENCODING 'UTF8'").format(sql.Identifier(cfg["NAME"])))
                log.info("База данных PostgreSQL «%s» создана.", cfg["NAME"])
    finally:
        conn.close()


def _create_mysql_db(cfg: dict) -> None:
    import MySQLdb  # пакет mysqlclient

    params = dict(host=cfg.get("HOST") or "127.0.0.1", user=cfg.get("USER") or "root",
                  passwd=cfg.get("PASSWORD") or "")
    if cfg.get("PORT"):
        params["port"] = int(cfg["PORT"])
    conn = MySQLdb.connect(**params)
    try:
        name = cfg["NAME"].replace("`", "``")
        conn.cursor().execute(
            f"CREATE DATABASE IF NOT EXISTS `{name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        log.info("База данных MySQL «%s» создана (или уже была).", cfg["NAME"])
    finally:
        conn.close()


def ensure_database_exists() -> None:
    cfg = settings.DATABASES["default"]
    engine = cfg["ENGINE"]

    if engine.endswith("sqlite3"):
        name = str(cfg["NAME"])
        if name != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(name)), exist_ok=True)
        return  # сам файл SQLite создаётся при первом подключении

    deadline = time.monotonic() + float(os.getenv("DB_WAIT_SECONDS", "15"))
    while True:
        try:
            connections["default"].ensure_connection()
            return  # база уже есть
        except OperationalError as exc:
            connect_error = exc
        connections.close_all()
        try:
            if "postgresql" in engine:
                _create_postgres_db(cfg)
            elif "mysql" in engine:
                _create_mysql_db(cfg)
            else:
                raise connect_error
        except Exception as exc:  # СУБД ещё стартует / неверный логин и т. п.
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    f"Не удалось подключиться к базе «{cfg.get('NAME')}» "
                    f"({cfg.get('HOST') or 'localhost'}) и создать её автоматически.\n"
                    f"  Ошибка подключения: {connect_error}\n  Ошибка создания: {exc}\n"
                    f"Проверьте DATABASE_URL, что СУБД запущена и у пользователя есть право CREATE DATABASE."
                ) from exc
            time.sleep(1)
            continue
        connections.close_all()  # переподключимся уже к созданной базе


# ---------------------------------------------------------------------
def bootstrap_database() -> None:
    if not _flag("AUTO_MIGRATE", True):
        return
    with _file_lock():
        ensure_database_exists()
        call_command("migrate", interactive=False, verbosity=0)
        if _flag("AUTO_SEED_ADMIN", True):
            call_command("seed_admin", verbosity=0)
    connections.close_all()
