from django.conf import settings
from django.core.management.base import BaseCommand

from core.models import User


class Command(BaseCommand):
    help = "Создаёт администратора по умолчанию (ADMIN_EMAIL/ADMIN_PASSWORD), если admin ещё нет."

    def handle(self, *args, **options):
        if User.objects.filter(role=User.Role.ADMIN).exists():
            self.stdout.write("Администратор уже существует — пропускаю.")
            return
        email = settings.DEFAULT_ADMIN_EMAIL.lower()
        user, created = User.objects.get_or_create(
            email=email, defaults={"name": "Администратор", "role": User.Role.ADMIN}
        )
        if created:
            user.set_password(settings.DEFAULT_ADMIN_PASSWORD)
        user.role = User.Role.ADMIN
        user.save()
        self.stdout.write(self.style.SUCCESS(
            f"Администратор: {email} (пароль из ADMIN_PASSWORD — смените его после входа!)"))
