"""Страницы, которыми раньше занимались index.php и join.php."""
import logging

from django.conf import settings
from django.contrib.auth import SESSION_KEY
from django.db import IntegrityError
from django.http import FileResponse, HttpResponse, HttpResponseRedirect
from django.shortcuts import redirect

from .models import Registration, Webinar

log = logging.getLogger(__name__)

NOT_FOUND_HTML = """<!DOCTYPE html>
<html lang="ru"><head><meta charset="UTF-8"><title>Ссылка недействительна — ConfHub</title>
<link rel="stylesheet" href="/css/style.css"></head>
<body><div class="auth-shell"><div>
<div class="brand">Conf<span>Hub</span></div>
<div class="form-card" style="text-align:center;">
<h2>Ссылка недействительна</h2>
<p style="color:var(--muted);">Ссылка-приглашение устарела или была перевыпущена организатором.</p>
<a class="btn accent" href="/dashboard.html" style="margin-top:10px;">На главную</a>
</div></div></div></body></html>"""


def index(request):
    """/ → публичная главная страница со слайдером и каталогом."""
    return FileResponse(open(settings.BASE_DIR / "frontend" / "index.html", "rb"), content_type="text/html; charset=utf-8")


def join_invite(request):
    """/join?token=... — регистрация на вебинар по ссылке-приглашению."""
    token = (request.GET.get("token") or "").strip()
    if not token:
        return redirect("/dashboard.html")

    webinar = Webinar.objects.filter(invite_token=token).only("id").first()
    if webinar is None:
        return HttpResponse(NOT_FOUND_HTML, status=404)

    user_id = request.session.get(SESSION_KEY)
    if not user_id:
        # Запоминаем вебинар: после входа/регистрации API запишет пользователя на него.
        request.session["pending_invite_webinar_id"] = webinar.id
        return HttpResponseRedirect("/login.html?invite=1")

    try:
        Registration.objects.get_or_create(webinar_id=webinar.id, user_id=int(user_id))
    except IntegrityError:
        pass  # уже зарегистрирован
    return redirect(f"/webinar.html?id={webinar.id}")
