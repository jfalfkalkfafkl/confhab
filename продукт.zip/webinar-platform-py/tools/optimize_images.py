"""Оптимизация изображений для сайта (запуск: python tools/optimize_images.py).

Из исходников assets_src/*.png делает:
  * слайдер главной — для каждого из 4 слайдов 4 размера (WebP + JPEG-запасной):
      mobile   390×480 и @2x 780×960   (портрет, экран телефона 390×844)
      desktop  960×400 и 1344×560      (широкий кадр)
    кадрирование идёт вокруг «точки интереса» (FOCUS), чтобы на телефоне не терялось главное;
  * обложки карточек вебинаров — 480×270 и 800×450 (WebP);
  * og-image для соцсетей — 1200×630 (JPEG).
Исходники (5+ МБ) на сайт не попадают: браузер получает 30–150 КБ на изображение.
"""
from pathlib import Path
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "assets_src"
OUT = ROOT / "frontend" / "img"

# (файл, точка интереса x, y в долях 0..1)
SLIDES = [
    ("slide-1-conference-hall.png", 0.62, 0.45),
    ("slide-2-big-stage.png",       0.50, 0.50),
    ("slide-3-online-webinar.png",  0.38, 0.50),
    ("slide-4-audience.png",        0.55, 0.45),
]
VARIANTS = {"m": (390, 480), "m2": (780, 960), "d": (960, 400), "d2": (1344, 560)}


def crop_to(img: Image.Image, size, fx, fy) -> Image.Image:
    """Обрезка под нужное соотношение сторон вокруг точки (fx, fy) + масштабирование."""
    tw, th = size
    iw, ih = img.size
    scale = max(tw / iw, th / ih)
    cw, ch = tw / scale, th / scale                      # область исходника, которую берём
    left = min(max(fx * iw - cw / 2, 0), iw - cw)
    top = min(max(fy * ih - ch / 2, 0), ih - ch)
    box = tuple(round(v) for v in (left, top, left + cw, top + ch))
    return img.crop(box).resize(size, Image.LANCZOS)


def save(img: Image.Image, path: Path, **kw):
    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path, **kw)
    print(f"{path.relative_to(ROOT)}  {path.stat().st_size // 1024} КБ")


def main():
    for i, (name, fx, fy) in enumerate(SLIDES, 1):
        src = ImageOps.exif_transpose(Image.open(SRC / name)).convert("RGB")
        for key, size in VARIANTS.items():
            im = crop_to(src, size, fx, fy)
            save(im, OUT / "slider" / f"slide{i}-{key}.webp", format="WEBP", quality=74, method=6)
            save(im, OUT / "slider" / f"slide{i}-{key}.jpg", format="JPEG", quality=76, optimize=True, progressive=True)
        for w, h in ((480, 270), (800, 450)):
            save(crop_to(src, (w, h), fx, fy), OUT / "cards" / f"cover{i}-{w}.webp", format="WEBP", quality=72, method=6)
        if i == 1:
            save(crop_to(src, (1200, 630), fx, fy), OUT / "og-image.jpg", format="JPEG", quality=80, optimize=True, progressive=True)


if __name__ == "__main__":
    main()
