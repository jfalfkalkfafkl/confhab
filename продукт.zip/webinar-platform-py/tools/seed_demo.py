"""Демо-данные для показа проекта: python tools/seed_demo.py  (организатор demo-org@confhub.local / Demo12345).
Создаёт 14 вебинаров в разных категориях и на разных площадках (Телемост, VK Видео, RuTube), участников и регистрации."""
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "confhub.settings")
import django  # noqa: E402

django.setup()
from api.utils import detect_platform  # noqa: E402
from core.bootstrap import bootstrap_database  # noqa: E402
from core.models import Category, Registration, User, Webinar  # noqa: E402

bootstrap_database()
org, _ = User.objects.get_or_create(email="demo-org@confhub.local", defaults={"name": "Анна Организатор", "role": "organizer"})
org.set_password("Demo12345"); org.save()
people = []
for i in range(1, 6):
    u, _ = User.objects.get_or_create(email=f"demo{i}@confhub.local", defaults={"name": f"Участник {i}", "role": "participant"})
    u.set_password("Demo12345"); u.save(); people.append(u)

CATALOG = [
    ("Устойчивое развитие перед лицом глобальных вызовов", "science", "https://vk.com/video-22822305_456239018", "scheduled"),
    ("Python для аналитиков: быстрый старт", "it", "https://telemost.yandex.ru/j/12345678901234", "scheduled"),
    ("SMM без бюджета: что работает в 2026", "marketing", "https://vkvideo.ru/video-1_2", "scheduled"),
    ("Как проводить встречи, после которых хочется работать", "business", "", "scheduled"),
    ("Здоровый сон: наука и практика", "health", "https://rutube.ru/video/abc123/", "scheduled"),
    ("Дизайн интерфейсов: от идеи к прототипу", "creative", "https://telemost.yandex.ru/j/999", "live"),
    ("Основы data science", "it", "", "scheduled"),
    ("Научный доклад: итоги года", "science", "https://vk.com/video-1_3", "finished"),
    ("Финансовая грамотность для фрилансеров", "business", "", "scheduled"),
    ("Йога онлайн для офисных сотрудников", "health", "", "scheduled"),
    ("Безопасность веб-приложений: XSS, CSRF, SQLi", "it", "https://telemost.yandex.ru/j/555", "scheduled"),
    ("Контент-план на месяц за один вечер", "marketing", "https://vk.com/video-5_6", "scheduled"),
    ("Мастер-класс по акварели", "creative", "", "finished"),
    ("Карьерный рост в IT: вопросы и ответы", "business", "https://vkvideo.ru/video-7_8", "live"),
]
now = datetime.now()
for i, (title, cat, url, status) in enumerate(CATALOG):
    w, created = Webinar.objects.get_or_create(title=title, defaults=dict(
        organizer=org, description=f"{title}. Практика, примеры и ответы на ваши вопросы.",
        category=Category.objects.filter(slug=cat).first(), stream_url=url or None, platform=detect_platform(url),
        scheduled_at=now + timedelta(days=(i - 6) if status != "scheduled" else i + 1, hours=i % 5), status=status,
        invite_token=f"demo{i:02d}token"))
    if created:
        for u in people[: (i % 5) + 1]:
            Registration.objects.get_or_create(webinar=w, user=u)
print("Готово: вебинаров", Webinar.objects.count())
